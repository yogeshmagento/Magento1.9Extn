<?php

class Sparx_Designertool_Helper_Data extends Mage_Core_Helper_Abstract
{
	
	/**
     * resize images
     * @param type $originalImage
     * @param type $copyImage
     * @param type $width
     * @param type $height
     */
    public function resizeImages($originalImage, $copyImage, $width, $height) {
        if (file_exists($originalImage)) :
            $imageObj = new Varien_Image($originalImage);
            $imageObj->constrainOnly(TRUE);
            $imageObj->keepTransparency(True);
            $imageObj->keepAspectRatio(TRUE);
            $imageObj->keepFrame(FALSE);
            $imageObj->resize($width, $height);
            $imageObj->save($copyImage);
        endif;
    }

	
	 /**
     * get drop down values
     * @param type $attributeCode
     * @param type $storeId
     * @return type
     */
    public function getDropDownValues($attributeCode, $storeId) {
        $attributeId = Mage::getResourceModel('eav/entity_attribute')->getIdByCode('catalog_product', $attributeCode);
        $attribute = Mage::getModel('catalog/resource_eav_attribute')->load($attributeId);
        $defaultVal = $attribute->getDefaultValue();
        $attributeOptions = $attribute->setStoreId($storeId)->getSource()->getAllOptions();

        $attributeArr = array();
        $defaultColl = array();
        if (count($attributeOptions) > 0) {
            foreach ($attributeOptions as $attributeValue) {
                if ($attributeValue['value'] != '') {
                    if ($defaultVal == $attributeValue['value']) {
                        $defaultColl[$attributeValue['value']] = $attributeValue['label'];
                    } else {
                        $attributeArr[$attributeValue['value']] = $attributeValue['label'];
                    }
                }
            }
            if (count($defaultColl) > 0) {
                $attributeArr = $defaultColl + $attributeArr;
            }
        }
        return $attributeArr;
    }
    
    
    public function getDesignInfoId($productId){
         return $model = Mage::getModel('designertool/designertool')->getCollection()
                 ->addFieldToFilter('product_id',$productId)
                 ->addFieldToFilter('created_by','Admin')
                 ->getFirstItem();
    }
    
    public function getToolInfo($materialSizeId,$parameter){
        $model = Mage::getModel('material/sizeinfo')->load($materialSizeId);
        $systemDpi = Mage::getStoreConfig('tool_setting/dpi_info/dpi_info_field') ;
        return round($model->getData($parameter)*$systemDpi);
    }
    
    /*
     * resize image
     */
     
     public function getResizeImage($image="", $width=null, $height=null){
	   
	   $imageUrl = str_replace(Mage::getBaseUrl('media'),Mage::getBaseDir('media').DS,$image);
	   $imageResized = str_replace('/designImage/','/designImage/resize/'.$width.'x'.$height.DS, $imageUrl);
	    if (!file_exists($imageResized) && file_exists($imageUrl)){
            $imageObj = new Varien_Image($imageUrl);
            $imageObj->constrainOnly(TRUE);
            $imageObj->keepAspectRatio(TRUE);
            $imageObj->keepFrame(FALSE);
            $imageObj->resize($width, $height);
            $imageObj->save($imageResized);
            
        }
        return str_replace('/designImage/','/designImage/resize/'.$width.'x'.$height.DS, $image);
	}
    
    /*
     * create design image
     */
    
    public function createDesignimage($imageData){
        $encodedData = base64_decode(substr($imageData,22));
        $mediaPath = Mage::getBaseDir('media').'/designertool/designImage/';
        $designName = uniqid('design_').'.png';
        $fo = fopen($mediaPath.$designName, 'w');
        fwrite($fo, $encodedData) or die('write failed');        
        fclose($fo);
        if(file_exists($mediaPath.$designName)){
            return $designName;
        }else{
            return false;
        }
    }
    
    /*
     * remove previous design image.
     */
    
    public function removePrevImg($filename){
        $mediaPath = Mage::getBaseDir('media').'/designertool/designImage/';
        unlink($mediaPath.$filename);
    }
    
    /*
     * Sorting size array
     */
    
    public function sizesortArray($mixedArray){
        $filterArray= array();
        foreach($mixedArray as $value){
            $filterArray[$value['value']] = $value['label'];
        }
        asort($filterArray);  
        return $filterArray;
    }
    
    /*
     *  Retrive designed data
     */
    
    public function retriveDesigndata($designId){
        $designdata = array();
        $designModel = Mage::getModel('designertool/designertool')->load($designId);
        $customWidth = $designModel->getCustomWidth();
        $customHeight = $designModel->getCustomHeight();
        $designdata['canvasArr'] = json_decode($designModel->getCanvasArray());
        $designdata['dataArray'] = json_decode($designModel->getDataArray());
        $designdata['materialId'] = $designModel->getMaterialId();
        $designdata['canvasWidth'] = $designModel->getCanvasWidth();
        $designdata['canvasHeight'] = $designModel->getCanvasHeight();
        $designdata['customW'] = !empty($customWidth)?$customWidth:0;
        $designdata['customH'] = !empty($customHeight)?$customHeight:0;
        $designdata['materialSizeId'] = $designModel->getMaterialSizeId();
        
        return $designdata;
    }
    
    public function templateInfo($data){
        $material = Mage::getModel('material/sizeinfo')->load($data['materialSizeId']);
        
        $isCustom=$data['is_custom'];
        
        if(isset($isCustom)){
				$width=$data['custom_width'];
				$height=$data['custom_height'];
			}
			else{
			$width=$material->getWidth();
			$height=$material->getHeight();
		}
        
        
        
        $systemDpi = Mage::getStoreConfig('tool_setting/dpi_info/dpi_info_field') ; 
        $resultArray = array();
        $resultArray['width'] = $width*$systemDpi;
        $resultArray['height'] =$height*$systemDpi;
        
        $resultArray['org_width'] = $width;
        $resultArray['org_height'] =$height;
        
        return $resultArray;
    }    
}
