<?php

class Sparx_Designertool_ProcessController extends Mage_Core_Controller_Front_Action {

    // set image magick path
    protected $_imagemagickpath;
    // set original image path of upload image
    protected $_userUpdOriginalImage;
    // set large image path of upload image
    protected $_largeImage;
    // set thumb image path of upload image
    protected $_thumbImage;
    // set filename of upload image
    protected $_fileName;
    // set file temp. name of upload image
    protected $_file_tmp;
    // set file type of upload image
    protected $_file_type;
    // set file type of upload image
    protected $_file_size;
    // set file ext type of upload image
    protected $_fileExt;
    // set image counter variable
    protected $imagecounter;
    // set error message
    protected $errormessage;    
    // set status
    protected $status;
    // thumb image url
    protected $thumbimageurl;
    // large image url
    protected $largeimageurl;

//     public function __construct() {
//        $this->_imagemagickpath = Mage::getStoreConfig('designertool/imagemagick_info/image_magick_path');//'/usr/bin/convert';
//    }

    public function indexAction() {
        $this->_imagemagickpath = Mage::getStoreConfig('designertool/imagemagick_info/image_magick_path');//'/usr/bin/convert';
        Mage::register('imagemagicpath');
        $this->loadLayout();
        $this->renderLayout();
    }

    public function makeTextAction() {
        $resultArray = array();
        $data = $this->getRequest()->getPost();
        $imagename = uniqid('Textimage_') . '.png';
        $textDir = Mage::getBaseDir('media') . DS . 'designertool' . DS . 'textimage' . DS;
        $texturl = Mage::getBaseUrl('media') . 'designertool' . DS . 'textimage' . DS;

        if ($data['text_val'] != '') {
            if ($data['rot'] != '' && $data['arc'] != '') {
                $data['align'] = 'center';
                if ($stroke == 0)
                    exec('convert  -density 200 -depth 8 -quality 100 -size 2000x2000 -background none -font "' . $data['font'] . '" -fill "' . $data['color'] . '" -gravity ' . $data['align'] . '  -pointsize 32  label:"' . $data['text_val'] . '" virtual-pixel transparent  -gravity center -rotate ' . $data['rot'] . '   -distort Arc "' . $data['arc'] . '" -trim   ' . $textDir . $imagename);
                else {
                    exec('convert  -density 200 -depth 8 -quality 100 -size 2000x2000 -background none -font "' . $data['font'] . '" -fill "' . $data['color'] . '" -strokewidth "' . $data['stroke'] . '" -stroke "' . $data['strokecolor'] . '" -gravity ' . $data['align'] . '  -pointsize 32  label:"' . $data['text_val'] . '" virtual-pixel transparent  -gravity center -rotate ' . $data['rot'] . '   -distort Arc "' . $data['arc'] . '" -trim ' . $textDir . $imagename);
                }

                $resImage =  $texturl . $imagename;
            } else {
                if ($data['stroke'] == 0) {
                    $textsize = $data['width'].'x'.$data['height'];
                    if($data['textType'] == 'update'){
                       // $data['font_size'] = '2000';
                        exec( 'convert  -density 450 -depth 10 -quality 100 -background  none  -units PixelsPerInch  -fill "' . $data['color'] . '" -font "' . $data['font'] . '" -gravity ' . $data['align'] . ' -pointsize ' . $data['font_size'] . ' -resize  ' . $textsize . '\! label:"' . $data['text_val'] . '"  -trim +repage  ' . $textDir . $imagename); 
                    }else{
                        exec('convert  -density 200 -depth 8 -quality 100 -size 2000x2000 -background none -fill "' . $data['color'] . '" -font "' . $data['font'] . '" -gravity ' . $data['align'] . '  -pointsize 18 label:"' . $data['text_val'] . '" -trim ' . $textDir . $imagename);
                    }
                } else {
                    exec('convert  -density 200 -depth 8 -quality 100 -size 2000x2000 -background none -fill "' . $data['color'] . '" -strokewidth "' . $data['stroke'] . '" -stroke "' . $data['strokecolor'] . '" -font "' . $data['font'] . '" -gravity ' . $data['align'] . '  -pointsize 32 label:"' . $data['text_val'] . '" -trim ' . $textDir . $imagename);
                }
            
                $resImage = $texturl . $imagename;
            }
        }
        $resultArray['img'] = $resImage;
        list($resultArray['width'],$resultArray['height']) = getimagesize(str_replace(Mage::getBaseUrl('media'), Mage::getBaseDir('media').'/', $resImage));
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($resultArray));        
    }

    // image upload process
    public function uploadAction() {
        if (isset($_FILES['Filedata']['name']) && $_FILES['Filedata']['name'] != '') {
            $this->_fileExt = $this->getFileExt($_FILES['Filedata']['name']);
            $this->_file_type = $_FILES['Filedata']['type'];
            $this->_file_size = $_FILES['Filedata']['size'];
            $this->_fileName = $_FILES['Filedata']['name'];
            $this->_file_tmp = $_FILES['Filedata']['tmp_name'];
            $this->_imagemagickpath = Mage::getStoreConfig('designertool/imagemagick_info/image_magick_path');//'/usr/bin/convert';

            $extension = array("pjpeg", "jpeg", "jpg", "x-png", "png", "bmp", "pdf", "eps", "tif", "svg", "gif", "PJPEG", "JPEG", "JPG", "X-PNG", "PNG", "BMP","PDF","EPS","TIF", "SVG", "GIF");
            $this->imagecounter = 0;
            if ($this->getFilesize($this->_file_size) <= 20) { 
                try { 
                    /* Starting upload */
                    $uploader = new Varien_File_Uploader('Filedata');

                    // Any extention would work
                    $uploader->setAllowedExtensions($extension);
                    $uploader->setAllowRenameFiles(false);

                    // Set the file upload mode 
                    // false -> get the file directly in the specified folder
                    // true -> get the file in the product like folders 
                    //	(file.jpg will go in something like /media/f/i/file.jpg)
                    $uploader->setFilesDispersion(false);
                    // We set media as the upload dir
                    $path = Mage::getBaseDir('media') . DS .'designertool'.DS.'userImages'.DS.'original'.DS;
                    // we set random file name with prefix upload
                    $filename = uniqid('Upload_').'.'.strtolower($this->_fileExt);
                    $uploader->save($path, $filename);
                    
                    //for pdf
                    if($this->_fileExt == "pdf" || $this->_fileExt == "PDF"){
                        $pdf_filename = $this->convertPdfToImage($path.$filename,$this->_fileExt);                       
                        list($width, $height) = getimagesize($pdf_filename);
                        if ($width >= 50 || $height >= 50) {
                            $this->getThumbsizeImage($pdf_filename);
                            $this->getLargesizeImage($pdf_filename);
                        }else{
                            $this->status = 0;
                            $this->errormessage = $this->getFilesizeMessage();
                        }
                        $this->imagecounter++;
                    }
                    
                    //for eps & tif
                    if($this->_fileExt == "eps" || $this->_fileExt == "EPS" || $this->_fileExt == "tif" || $this->_fileExt == "TIF"){
                        $eps_filename = $this->convertEpsTifToImage($path.$filename,$this->_fileExt);
                        list($width, $height) = getimagesize($eps_filename);
                        if ($width >= 50 || $height >= 50) {
                            $this->getThumbsizeImage($eps_filename);
                            $this->getLargesizeImage($eps_filename);
                        }else{
                            $this->status = 0;
                            $this->errormessage = $this->getFilesizeMessage();
                        }
                        $this->imagecounter++;
                    }
                    
                    //for svg
                    if($this->_fileExt == "svg" || $this->_fileExt == "SVG"){
                        $svg_filename = $this->convertSvgToImage($path.$filename,$this->_fileExt);
                        list($width, $height) = getimagesize($svg_filename);
                        if ($width >= 50 || $height >= 50) {
                            $this->getThumbsizeImage($svg_filename);
                            $this->getLargesizeImage($svg_filename);
                        }else{
                            $this->status = 0;
                            $this->errormessage = $this->getFilesizeMessage();
                        }
                        $this->imagecounter++;
                    }
                    
                    if($this->imagecounter == 0){
                        list($width, $height) = getimagesize($path.$filename);
                         if ($width >= 50 || $height >= 50) {
                            $this->getThumbsizeImage($path.$filename);
                            $this->getLargesizeImage($path.$filename);
                        }else{
                            $this->status = 0;
                            $this->errormessage = $this->getFilesizeMessage();
                        }
                    }
                    
                } catch (Exception $ex) {
                    $this->status = 0;
                    $this->errormessage = sprintf($this->getExtensionMessage(),'.'.$this->_fileExt);
                }
            }else{
                $this->status = 0;
                $this->errormessage = $this->getUploadlimitMessage();
            }
        }
        
        if($this->errormessage ==''){
            $returnarray = array('status'=>1,'url'=>$this->thumbimageurl);
        }else{
            $returnarray = array('status'=>$this->status,'message'=>$this->errormessage);
        }
        
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($returnarray));
    }
    
    // convert pdf to image
    private function convertPdfToImage($filename,$file_ext){
      $newfile = str_replace(strtolower($file_ext),'png',$filename);
        exec($this->_imagemagickpath . "  -density 96 -depth 8 -quality 85  $filename PNG32:$newfile");
        return $newfile;
    }
    
    
    // convert pdf to image
    private function convertEpsTifToImage($filename,$file_ext){
      $newfile = str_replace(strtolower($file_ext),'png',$filename);
        exec($this->_imagemagickpath . "  -density 300 -channel RGBA -colorspace RGB -background none -fill none -dither None  $filename $newfile");
        return $newfile;
    }
    
    // convert svg to image
    private function convertSvgToImage($filename,$file_ext){
      $newfile = str_replace(strtolower($file_ext),'png',$filename);
      exec($this->_imagemagickpath . " -background none  $filename PNG32: $newfile");
      return $newfile;
    }

    // get aspect ratio of image
    public function getImageRatio($ratioW, $ratioH, $imgPath) {
        $imageRatio = '';
        list($width, $height) = @(getimagesize($imgPath));
        if ($width > $ratioW && $height > $ratioH) {
            $imageRatio = $ratioW . 'x' . $ratioH;
        } else if ($width < $ratioW && $height > $ratioH) {
            $imageRatio = 'x' . $ratioH;
        } else if ($width > $ratioW && $height < $ratioH) {
            $imageRatio = $ratioW . 'x';
        } else {
            $imageRatio = $width . 'x' . $height;
        }
        return $imageRatio;
    }

    // get file extension
    private function getFileExt($fileName) {
        $explFile = explode('.', $fileName);
        $countExpFile = count($explFile);
        $countVal = $countExpFile - 1;
        return $explFile[$countVal];
    }

    // get valid size
    private function getFilesize($filesize) {
        return round($filesize / (1024*1024));
    }
    
    // create thumb size image as defined in config    
    private function getThumbsizeImage($filename){
        $thumbwidth = Mage::getStoreConfig('designertool/uploadimage_info/thumb_width');
        $thumbHeight = Mage::getStoreConfig('designertool/uploadimage_info/thumb_height');
        $usrImgThumb = str_replace('/original/','/thumb/',$filename);
        $thumbsize = $this->getImageRatio($thumbwidth, $thumbHeight, $filename);
        exec($this->_imagemagickpath . " $filename -thumbnail $thumbsize $usrImgThumb");
        $this->thumbimageurl = str_replace(Mage::getBaseDir('media'),Mage::getBaseUrl('media'),$usrImgThumb);
    }
    
    // create large size image as defined in config
    private function getLargesizeImage($filename){
        $largewidth = Mage::getStoreConfig('designertool/uploadimage_info/large_width');
        $largeHeight = Mage::getStoreConfig('designertool/uploadimage_info/large_height');
        $usrImglarge = str_replace('/original/','/large/',$filename);
        $thumbsize = $this->getImageRatio($largewidth, $largeHeight, $filename);
        exec($this->_imagemagickpath . " $filename -thumbnail $thumbsize $usrImglarge");
        $this->largeimageurl = str_replace(Mage::getBaseDir('media'),Mage::getBaseUrl('media'),$usrImglarge);
    }
    
    // filesize error message 
    private function getFilesizeMessage(){
        return Mage::getStoreConfig('designertool/errormessage_info/filesize_error_message');
    }
    
    // extension error message 
    private function getExtensionMessage(){
        return Mage::getStoreConfig('designertool/errormessage_info/extension_error_message');
    }
    
    // upload limit message
    private function getUploadlimitMessage(){
        return Mage::getStoreConfig('designertool/errormessage_info/error_message_size');
    }
}
