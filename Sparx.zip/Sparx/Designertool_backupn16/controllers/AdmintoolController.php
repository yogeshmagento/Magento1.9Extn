<?php

class Sparx_Designertool_AdmintoolController extends Mage_Core_Controller_Front_Action {

    public function saveAction() {
        $data = $this->getRequest()->getPost();
        //echo "<pre>"; print_r($data); exit;
        $toolModel = Mage::getModel('designertool/designertool');
        $tooldata['canvas_array'] = $data['canvasArr'];
        $tooldata['canvas_width'] = $data['canvasWidth'];
        $tooldata['canvas_height'] = $data['canvasHeight'];
        $tooldata['data_array'] = json_encode($data['dataArray']);
        $tooldata['material_size_id'] = (int) $data['materialSizeId'];
        $tooldata['material_id'] = (int) $data['materialId'];
        $tooldata['created_by'] = 'Admin';
        $tooldata['product_id'] = $data['productId'];
        
        if ($data['prevImg']) {
            Mage::helper('designertool')->removePrevImg($data['prevImg']); // remove previous image
        }

        if ($data['previewImg']) {
            $designImg = Mage::helper('designertool')->createDesignimage($data['previewImg']);
            $tooldata['filename'] = $designImg;
        }
        $fullpath = Mage::getBaseDir('media') . '/designertool/designImage/' . $designImg;

        $toolModel->setData($tooldata);

        if (!empty($data['designId']))
            $toolModel->setId($data['designId']);

        $toolModel->save();

        // Remove images
        Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID);
        $productId=$data['productId'];

        $mediaApi = Mage::getModel("catalog/product_attribute_media_api");
            $items = $mediaApi->items($productId);
            foreach ($items as $item) {
                $mediaApi->remove($productId, $item['file']);
            }

        // Add New Images
        $product = Mage::getModel('catalog/product')->load($productId);
        // Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID); //for Set it to all Store view
        $product->setMediaGallery(array('images' => array(), 'values' => array()));
        $mode = array('thumbnail', 'small_image', 'image');
        $product->addImageToMediaGallery($fullpath, $mode, false, false);
        Mage::app()->setCurrentStore(Mage_Core_Model_App::ADMIN_STORE_ID);
        $product->save();

        if ($toolModel->getId())
            $this->getResponse()->setBody(json_encode (array('action'=>'success')));
    }

    private function setDefaultImage($productId, $media_array = array()) {
        $product = Mage::getModel('catalog/product')->load($productId);
        if (!empty($media_array)) {
            
        }
    }

    public function editAction() {
        $designId = $this->getRequest()->getPost('designId');
        //echo "<pre>"; print_r($designId); exit;
        $designdata = Mage::helper('designertool')->retriveDesigndata($designId);
        $this->getResponse()->setBody(json_encode($designdata));
    }

}
