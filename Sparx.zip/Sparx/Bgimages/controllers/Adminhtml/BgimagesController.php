<?php

class Sparx_Bgimages_Adminhtml_BgimagesController extends Mage_Adminhtml_Controller_action {

    protected function _isAllowed() {
        return Mage::getSingleton('admin/session')->isAllowed('designersoftware/bgimages');
    }

    protected function _initAction() {
        $this->loadLayout()
                ->_setActiveMenu('designertool/items')
                ->_addBreadcrumb(Mage::helper('adminhtml')->__('Background Images '), Mage::helper('adminhtml')->__('Background Images '));

        return $this;
    }

    public function indexAction() {
        $this->_initAction()
                ->renderLayout();
    }

    public function editAction() {
        $id = $this->getRequest()->getParam('id');
        $model = Mage::getModel('bgimages/bgimages')->load($id);

        if ($model->getId() || $id == 0) {
            $data = Mage::getSingleton('adminhtml/session')->getFormData(true);
            if (!empty($data)) {
                $model->setData($data);
            }

            if (!empty($model['banner_path'])) {
                $model['banner_path'] = json_decode($model['banner_path']);
            }

            Mage::register('bgimages_data', $model);

            $this->loadLayout();
            $this->_setActiveMenu('designertool/items');

            $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Background Images '), Mage::helper('adminhtml')->__('Background Images '));
            $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Background Images '), Mage::helper('adminhtml')->__('Background Images '));

            $this->getLayout()->getBlock('head')->setCanLoadExtJs(true);

            $this->_addContent($this->getLayout()->createBlock('bgimages/adminhtml_bgimages_edit'))
                    ->_addLeft($this->getLayout()->createBlock('bgimages/adminhtml_bgimages_edit_tabs'));

            $this->renderLayout();
        } else {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('bgimages')->__('Background Images does not exist'));
            $this->_redirect('*/*/');
        }
    }

    public function newAction() {
        $this->_forward('edit');
    }

    public function saveAction() {

        $deleteArray = array();
        $jsonPath = array();
        $spath = array();
        $toDelete = array();
        $allpath = array();
        if ($data = $this->getRequest()->getPost()) {
            $existImageId = $this->getExistsImage($data);


            $model = Mage::getModel('bgimages/bgimages');
            $model->setData($data);

            if ($existImageId > 0):
                $model->setId($existImageId);
            else:
                $model->setId($this->getRequest()->getParam('id'));
            endif;

            try {
                if ($model->getCreatedTime() == NULL || $model->getUpdateTime() == NULL) {
                    $model->setCreatedTime(now())
                            ->setUpdateTime(now());
                } else {
                    $model->setUpdateTime(now());
                }

                $model->save();

                if ($model->getId() > 0) {
                    $deleteBanner = $data ['bannerdelete'];
                    foreach ($deleteBanner as $key => $val) {
                        $toDelete[] = $key;
                    }
                    $model = Mage::getModel('bgimages/bgimages')->load($model->getId());
                    if (!empty($model->getFilename())) {
                        $jsonPath = json_decode($model->getFilename());
                    }

                    if (isset($_FILES['banner']['name']) && $_FILES['banner']['name'] !== '') {
                        $file_array = $this->reArrayFiles($_FILES['banner']);

                        foreach ($file_array as $file) {
                            if ($file['name'] != NULL) {
                                $filePath = $this->uploadBgImages($file);
                                if (isset($filePath) && $filePath !== NULL) {

                                    $originalImage = Mage::getBaseDir('media') . DS . 'files/bgimages/original/' . $filePath;
                                    // thumb image
                                    mkdir(Mage::getBaseDir('media') . DS . 'files/bgimages/thumb/', 0777, true);
                                    $thumbImage = str_replace('/original/', '/thumb/', $originalImage);
                                    Mage::helper('designertool/data')->resizeImages($originalImage, $thumbImage, 150, 150);
                                    // large image
                                    mkdir(Mage::getBaseDir('media') . DS . 'files/bgimages/large/', 0777, true);
                                    $largeImage = str_replace('/original/', '/large/', $originalImage);
                                    Mage::helper('designertool/data')->resizeImages($originalImage, $largeImage, 1000, 1000);
                                    
                                    // for rotate
                                   // mkdir(Mage::getBaseDir('media') . DS . 'files/bgimages/rotate/', 0777, true);
                                  //  $rotateImage = str_replace('/large/', '/rotate/', $largeImage);
                                   // $imageMagickPath= Mage::getStoreConfig('designertool/imagemagick_info/image_magick_path');
                                  //  exec('"'.$imageMagickPath.'" "'.$largeImage.'" -rotate 90 "'.$rotateImage.'"');


                                    $path[] = $filePath;
                                }
                            }
                        }
                        if (count($path) > 0):
                            $spath = $path;
                        endif;
                    }



                    $finalArr = array_merge($spath, $jsonPath);
                    $finalArr = array_diff($finalArr, $toDelete);
                    if (empty($spath) && empty($toDelete)) {
                        $finalArr = $jsonPath;
                    }

                    $collArr = array_values($finalArr);
                    $allpath = (count($collArr) > 0) ? json_encode($collArr) : '';
                    $model->setFilename($allpath)->save();
                }

                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('bgimages')->__('Background Images was successfully saved'));
                Mage::getSingleton('adminhtml/session')->setFormData(false);

                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', array('id' => $model->getId()));
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                Mage::getSingleton('adminhtml/session')->setFormData($data);
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('bgimages')->__('Unable to find background images to save'));
        $this->_redirect('*/*/');
    }

    public function deleteAction() {
        if ($this->getRequest()->getParam('id') > 0) {
            try {
                $model = Mage::getModel('bgimages/bgimages');

                $model->setId($this->getRequest()->getParam('id'))
                        ->delete();

                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Background Images was successfully deleted'));
                $this->_redirect('*/*/');
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
            }
        }
        $this->_redirect('*/*/');
    }

    /**
     * Rearrange $_Files for multiple images
     * @param type $file_post
     * @return array
     */
    protected function reArrayFiles(&$file_post) {
        $i = 0;
        $file_ary = array();
        foreach ($file_post['name'] as $key => $value) {
            $file_ary[$i]['name'] = $value;
            $file_ary[$i]['type'] = $file_post['type'][$key];
            $file_ary[$i]['tmp_name'] = $file_post['tmp_name'][$key];
            $file_ary[$i]['error'] = $file_post['error'][$key];
            $file_ary[$i]['size'] = $file_post['size'][$key];
            $i++;
        }
        return $file_ary;
    }

    /**
     * Upload banner images for kiosk user
     * @param type $file
     * @return string
     */
    protected function uploadBgImages($file) {
        try {
            $uploader = new Varien_File_Uploader($file);
            $uploader->setAllowedExtensions(array('jpg', 'jpeg', 'gif', 'png'));
            $uploader->setAllowRenameFiles(false);
            $uploader->setFilesDispersion(false);
            // Set media as the upload dir
            $media_path = Mage::getBaseDir('media') . DS . 'files/bgimages/original';
            $filename = uniqid('bg_') . time() . rand(1, 100) . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
            // Upload the image
            if ($uploader->save($media_path, $filename)) {
                return $filename;
            }
        } catch (Exception $e) {
            Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
        }
    }

    private function getExistsImage($data) {
        $bgimages_id = 0;
        $model = Mage::getModel('bgimages/bgimages')->getCollection()
                        ->addFieldToFilter('bg_category_id', $data['bg_category_id'])
                        ->getFirstItem()->getData();
        if (count($model) > 0):
            $bgimages_id = $model['bgimages_id'];
        endif;
        return $bgimages_id;
    }

    public function massDeleteAction() {
        $bgimagesIds = $this->getRequest()->getParam('bgimages');
        if (!is_array($bgimagesIds)) {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Please select background image(s)'));
        } else {
            try {
                foreach ($bgimagesIds as $bgimagesId) {
                    $bgimages = Mage::getModel('bgimages/bgimages')->load($bgimagesId);
                    $bgimages->delete();
                }
                Mage::getSingleton('adminhtml/session')->addSuccess(
                        Mage::helper('adminhtml')->__(
                                'Total of %d record(s) were successfully deleted', count($bgimagesIds)
                        )
                );
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }

    public function massStatusAction() {
        $bgimagesIds = $this->getRequest()->getParam('bgimages');
        if (!is_array($bgimagesIds)) {
            Mage::getSingleton('adminhtml/session')->addError($this->__('Please select background image(s)'));
        } else {
            try {
                foreach ($bgimagesIds as $bgimagesId) {
                    $bgimages = Mage::getSingleton('bgimages/bgimages')
                            ->load($bgimagesId)
                            ->setStatus($this->getRequest()->getParam('status'))
                            ->setIsMassupdate(true)
                            ->save();
                }
                $this->_getSession()->addSuccess(
                        $this->__('Total of %d record(s) were successfully updated', count($bgimagesIds))
                );
            } catch (Exception $e) {
                $this->_getSession()->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }

    public function exportCsvAction() {
        $fileName = 'bgimages.csv';
        $content = $this->getLayout()->createBlock('bgimages/adminhtml_bgimages_grid')
                ->getCsv();

        $this->_sendUploadResponse($fileName, $content);
    }

    public function exportXmlAction() {
        $fileName = 'bgimages.xml';
        $content = $this->getLayout()->createBlock('bgimages/adminhtml_bgimages_grid')
                ->getXml();

        $this->_sendUploadResponse($fileName, $content);
    }

    protected function _sendUploadResponse($fileName, $content, $contentType = 'application/octet-stream') {
        $response = $this->getResponse();
        $response->setHeader('HTTP/1.1 200 OK', '');
        $response->setHeader('Pragma', 'public', true);
        $response->setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0', true);
        $response->setHeader('Content-Disposition', 'attachment; filename=' . $fileName);
        $response->setHeader('Last-Modified', date('r'));
        $response->setHeader('Accept-Ranges', 'bytes');
        $response->setHeader('Content-Length', strlen($content));
        $response->setHeader('Content-type', $contentType);
        $response->setBody($content);
        $response->sendResponse();
        die;
    }

}
