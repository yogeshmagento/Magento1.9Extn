<?php

class Sparx_Bgimages_Model_Bgimages extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('bgimages/bgimages');
    }
}