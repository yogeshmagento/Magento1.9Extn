<?php

class Sparx_Bgimages_Model_Mysql4_Bgimagescoll extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the bgimages_id refers to the key field in your database table.
        $this->_init('bgimages/bgimagescoll', 'bgimagescoll_id');
    }
}