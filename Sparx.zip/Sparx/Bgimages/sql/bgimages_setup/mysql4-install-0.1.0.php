<?php

$installer = $this;

$installer->startSetup();

$installer->run("

-- DROP TABLE IF EXISTS {$this->getTable('sparx_bgimages')};
CREATE TABLE {$this->getTable('sparx_bgimages')} (
  `bgimages_id` int(11) unsigned NOT NULL auto_increment,
  `bg_category_id` int(11) unsigned NOT NULL,
  `filename` longtext NOT NULL default '',
  `status` smallint(6) NOT NULL default '0',
  `created_time` datetime NULL,
  `update_time` datetime NULL,
  PRIMARY KEY (`bgimages_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    ");

$installer->endSetup(); 

