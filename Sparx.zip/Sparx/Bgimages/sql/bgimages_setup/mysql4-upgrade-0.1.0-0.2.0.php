<?php

$installer = Mage::getResourceModel('catalog/setup', 'catalog_setup');

$installer->startSetup();

$installer->addAttribute('catalog_product', "designertool_bg_categories", array(
    'type' => 'int',
    'input' => 'select',
    'label' => 'Designertool BG Categories',
    'source' => '',
    'sort_order' => 1000,
    'visible' => 1,
    'required' => 0,
    'user_defined' => 1,
    'global' => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
    'is_configurable' => 0,
    'backend' => 'eav/entity_attribute_backend_array',
    'option' => array(
        'values' => array(
            0 => 'Category 1',
            1 => 'Category 2',
            2 => 'Category 3',
        )
    ),
));

$installer->endSetup();

