<?php
class Sparx_Bgimages_Block_Adminhtml_Bgimages extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_bgimages';
    $this->_blockGroup = 'bgimages';
    $this->_headerText = Mage::helper('bgimages')->__('Background Images');
    $this->_addButtonLabel = Mage::helper('bgimages')->__('Add Images');
    parent::__construct();
  }
}