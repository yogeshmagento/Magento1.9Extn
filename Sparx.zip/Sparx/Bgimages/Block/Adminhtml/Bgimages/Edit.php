<?php

class Sparx_Bgimages_Block_Adminhtml_Bgimages_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'bgimages';
        $this->_controller = 'adminhtml_bgimages';
        
        $this->_updateButton('save', 'label', Mage::helper('bgimages')->__('Save Images'));
        $this->_updateButton('delete', 'label', Mage::helper('bgimages')->__('Delete Images'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('bgimages_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'bgimages_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'bgimages_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('bgimages_data') && Mage::registry('bgimages_data')->getId() ) {
            return Mage::helper('bgimages')->__("Edit Images '%s'", $this->htmlEscape(Mage::registry('bgimages_data')->getTitle()));
        } else {
            return Mage::helper('bgimages')->__('Add Images');
        }
    }
}