<?php

class Sparx_Bgimages_Block_Adminhtml_Bgimages_Edit_Tab_Image extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm() {
        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset('bgimages_form', array('legend' => Mage::helper('bgimages')->__('Background Images')));

        $banner = $fieldset->addField("banner[\${j}]", "imageset", array(
            "label" => Mage::helper("bgimages")->__("Background Image"),
            "name" => "banner[\${j}]",
            "imageset" => json_decode(Mage::registry('bgimages_data')->getFilename()),
            "hname" => "banner"
        ));

        $banner->setAfterElementHtml("<script type=\"text/javascript\">
            var banner = (document.getElementById(\"banner[\${j}]\").parentNode.parentNode.parentNode);
            var newJob = document.createElement(\"tr\");
            newJob.innerHTML = '<td></td><td><button type=\"button\" style=\"float:right\" class=\"scalable add\" id=\"add-banner\" onclick=cloneNewBanner()>Add Background Image</button></td>';
            banner.appendChild(newJob);
            var count = 0;
            function cloneNewBanner(){
                var itm = document.getElementById(\"banner[\${j}]\");
                var clone = itm.cloneNode(true);
                clone.setAttribute('name','banner['+count+']');
                clone.setAttribute('id','banner['+count+']');
                count++;
                itm.parentNode.appendChild(clone);
            }
            </script>");

        if (Mage::getSingleton('adminhtml/session')->getBgimagesData()) {
            $form->setValues(Mage::getSingleton('adminhtml/session')->getBgimagesData());
            Mage::getSingleton('adminhtml/session')->setBgimagesData(null);
        } elseif (Mage::registry('bgimages_data')) {
            $form->setValues(Mage::registry('bgimages_data')->getData());
        }
        return parent::_prepareForm();
    }

}
