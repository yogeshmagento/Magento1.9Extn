<?php

class Sparx_Bgimages_Block_Adminhtml_Bgimages_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm() {
        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset('bgimages_form', array('legend' => Mage::helper('bgimages')->__('Background Images')));

        $fieldset->addField('bg_category_id', 'select', array(
            'label' => Mage::helper('bgimages')->__('Categories'),
            'class' => 'required-entry',
            'required' => true,
            'name' => 'bg_category_id',
            'values' => Mage::helper('designertool/data')->getDropDownValues('designertool_bg_categories'),
        ));

        $fieldset->addField('status', 'select', array(
            'label' => Mage::helper('bgimages')->__('Status'),
            'name' => 'status',
            'values' => array(
                array(
                    'value' => 1,
                    'label' => Mage::helper('bgimages')->__('Enabled'),
                ),
                array(
                    'value' => 2,
                    'label' => Mage::helper('bgimages')->__('Disabled'),
                ),
            ),
        ));

        if (Mage::getSingleton('adminhtml/session')->getBgimagesData()) {
            $form->setValues(Mage::getSingleton('adminhtml/session')->getBgimagesData());
            Mage::getSingleton('adminhtml/session')->setBgimagesData(null);
        } elseif (Mage::registry('bgimages_data')) {
            $form->setValues(Mage::registry('bgimages_data')->getData());
        }
        return parent::_prepareForm();
    }

}
