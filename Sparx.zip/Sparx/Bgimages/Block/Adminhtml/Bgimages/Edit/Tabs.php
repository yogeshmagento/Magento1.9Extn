<?php

class Sparx_Bgimages_Block_Adminhtml_Bgimages_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs {

    public function __construct() {
        parent::__construct();
        $this->setId('bgimages_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(Mage::helper('bgimages')->__('Background Images'));
    }

    protected function _beforeToHtml() {
        $this->addTab('form_section', array(
            'label' => Mage::helper('bgimages')->__('Background Information'),
            'title' => Mage::helper('bgimages')->__('Background Information'),
            'content' => $this->getLayout()->createBlock('bgimages/adminhtml_bgimages_edit_tab_form')->toHtml(),
        ));

//        if ($this->getRequest()->getParam('id') > 0) {
            $this->addTab('image_section', array(
                'label' => Mage::helper('bgimages')->__('Background Image'),
                'title' => Mage::helper('bgimages')->__('Background Image'),
                'content' => $this->getLayout()->createBlock('bgimages/adminhtml_bgimages_edit_tab_image')->toHtml(),
            ));
//        }

        return parent::_beforeToHtml();
    }

}
