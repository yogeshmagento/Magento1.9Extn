<style>
    .overlay_display_block{
        display: block;
    }
    .overlay_display_none{
        display: none;
    }
    .overlay_display{
        display: none;
    }
</style>
<?php

class Sparx_Bgimages_Block_Adminhtml_Bgimages_Renderer_Bgimages extends Mage_Adminhtml_Block_Abstract implements Varien_Data_Form_Element_Renderer_Interface {

    public function render(Varien_Data_Form_Element_Abstract $element) {
        $bgimage_id = $this->getRequest()->getParam('id');

        $bgData = Mage::registry('bgimages_data')->getData();
        $cardTypeId = $bgData['card_type_id'];

        // Get bg images collection
        $bgImagesColl = Mage::getModel('bgimages/bgimagescoll')->getCollection()->addFieldToFilter('bgimages_id', $bgimage_id)->getData();
        $html = '<td class="grid tier" colspan="10">
    <table cellspacing="0" id="tiers_table" class="data border">
                <colgroup><col width="120">
        <col width="95">
        <col>
        <col width="1">
        </colgroup><thead>
            <tr class="headings">               
                <th>BG Image</th>
                <th class="overlay_display">BG Overlay Image</th>
                <th class="last">Action</th>
            </tr>
        </thead>
        <tbody id="other_info_container"></tbody>
        <tfoot>
            <tr>
                <td style="display:none"></td>
                <td class="a-right" colspan="4"><button style="" onclick="return otherinfo.addItem()" class="scalable add" type="button" title="Add Tier" id="id_ab2c2c8ddd9a30c25852bd79152843f3"><span><span><span>Add Information</span></span></span></button></td>
            </tr>
        </tfoot>
    </table>
</td>';
        echo $html;
        ?>
        <script >
            var otherInfoRowTemplate = '<tr>'
                    + '<td><input type="file" name="bg[image][{{index}}]">'
                    + '<img id="bg_image_{{index}}_img" src="{{imgsrc}}" width="40" height="20" style="display:none;margin-left:5px;"/></td>'
                    + '<td class="overlay_display"><input type="file" name="bg[overlay][{{index}}]">'
                    + '<img id="bg_overlay_{{index}}_img" src="{{overlaysrc}}" width="40" height="20" style="display:none;margin-left:5px;"/></td>'
                    + '<td class="last"><input type="hidden" name="bg_delete[{{index}}]" class="delete" value="" id="bg_delete[{{index}}]" />'
                    + '<input type="hidden" name="edit_image[{{index}}]" class="edit_image" value="" id="edit_image_{{index}}" />'
                    + '<button title="Delete Info" type="button" class="scalable delete icon-btn delete-product-option" id="other_info_row_{{index}}_delete_button" onclick="return otherinfo.deleteItem(event);">'
                    + '<span><span><span>Delete</span></span></span></button></td>'
                    + '</tr>';


            var otherinfo = {
                template: new Template(otherInfoRowTemplate, new RegExp('(^|.|\\r|\\n)({{\\s*(\\w+)\\s*}})', "")),
                itemsCount: 0,
                addItem: function() {
                    var data = {
                        imgsrc: '',
                        overlaysrc: '',
                        index: this.itemsCount++
                    };


                    if (arguments.length > 0) {
                        data.imgsrc = arguments[0];
                        data.overlaysrc = arguments[1];
                    }

                    Element.insert($('other_info_container'), {
                        bottom: this.template.evaluate(data)
                    });
                    var checkExistRow = $('other_info_container').childElements();
                    //if (checkExistRow.length == 1) {
                    if (($('card_type_id').getValue() == 12 || $('card_type_id').getValue() == 1) && checkExistRow.length >= 1) {
                        Element.select('tr', '.overlay_display').each(function(elem) {
                            elem.removeClassName('overlay_display');
                            elem.addClassName('overlay_display_block');
                        });
                    }
                    //}


                    if (data.imgsrc) {
                        $('bg_image_' + data.index + '_img').show();
                    }
                    if (data.overlaysrc) {
                        $('bg_overlay_' + data.index + '_img').show();
                    }
                    if (arguments[2] > 0) {
                        $('edit_image_' + data.index).writeAttribute('value', arguments[2]);
                    }

                },
                deleteItem: function(event) {
                    var tr = Event.findElement(event, 'tr');
                    if (tr) {
                        var editDeleted = 0;
                        Element.select(tr, '.edit_image').each(function(elem) {
                            editDeleted = elem.value;
                        });

                        Element.select(tr, '.delete').each(function(elem) {
                            elem.value = editDeleted > 0 ? editDeleted : 0;
                        });

                        Element.select(tr, ['input', 'select']).each(function(elem) {
                            elem.hide()
                        });
                        Element.hide(tr);
                        Element.addClassName(tr, 'no-display template');
                    }
                    return false;
                }
            };
        <?php
        if (!empty($bgImagesColl)) {
            foreach ($bgImagesColl as $imagesInfo) {
                ?>
                    otherinfo.addItem('<?php echo Mage::getBaseUrl('media'); ?>files/bgimages/<?php echo $imagesInfo['filename']; ?>', '<?php echo Mage::getBaseUrl('media'); ?>files/bgimages/<?php echo $imagesInfo['overlay']; ?>', '<?php echo $imagesInfo['bgimagescoll_id']; ?>');
                <?php
            }
        }
        ?>
                var editCardTypeId = "<?php echo $cardTypeId; ?>";
                if (editCardTypeId == 12 || editCardTypeId == 1) {
                    Element.select('tr', '.overlay_display').each(function(elem) {
                        elem.removeClassName('overlay_display');
                        elem.addClassName('overlay_display_block');
                    });
                }
        </script>
        <?php
    }

}
?>