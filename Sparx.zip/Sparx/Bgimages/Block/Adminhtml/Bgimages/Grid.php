<?php

class Sparx_Bgimages_Block_Adminhtml_Bgimages_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('bgimagesGrid');
      $this->setDefaultSort('bgimages_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('bgimages/bgimages')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }
  
  protected function _prepareColumns()
  {
      $this->addColumn('bgimages_id', array(
          'header'    => Mage::helper('bgimages')->__('ID'),
          'align'     =>'right',
          'width'     => '50px',
          'index'     => 'bgimages_id',
      ));
 
      $this->addColumn('bg_category_id', array(
          'header'    => Mage::helper('bgimages')->__('Categories'),
          'align'     =>'left',
          'index'     => 'bg_category_id',
          'type'      => 'options',
          'options'   => Mage::helper('designertool/data')->getDropDownValues('designertool_bg_categories'),          
      ));

      $this->addColumn('status', array(
          'header'    => Mage::helper('bgimages')->__('Status'),
          'align'     => 'left',
          'width'     => '80px',
          'index'     => 'status',
          'type'      => 'options',
          'options'   => array(
              1 => 'Enabled',
              2 => 'Disabled',
          ),
      ));
	  
        $this->addColumn('action',
            array(
                'header'    =>  Mage::helper('bgimages')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('bgimages')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
		
		$this->addExportType('*/*/exportCsv', Mage::helper('bgimages')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('bgimages')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('bgimages_id');
        $this->getMassactionBlock()->setFormFieldName('bgimages');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'    => Mage::helper('bgimages')->__('Delete'),
             'url'      => $this->getUrl('*/*/massDelete'),
             'confirm'  => Mage::helper('bgimages')->__('Are you sure?')
        ));

        $statuses = Mage::getSingleton('bgimages/status')->getOptionArray();

        array_unshift($statuses, array('label'=>'', 'value'=>''));
        $this->getMassactionBlock()->addItem('status', array(
             'label'=> Mage::helper('bgimages')->__('Change status'),
             'url'  => $this->getUrl('*/*/massStatus', array('_current'=>true)),
             'additional' => array(
                    'visibility' => array(
                         'name' => 'status',
                         'type' => 'select',
                         'class' => 'required-entry',
                         'label' => Mage::helper('bgimages')->__('Status'),
                         'values' => $statuses
                     )
             )
        ));
        return $this;
    }

  public function getRowUrl($row)
  {
      return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }

}
