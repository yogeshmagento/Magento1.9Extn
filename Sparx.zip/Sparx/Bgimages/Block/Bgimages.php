<?php
class Sparx_Bgimages_Block_Bgimages extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getBgimages()     
     { 
        if (!$this->hasData('bgimages')) {
            $this->setData('bgimages', Mage::registry('bgimages'));
        }
        return $this->getData('bgimages');
        
    }
}