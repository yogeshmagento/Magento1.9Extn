<?php

class Sparx_Bgimages_Helper_Data extends Mage_Core_Helper_Abstract {

    public function getConfigJson($field) {
        $this->getConfig()->setParams(
                array(
                    'form_key' => $this->getFormKey(),
                    "field" => $field
                )
        );
        $this->getConfig()->setFileField('Filedata');
        $this->getConfig()->setUrl(Mage::getModel('adminhtml/url')->addSessionParam()->getUrl("*/*/upload", array("param1" => "value1")));
        $this->getConfig()->setFilters(array(
            'pdf documents' => array(
                'label' => Mage::helper('adminhtml')->__('Portable Document Format (.pdf)'),
                'files' => array('*.jpg', '*.png', '*.jpeg', '*.gif')
            )
        ));
        return Mage::helper('core')->jsonEncode($this->getConfig()->getData());
    }

    public function getConfig() {
        if (is_null($this->_config)) {
            $this->_config = new Varien_Object();
        }

        return $this->_config;
    }

}
