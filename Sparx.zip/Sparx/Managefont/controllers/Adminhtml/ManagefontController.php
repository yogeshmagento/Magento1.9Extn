<?php

include('ycTIN_TTF.php');

class Sparx_Managefont_Adminhtml_ManagefontController extends Mage_Adminhtml_Controller_action {

    protected function _isAllowed() {
        return Mage::getSingleton('admin/session')->isAllowed('designertool/managefont');
    }

    protected function _initAction() {
        $this->loadLayout()
                ->_setActiveMenu('designersoftware/items')
                ->_addBreadcrumb(Mage::helper('adminhtml')->__('Manage Font'), Mage::helper('adminhtml')->__('Manage Font'));

        return $this;
    }

    public function indexAction() {
        $this->_initAction()
                ->renderLayout();
    }

    public function editAction() {
        $id = $this->getRequest()->getParam('id');
        $model = Mage::getModel('managefont/managefont')->load($id);

        if ($model->getId() || $id == 0) {
            $data = Mage::getSingleton('adminhtml/session')->getFormData(true);
            if (!empty($data)) {
                $model->setData($data);
            }

            Mage::register('managefont_data', $model);

            $this->loadLayout();
            $this->_setActiveMenu('designersoftware/items');

            $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Manage Font'), Mage::helper('adminhtml')->__('Manage Font'));
            $this->_addBreadcrumb(Mage::helper('adminhtml')->__('Font News'), Mage::helper('adminhtml')->__('Font News'));

            $this->getLayout()->getBlock('head')->setCanLoadExtJs(true);

            $this->_addContent($this->getLayout()->createBlock('managefont/adminhtml_managefont_edit'))
                    ->_addLeft($this->getLayout()->createBlock('managefont/adminhtml_managefont_edit_tabs'));

            $this->renderLayout();
        } else {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('managefont')->__('Font does not exist'));
            $this->_redirect('*/*/');
        }
    }

    public function newAction() {
        $this->_forward('edit');
    }

    public function checkFileEmpty($files) {
        $fontTypeArr = Mage::getModel('managefont/managefonttype')->getCollection()
                ->addFieldToFilter('status', array('eq' => 1))
                ->getData();
        $flag = 0;
        if (count($fontTypeArr) > 0) {
            foreach ($fontTypeArr as $fontValue) {
                $fontFileName = 'font_' . $fontValue['managefonttype_id'];
                if (isset($files[$fontFileName]['name']) && $files[$fontFileName]['name'] != '') {
                    $flag = 1;
                }
            }
        }
        return $flag;
    }

    public function saveAction() {
        if ($this->getRequest()->getParam('id') == '') {
            if ($this->checkFileEmpty($_FILES) == 0) {
                Mage::getSingleton('adminhtml/session')->addError(Mage::helper('managefont')->__('Please upload at least one file'));
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                return;
            }
        }

        if ($data = $this->getRequest()->getPost()) {
            $model = Mage::getModel('managefont/managefont');
            $model->setData($data)
                    ->setId($this->getRequest()->getParam('id'));

            try {
                if ($model->getCreatedTime == NULL || $model->getUpdateTime() == NULL) {
                    $model->setCreatedTime(now())
                            ->setUpdateTime(now());
                } else {
                    $model->setUpdateTime(now());
                }

                $model->save();

                $fontId = $model->getId();


                $fontTypeArr = Mage::getModel('managefont/managefonttype')->getCollection()
                        ->addFieldToFilter('status', array('eq' => 1))
                        ->getData();

                if (count($fontTypeArr) > 0) {
                    foreach ($fontTypeArr as $fontValue) {
                        $modelFontdesc = Mage::getModel('managefont/managefontdesc')->getCollection()
                                        ->addFieldToFilter('managefont_id', $fontId)
                                        ->addFieldToFilter('fonttype_id', $fontValue['managefonttype_id'])->getData();
                        if (count($modelFontdesc) > 0) {
                            $modelFontdesc = Mage::getModel('managefont/managefontdesc')->load($modelFontdesc[0]['managefontdesc_id']);
                        } else {
                            $modelFontdesc = Mage::getModel('managefont/managefontdesc');
                        }

                        $modelFontdesc->setManagefontId($fontId);
                        $modelFontdesc->setFonttypeId($fontValue['managefonttype_id']);
                        $modelFontdesc->setFonttypeCode($fontValue['fonttype_code']);


                        $fontFileName = 'font_' . $fontValue['managefonttype_id'];
                        $mediaPath = Mage::getBaseDir('media') . DS . 'designertool' . DS . 'font' . DS . 'ttf' . DS;
                        $ttfName = $this->uploadImages($_FILES[$fontFileName], $mediaPath);
                        if (!empty($ttfName)):
                            $png_image_name = str_replace(pathinfo($ttfName, PATHINFO_EXTENSION), 'png', $ttfName);
                            $queryTTF = new ycTIN_TTF(); //create yctin_ttf object
                            $imageFilePath = Mage::getBaseDir('media') . '/designertool/font/original/';
                            mkdir($imageFilePath, 0777, true);
                            $objFont = $queryTTF->generateFontImage($mediaPath . $ttfName, $ttfName, $imageFilePath . $png_image_name);

                            // set values
                            $modelFontdesc->setFontTtf($ttfName);
                            $modelFontdesc->setFonttypeImage($png_image_name);

                            // generations tcpdf files
                            $tcpdf_fonts = new TCPDF_TCPDF(PDF_PAGE_ORIENTATION, 'pt', '', true, 'UTF-8', false);
                            $tcpdfFontName = $tcpdf_fonts->addTTFfont($mediaPath . $_FILES[$fontFileName]['name']);
                            $modelFontdesc->setFontName($tcpdfFontName);
                            $modelFontdesc->save();
                        endif;
                    }
                }

                if ($fontId > 0) {
                    $model = Mage::getModel('managefont/managefont')->load($fontId);
                    $model->setTitle($objFont['fontStyle']);
                    $model->save();
                }

                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('managefont')->__('Font was successfully saved'));
                Mage::getSingleton('adminhtml/session')->setFormData(false);

                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', array('id' => $model->getId()));
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                Mage::getSingleton('adminhtml/session')->setFormData($data);
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError(Mage::helper('managefont')->__('Unable to find font to save'));
        $this->_redirect('*/*/');
    }

    private function uploadImages($file, $mediaPath) {
        $filename = '';
        if (!empty($file['name'])) {
            try {
                $uploader = new Varien_File_Uploader($file);
                //$uploader->setAllowedExtensions(array('jpg', 'jpeg', 'gif', 'png'));
                $uploader->setAllowRenameFiles(false);
                $uploader->setFilesDispersion(false);
                $fileExt = pathinfo($file['name'], PATHINFO_EXTENSION);

                $pos = strpos($file['name'], '.ctg.z');
                if ($pos !== false) {
                    $fileExt = 'ctg.z';
                }

                $filename = $file['name']; //uniqid('font_') . time() . rand(1, 100) . '.' . $fileExt;
                // Upload the image
                if ($uploader->save($mediaPath, $filename)) {
                    return $filename;
                }
            } catch (Exception $e) {
                Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
            }
        }
        return $filename;
    }

    public function deleteAction() {
        if ($this->getRequest()->getParam('id') > 0) {
            try {
                $model = Mage::getModel('managefont/managefont');

                $model->setId($this->getRequest()->getParam('id'))
                        ->delete();

                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Font was successfully deleted'));
                $this->_redirect('*/*/');
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
            }
        }
        $this->_redirect('*/*/');
    }

    public function massDeleteAction() {
        $managefontIds = $this->getRequest()->getParam('managefont');
        if (!is_array($managefontIds)) {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Please select font(s)'));
        } else {
            try {
                foreach ($managefontIds as $managefontId) {
                    $managefont = Mage::getModel('managefont/managefont')->load($managefontId);
                    $managefont->delete();
                }
                Mage::getSingleton('adminhtml/session')->addSuccess(
                        Mage::helper('adminhtml')->__(
                                'Total of %d record(s) were successfully deleted', count($managefontIds)
                        )
                );
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }

    public function massStatusAction() {
        $managefontIds = $this->getRequest()->getParam('managefont');
        if (!is_array($managefontIds)) {
            Mage::getSingleton('adminhtml/session')->addError($this->__('Please select font(s)'));
        } else {
            try {
                foreach ($managefontIds as $managefontId) {
                    $managefont = Mage::getSingleton('managefont/managefont')
                            ->load($managefontId)
                            ->setStatus($this->getRequest()->getParam('status'))
                            ->setIsMassupdate(true)
                            ->save();
                }
                $this->_getSession()->addSuccess(
                        $this->__('Total of %d record(s) were successfully updated', count($managefontIds))
                );
            } catch (Exception $e) {
                $this->_getSession()->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/index');
    }

    public function exportCsvAction() {
        $fileName = 'managefont.csv';
        $content = $this->getLayout()->createBlock('managefont/adminhtml_managefont_grid')
                ->getCsv();

        $this->_sendUploadResponse($fileName, $content);
    }

    public function exportXmlAction() {
        $fileName = 'managefont.xml';
        $content = $this->getLayout()->createBlock('managefont/adminhtml_managefont_grid')
                ->getXml();

        $this->_sendUploadResponse($fileName, $content);
    }

    protected function _sendUploadResponse($fileName, $content, $contentType = 'application/octet-stream') {
        $response = $this->getResponse();
        $response->setHeader('HTTP/1.1 200 OK', '');
        $response->setHeader('Pragma', 'public', true);
        $response->setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0', true);
        $response->setHeader('Content-Disposition', 'attachment; filename=' . $fileName);
        $response->setHeader('Last-Modified', date('r'));
        $response->setHeader('Accept-Ranges', 'bytes');
        $response->setHeader('Content-Length', strlen($content));
        $response->setHeader('Content-type', $contentType);
        $response->setBody($content);
        $response->sendResponse();
        die;
    }

}
