<?php
class Sparx_Managefont_Block_Managefont extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getManagefont()     
     { 
        if (!$this->hasData('managefont')) {
            $this->setData('managefont', Mage::registry('managefont'));
        }
        return $this->getData('managefont');
        
    }
}