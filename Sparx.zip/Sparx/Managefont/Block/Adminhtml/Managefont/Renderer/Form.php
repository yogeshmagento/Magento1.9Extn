<?php

class Sparx_Managefont_Block_Adminhtml_Managefont_Renderer_Form extends Mage_Adminhtml_Block_Abstract implements Varien_Data_Form_Element_Renderer_Interface {

    public function render(Varien_Data_Form_Element_Abstract $element) {
        $formData = Mage::registry('managefont_data')->getData();
        $status = isset($formData['status']) ? $formData['status'] : 1;
        $enabled = $status == 1 ? 'selected' : '';
        $disabled = $status == 2 ? 'selected' : '';

        $categoryModel=Mage::getModel('fontcategory/fontcategory')->getCollection()->addFieldToFilter('status',array('eq'=>1));
        ?>
        <table cellspacing="0" class="form-list">
            <tbody>
                <tr>
                    <td class="label"><label for="FontCategory">Font Category</label></td>
                    <td class="value">
                        <select type="select" name="fontcategory_id" id="fontcategory_id">
                            <?php if($categoryModel->getSize()>0){
                                foreach($categoryModel as $catVal){
                                ?>
                            <option value="<?php echo $catVal->getId(); ?>"><?php echo $catVal->getTitle(); ?></option>
                                <?php 
                            }
                        } ?>
                        </select>            
                    </td>
                </tr>


                <?php
                $fontTypeArr = Mage::getModel('managefont/managefonttype')->getCollection()
                        ->addFieldToFilter('status', array('eq' => 1))
                        ->getData();

                if (count($fontTypeArr) > 0) {
                    foreach ($fontTypeArr as $fontValue) {

                        //=====================Start Get Edit information =============================
                        $insertedFontId = $this->getRequest()->getParam('id');
                        if ($insertedFontId > 0) {
                            $fontDesc = Mage::getModel('managefont/managefontdesc')->getCollection()
                                            ->addFieldToFilter('managefont_id', $insertedFontId)
                                            ->addFieldToFilter('fonttype_id', $fontValue['managefonttype_id'])->getFirstItem()->getData();
                        }
                        //=====================End Get Edit information =============================

                        $fontField = 'font_' . $fontValue['managefonttype_id'];
                        ?>
                        <tr>
                            <td class="label"><label for=""><strong><?php echo Mage::helper('managefont')->__($fontValue['fonttype_name'] . ' File(.ttf)'); ?></strong></label></td>
                            <td class="value">
                                <input type="file" value="" name="<?php echo $fontField; ?>" id="<?php echo $fontField; ?>">
                                <?php /*<table>  
                                    <tr>
                                        <td class="label"><label for=""><strong><?php echo Mage::helper('managefont')->__('Font Name'); ?></strong></label></td>
                                        <td class="value">
                                            <input type="text" value="<?php echo $fontDesc['font_name']; ?>" name="<?php echo $fontField; ?>_fontname" id="<?php echo $fontField; ?>_fontname">
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="label"><label for=""><strong><?php echo Mage::helper('managefont')->__('File (.z)'); ?></strong></label></td>
                                        <td class="value">
                                            <input type="file" value="" name="<?php echo $fontField; ?>_z" id="<?php echo $fontField; ?>_z">
                                            <br><?php if (!empty($fontDesc['font_z'])): ?><span style="color:green;" title="uploaded file name"><?php echo $fontDesc['font_z']; ?></span><?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="label"><label for=""><strong><?php echo Mage::helper('managefont')->__('File (.ctg.z)'); ?></strong></label></td>
                                        <td class="value">
                                            <input type="file" value="" name="<?php echo $fontField; ?>_ctg" id="<?php echo $fontField; ?>_ctg">
                                            <br><?php if (!empty($fontDesc['font_ctg'])): ?><span style="color:green;" title="uploaded file name"><?php echo $fontDesc['font_ctg']; ?></span><?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="label"><label for=""><strong><?php echo Mage::helper('managefont')->__('File (.php)'); ?></strong></label></td>
                                        <td class="value">
                                            <input type="file" value="" name="<?php echo $fontField; ?>_php" id="<?php echo $fontField; ?>_php">
                                            <br><?php if (!empty($fontDesc['font_php'])): ?><span style="color:green;" title="uploaded file name"><?php echo $fontDesc['font_php']; ?></span><?php endif; ?>
                                        </td>
                                    </tr>
                                </table>*/?>
                                <?php if (!empty($fontDesc['fonttype_image'])): ?><p><img src="<?php echo Mage::getBaseUrl('media'); ?>designertool/font/original/<?php echo $fontDesc['fonttype_image']; ?>"/></p><?php endif; ?>
                            </td>
                        </tr>
                        <?php
                    }
                }
                ?>
                <tr>
                    <td class="label"><label for="status">Status</label></td>
                    <td class="value">
                        <select class=" select" name="status" id="status">
                            <option value="1" <?php echo $enabled; ?>><?php echo Mage::helper('managefont')->__('Enabled'); ?></option>
                            <option value="2" <?php echo $disabled; ?>><?php echo Mage::helper('managefont')->__('Disabled'); ?></option>
                        </select>            
                    </td>
                </tr>
            </tbody>
        </table>
        <?php
    }

}
