<?php

class Sparx_Managefont_Block_Adminhtml_Managefont_Edit extends Mage_Adminhtml_Block_Widget_Form_Container {

    public function __construct() {
        parent::__construct();

        $this->_objectId = 'id';
        $this->_blockGroup = 'managefont';
        $this->_controller = 'adminhtml_managefont';

        $this->_updateButton('save', 'label', Mage::helper('managefont')->__('Save Font'));
        $this->_updateButton('delete', 'label', Mage::helper('managefont')->__('Delete Font'));

        $this->_addButton('saveandcontinue', array(
            'label' => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick' => 'saveAndContinueEdit()',
            'class' => 'save',
                ), -100);

        $this->_formScripts[] = "
            jQuery('body').on('change','input[type=file]',function(){
                var val = jQuery(this).val();                
                var currentExt=val.substring(val.indexOf('.')+1).toLowerCase();
                
                var currentId= jQuery(this).attr('id');
                if((currentId.indexOf('_ctg')!= -1) && (currentExt == 'ctg.z')){
                            return true;
                    }
                    else if((currentId.indexOf('_z')!= -1) && (currentExt == 'z')){
                            return true;
                    }
                    else if((currentId.indexOf('_php')!= -1) && (currentExt == 'php')){
                            return true;
                    }
                    else if(currentExt=='ttf' && (currentId.indexOf('_php')== -1) && (currentId.indexOf('_z')== -1) && (currentId.indexOf('_ctg')== -1)){
                        return true;
                    }
                    else{
                        jQuery(this).val('');
                        alert('Please upload required .ttf files are allowed!!!');
                        return false;
                    }
            });
            
            function toggleEditor() {
                if (tinyMCE.getInstanceById('managefont_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'managefont_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'managefont_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText() {
        if (Mage::registry('managefont_data') && Mage::registry('managefont_data')->getId()) {
            return Mage::helper('managefont')->__("Edit Font '%s'", $this->htmlEscape(Mage::registry('managefont_data')->getTitle()));
        } else {
            return Mage::helper('managefont')->__('Add Font');
        }
    }

}
