<?php

class Sparx_Managefont_Block_Adminhtml_Managefont_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
      parent::__construct();
      $this->setId('managefont_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('managefont')->__('Manage Font'));
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('managefont')->__('Manage Font'),
          'title'     => Mage::helper('managefont')->__('Manage Font'),
          'content'   => $this->getLayout()->createBlock('managefont/adminhtml_managefont_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}
