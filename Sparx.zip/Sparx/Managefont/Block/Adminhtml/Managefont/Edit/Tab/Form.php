<?php

class Sparx_Managefont_Block_Adminhtml_Managefont_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm() {
        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset('managefont_form', array('legend' => Mage::helper('managefont')->__('Manage Font')));

        $customField = $fieldset->addField('test', 'text', array('label' => Mage::helper('managefont')->__('Font Information'), 'name' => 'card_sizes',));

        $customField->setRenderer($this->getLayout()->createBlock('managefont/adminhtml_managefont_renderer_Form'));

        if (Mage::getSingleton('adminhtml/session')->getManagefontData()) {
            $form->setValues(Mage::getSingleton('adminhtml/session')->getManagefontData());
            Mage::getSingleton('adminhtml/session')->setManagefontData(null);
        } elseif (Mage::registry('managefont_data')) {
            $form->setValues(Mage::registry('managefont_data')->getData());
        }
        return parent::_prepareForm();
    }

}
