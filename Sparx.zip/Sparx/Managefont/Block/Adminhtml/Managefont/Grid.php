<?php

class Sparx_Managefont_Block_Adminhtml_Managefont_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('managefontGrid');
      $this->setDefaultSort('managefont_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('managefont/managefont')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }

  protected function _prepareColumns()
  {
      $this->addColumn('managefont_id', array(
          'header'    => Mage::helper('managefont')->__('ID'),
          'align'     =>'right',
          'width'     => '50px',
          'index'     => 'managefont_id',
      ));

      $this->addColumn('title', array(
          'header'    => Mage::helper('managefont')->__('Font Name'),
          'align'     =>'left',
          'index'     => 'title',
      ));
      
       //======================== Load, font category ==============================================================
      $categoryModel=Mage::getModel('fontcategory/fontcategory')->getCollection()->addFieldToFilter('status',array('eq'=>1));
      if($categoryModel->getSize()>0){
		$catArr=array(); 
		foreach($categoryModel->getData() as $catVal){
				$catArr[$catVal['fontcategory_id']]=$catVal['title'];
			}
		  
		  $this->addColumn('fontcategory_id', array(
			  'header'    => Mage::helper('managefont')->__('Font Category'),
			  'align'     => 'left',
			  'width'     => '480px',
			  'index'     => 'fontcategory_id',
			  'type'      => 'options',
			  'options'   => $catArr,
		  ));
		}
	

	  /*
      $this->addColumn('content', array(
			'header'    => Mage::helper('managefont')->__('Item Content'),
			'width'     => '150px',
			'index'     => 'content',
      ));
	  */

      $this->addColumn('status', array(
          'header'    => Mage::helper('managefont')->__('Status'),
          'align'     => 'left',
          'width'     => '80px',
          'index'     => 'status',
          'type'      => 'options',
          'options'   => array(
              1 => 'Enabled',
              2 => 'Disabled',
          ),
      ));
	  
        $this->addColumn('action',
            array(
                'header'    =>  Mage::helper('managefont')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('managefont')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
		
		$this->addExportType('*/*/exportCsv', Mage::helper('managefont')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('managefont')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('managefont_id');
        $this->getMassactionBlock()->setFormFieldName('managefont');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'    => Mage::helper('managefont')->__('Delete'),
             'url'      => $this->getUrl('*/*/massDelete'),
             'confirm'  => Mage::helper('managefont')->__('Are you sure?')
        ));

        $statuses = Mage::getSingleton('managefont/status')->getOptionArray();

        array_unshift($statuses, array('label'=>'', 'value'=>''));
        $this->getMassactionBlock()->addItem('status', array(
             'label'=> Mage::helper('managefont')->__('Change status'),
             'url'  => $this->getUrl('*/*/massStatus', array('_current'=>true)),
             'additional' => array(
                    'visibility' => array(
                         'name' => 'status',
                         'type' => 'select',
                         'class' => 'required-entry',
                         'label' => Mage::helper('managefont')->__('Status'),
                         'values' => $statuses
                     )
             )
        ));
        return $this;
    }

  public function getRowUrl($row)
  {
      return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }

}
