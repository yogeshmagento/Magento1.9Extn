<?php
class Sparx_Managefont_Block_Adminhtml_Managefont extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_managefont';
    $this->_blockGroup = 'managefont';
    $this->_headerText = Mage::helper('managefont')->__('Manage Font');
    $this->_addButtonLabel = Mage::helper('managefont')->__('Add Font');
    parent::__construct();
  }
}
