<?php

class Sparx_Managefont_Model_Mysql4_Managefontdesc extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the managefont_id refers to the key field in your database table.
        $this->_init('managefont/managefontdesc', 'managefontdesc_id');
    }
}
