<?php

class Sparx_Managefont_Model_Managefontdesc extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('managefont/managefontdesc');
    }
}
