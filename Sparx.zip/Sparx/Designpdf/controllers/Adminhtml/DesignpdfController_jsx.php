

<?php
require_once 'pdffiles/pdf.php';
require_once 'pdffiles/zip.class.php';
require_once 'MaketextController.php';

class Sparx_Designpdf_Adminhtml_DesignpdfController extends Mage_Adminhtml_Controller_action {

    var $imageMagickPath;

    public function imageMagicPath() {
        $this->imageMagickPath = Mage::getStoreConfig('designertool/imagemagick_info/image_magick_path');
        return $this->imageMagickPath;
    }

    function deletePDFAction() {
        $orderId = $this->getRequest()->getParam('orderId');
        $orderIncId = $this->getRequest()->getParam('orderIncId');
        @unlink(Mage::getBaseDir() . '/pdf/' . $orderId . ".zip");
        $this->DELETE_RECURSIVE_DIRS(Mage::getBaseDir() . '/pdf/' . $orderId);
        $url = Mage::helper("adminhtml")->getUrl("designpdf/adminhtml_designpdf/generatePDF/", array("orderId" => $orderId));
        echo '<a href="javascript:void(0);" onclick="generate_pdf(\'' . $url . '\',' . $orderId . ');">Generate PDF</a>';
    }

	function DELETE_RECURSIVE_DIRS($dirname) {
		if (is_dir($dirname)) {
			$dir_handle = opendir($dirname);
			while ($file = readdir($dir_handle)) {
				if ($file != "." && $file != "..") {
					if (!is_dir($dirname . "/" . $file)) {
						unlink($dirname . "/" . $file);
					} else {
						$this -> DELETE_RECURSIVE_DIRS($dirname . "/" . $file);
						@rmdir($dirname . "/" . $file);
					}
				}
			}
			closedir($dir_handle);
			@rmdir($dirname);
			return true;
		} else
			return false;
	}



	function createDirectory($dirName) {
		if (!is_dir($dirName)) {
			@mkdir($dirName);
			@chmod($dirName, 0777);
		}
	}

	function generatePDFAction() {
		//$maketext = new Sparx_Designpdf_Adminhtml_MaketextController();
		//$jsonClass = new JSON;
		$orderId = $this->getRequest()->getParam('orderId'); 
        $order = Mage::getModel('sales/order')->load($orderId);
        $items = $order->getAllItems();
        $itemcount = count($items);
		$ordZipFileName = $orderId . ".zip";
		$directoryName = "pdf/" . $ordZipFileName;
		$cnt = 0;
		if (!is_file($directoryName)) {
			if ($itemcount > 0) {
				$zipArr = array();
				foreach ($items as $itemId => $item) {
					 $productId = $item->getProductId();
					 
					 $colections = Mage::getModel('designertool/designertool')->getCollection()
					 ->addFieldToFilter('product_id',$productId)
					 ->addFieldToFilter('tool_output', array('neq' => ''));
					 $cnt = count($colections->getData());
					//Call for PDF lettering
					 if($cnt) {
						$productId = $item -> getProductId();
						$toolDataCollection = Mage::getModel('designertool/designertool') -> getCollection() -> addFieldToFilter('product_id', $productId) -> getFirstItem() -> getData();
						$dataArr = $toolDataCollection['tool_output'];
						$jsonEncodedData = json_decode($dataArr);
						$dirName = Mage::getBaseDir('media') . "/designertool/pdf/" . $orderId;
						$this -> createDirectory($dirName);
						$maketextClass = new Sparx_Designpdf_Adminhtml_MaketextController();

						foreach ($jsonEncodedData as $fvalue) {
							//echo "<pre>";
							 //print_r($fvalue); die;

							$proofImg = Mage::getBaseDir().'/designertool/lettering/' . $fvalue -> imgPath;
							$imgSize = getimagesize($proofImg);

							$widthVal = 1000;
							$heightVal = 1400;
							$ratioW = 1;
							$ratioH = 1;
							$size = array($widthVal, $heightVal);
							$pdf = new PDF("P", "pt", $size);
							$pdf -> AddPage();
							$pdfFileName = $orderId . "/" . $orderId . ".pdf";
							//exec("convert -density 200x200 -depth 8 -quality 100  ".$maketextClass -> imgUrl." -resize 1000% ". $maketextClass -> imgUrl);
							//$pdf -> RotatedImage($maketextClass -> imgUrl, 0, 0, $widthVal, $heightVal, 0);

							$y = 530;
							$xh = 70;
							$xhd = 270;
							$xd = 350;
							$ximg = 70;
							$ratioW = 1;
							$ratioH = 1;
							$l = 0;
							$t = 1;
							$n = 1;
							list($IM_W, $IM_H) = getimagesize(Mage::getBaseDir().'/media/custom-logo.png');
							$pdf -> RotatedImage(Mage::getBaseDir().'/media/custom-logo.png', $xh, 5, $IM_W, $IM_H, 0);
							$pdf -> RotatedImage(Mage::getBaseDir().'/media/proof.png', 691, 58, 240, 40, 0);
							$pdf -> SetLineWidth(2);
							$pdf -> SetDrawColor(221, 221, 221);
							$pdf -> Line($xh, 105, 930, 105);

							$widt = 270;
							$heigt = 250;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 30);
							$pdf -> Text($xh, 135, "MY DESIGN");
							$pdf -> SetLineWidth(2);
							$pdf -> SetDrawColor(221, 221, 221);
							$pdf -> Line($xh, 150, 930, 150);
							$pdf -> SetDrawColor(255, 140, 0);

							if ($imgSize[1] > 170)
							$rectSize = 150;
							else
							$rectSize = $imgSize[1];
							$pdf -> RoundedRect($ximg + 30, 170, 800, $rectSize, 3.50, '1111', 'DF');

							$pdf -> RotatedImage($proofImg, $ximg + 30, 170, 800, $rectSize, 0);

							$y = 230 + $rectSize;

							// $pdf -> SetFont('Arial', 'B', 30);
							// $pdf -> Text($xh, 485, "OPTIONS");
							// $pdf -> SetLineWidth(2);
							// $pdf -> SetDrawColor(221, 221, 221);
							// $pdf -> Line($xh, 490, 930, 490);
							$pdf -> SetTextColor(131, 129, 129);
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 26);
							$pdf -> Text($xh, $y, "OUTPUT INFORMATION");

							$y = $y + 50;
							//echo $text;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Font Name : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> Font_name);

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Font Bold : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> bold);

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Font Italic : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> italic);

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Text Color : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> textColor);
							//$this -> rgbVal($fvalue -> textColor);
							//$pdf -> SetFillColor($this->$colorArr[0], $this->$colorArr[1], $this->$colorArr[2]);
							$rgb = str_replace('rgb(', '', $fvalue -> textColor);
							$rgb = str_replace(')', '', $rgb);
							$colorArr = explode(',', $rgb);
							$pdf -> SetFillColor($colorArr[0], $colorArr[1], $colorArr[2]);
							$pdf -> RoundedRect($xh + 500, $y - 20, 50, 20, 3.50, 'FD');

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Text Line Alignment : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> textAlign);

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Text Shadow : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> textShadow);

							if ($fvalue -> textShadow != 'None') {
							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Text Shadow Color : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> shadowColor);
							//$this -> rgbVal($fvalue -> shadowColor);
							//$pdf -> SetFillColor($this->$colorArr[0], $this->$colorArr[1], $this->$colorArr[2]);
							$rgb = str_replace('rgb(', '', $fvalue -> shadowColor);
							$rgb = str_replace(')', '', $rgb);
							$colorArr = explode(',', $rgb);
							$pdf -> SetFillColor($colorArr[0], $colorArr[1], $colorArr[2]);
							$pdf -> RoundedRect($xh + 500, $y - 20, 50, 20, 3.50, 'FD');
							}

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Border Style : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> strokewidth);

							if ($fvalue -> strokewidth != 'None') {

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Border Color : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> borderColor);
							//$this -> rgbVal($fvalue -> borderColor);
							//$pdf -> SetFillColor($this->$colorArr[0], $this->$colorArr[1], $this->$colorArr[2]);
							$rgb = str_replace('rgb(', '', $fvalue -> borderColor);
							$rgb = str_replace(')', '', $rgb);
							$colorArr = explode(',', $rgb);
							$pdf -> SetFillColor($colorArr[0], $colorArr[1], $colorArr[2]);
							$pdf -> RoundedRect($xh + 500, $y - 20, 50, 20, 3.50, 'FD');
							}

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Text Wrapping : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> effectName);

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Character Spacing : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> characterSpace);

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Mirror Cut V : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> flipVal);

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Mirror Cut H : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> flopVal);

							$y = $y + 90;

							// $pdf -> SetLineWidth(2);
							// $pdf -> SetDrawColor(221, 221, 221);
							// $pdf -> Line($xh, 490, 930, 490);
							// $pdf -> SetTextColor(131, 129, 129);
							// $pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 26);
							$pdf -> Text($xh, $y, "SIZE INFORMATION");

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Width : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> originWidth . "(inch)");

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Height : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh + 300, $y, $fvalue -> originHeight . "(inch)");

							$y = $y + 30;

							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> Text($xh, $y, "Text Value : ");
							$pdf -> SetTextColor(100, 100, 100);
							$pdf -> SetFont('Arial', 'B', 22);
							$pdf -> SetY($y - 20);
							$pdf -> SetX($xh + 290);
							$lines = preg_split("/\r\n|[\r\n]/", trim($fvalue -> data));
							$countLine = count($lines);

							$text = '';
							for ($i = 0; $i < $countLine; $i++) {
							$text = $text . $lines[$i];
							if ($i != $countLine - 1) {
							$text = $text . " \n ";
							}
							}
							//echo $text;
							$text = " " . $text . " ";
							//$pdf->MultiCell(600,22,"Maneet Singh Rana Maneet Singh Rana\nManeet Singh Rana",0,'C',0);
							$pdf -> MultiCell(600, 22, $text, 0, 'L', 0);
							//CellFitSpace
							//$pdf->CellFitSpace(0,10,$text,1,10,'',0);
							//echo $y = $y + 30 + (22 * $countLine);
						}
						$zipArr[] = $maketextClass -> imgUrl;
						$zipArr[] = Mage::getBaseDir('media') . "/designertool/pdf/" . $pdfFileName;
						$pdf -> Output(Mage::getBaseDir('media') . "/designertool/pdf/" . $pdfFileName);

					} else {

							$optionsArr = $item->getProductOptions();
							if(count($optionsArr['options']) > 0)
							{
								foreach ($optionsArr['options'] as $option)
								{
								$optionValue = $option['value'];
								}
							}
							if($optionValue) {
								$designQuote = Mage::getModel('designertool/designquote')->getCollection()
								->addFieldToFilter('design_unique_id',$optionValue)->getFirstItem();
								$designId = $designQuote->getDesignId();
							}
							$dirOrderName = $directoryName . "/" . $orderId;
							$this -> createDirectory($dirOrderName);
							$dirName = $dirOrderName . "/" . $productId;
							$this -> createDirectory($dirName);
							$data = Mage::getModel('designertool/designertool') -> load($designId);
							$dataArr = $data -> getDataArray();
							$backgroundColor = $data -> getBackgroundColor();

							$red = hexdec(substr($backgroundColor, 1, 2));
							$green = hexdec(substr($backgroundColor, 3, 2));
							$blue = hexdec(substr($backgroundColor, 5, 2));
							//echo $backgroundColor;
							$backgroundAlpha = $data -> getBackgroundAlpha();
							$pHeight = $data -> getPrintHeight();
							$pWidth = $data -> getPrintWidth();
							$height = $data -> getHeight();
							$width = $data -> getWidth();
							$jsonEncodedData = json_decode($dataArr);
							//echo "<pre>";print_r($jsonEncodedData);
							//exit ;

							$printW = $pWidth;
							$printH = $pHeight;
							$ratioW = $printW / $width;
							$ratioH = $printH / $height;

							$dirName = "pdf/" . $orderId;
							$this -> createDirectory($dirName);
							// Create First Level Directory
							$dirName = "pdf/" . $orderId . "/" . $productId;
							$this -> createDirectory($dirName);
							// Create second Level Directory
							$designDirName = Mage::getBaseDir()."/pdf/" . $orderId . "/designimage";
							$this -> createDirectory($designDirName);
							// Create Second Level Directoryexit;
							$pdfFileName = $orderId . "-" . $productId . "-.pdf";
							$Eps_script = 'var docPreset = new DocumentPreset;';
							$Eps_script = $Eps_script . 'docPreset.width = "' . $printW . '" ;
							docPreset.height = "' . $printH . '";
							var docRef = documents.addDocument(DocumentColorSpace.RGB, docPreset);
							var fName = "CURVE 8900";var newLayer = docRef.layers.add();newLayer.name = fName;';
							$Eps_script = $Eps_script . 'var pathRef = docRef.pathItems.rectangle(docPreset.height, 0, docPreset.width, docPreset.height);
							var backgroundCol = new RGBColor();
							backgroundCol.red = ' . $red . ';
							backgroundCol.green = ' . $green . ';
							backgroundCol.blue = ' . $blue . ';
							pathRef.filled = true;
							pathRef.fillColor = backgroundCol;';
							/*echo "<pre>";
							print_r($jsonEncodedData);
							exit ;*/
							foreach ($jsonEncodedData as $datavalue) {
								if ($datavalue -> name == 'text') {
									$rotation = 0;
									$posX = ($datavalue -> x * $ratioW);
									$posY = ($datavalue -> y * $ratioH);
									$posW = ($datavalue -> width * $ratioW);
									$posH = ($datavalue -> height * $ratioH);
									$top = $printH - $posY;
									$totalH = $printH - $posY;
									$ai_name = $datavalue -> ai_name;
									$text = $datavalue -> text_val;
									if ($datavalue->fill != '') {
										$txtColor = '#' . $datavalue->fill;
									} 
									else {
										$txtColor = '#' . dechex($datavalue->fill);
									}//$value->color;
									$red = hexdec(substr($txtColor, 1, 2));
									$green = hexdec(substr($txtColor, 3, 2));
									$blue = hexdec(substr($txtColor, 5, 2));
									$opacity = 100;
		
									$Eps_script = $Eps_script . 'areaTextRef = newLayer.textFrames.add();
									areaTextRef.top =' . $top . ';
									areaTextRef.left =' . $posX . ';
									var fontName = "' . $ai_name . '";
									areaTextRef.textRange.characterAttributes.textFont = textFonts.getByName(fontName);
									areaTextRef.contents = "' . $text . '";
		
									var mytextcolor = new RGBColor();
									mytextcolor.red = ' . $red . ';
									mytextcolor.green = ' . $green . ';
									mytextcolor.blue = ' . $blue . ';
									areaTextRef.textRange.characterAttributes.fillColor = mytextcolor;
									areaTextRef.opacity=' . $opacity . ';
									var triangleGroup = areaTextRef.createOutline();
									triangleGroup.top = ' . $top . ';
									triangleGroup.left =' . $posX . ';
									triangleGroup.width =' . $posW . ';
									triangleGroup.height =' . $posH . ';
									triangleGroup.rotate (' . $rotation . ');
									triangleGroup.top = ' . $top . ';
									triangleGroup.left =' . $posX . ';';
	
								}
								/*$textNo = rand();
								$imageDestName = $designDirName . "/" . $textNo . "normal.png";
								$query = $this -> setTextQuery($datavalue, $imageDestName);
								exec($imageMagickPath . $query);
								$zipArr[] = $designDirName . "/" . $textNo . "normal.png";
								$pdf->RotatedImage($imageDestName, $posX, $posY, $posW, $posH, $rotation);
								$Eps_script = $Eps_script . 'var thisPlacedItem;thisPlacedItem = newLayer.placedItems.add();
								thisPlacedItem.file = File("D:/illustrator/NR321/' . $orderId . '/' . $textNo . 'normal.png");';
								$Eps_script = $Eps_script . 'thisPlacedItem.height=' . $posH . ';';
								$Eps_script = $Eps_script . 'thisPlacedItem.width=' . $posW . ';';
								$Eps_script = $Eps_script . 'thisPlacedItem.top=' . $totalH . ';';
								$Eps_script = $Eps_script . 'thisPlacedItem.left=' . $posX . ';';
								$Eps_script = $Eps_script . 'thisPlacedItem.rotate ("' . $rotation . '");';
								}*/
	
								if ($datavalue -> name == 'clipart') {
									$rotation = 0;
									$posX = ($datavalue -> x * $ratioW);
									$posY = ($datavalue -> y * $ratioH);
									$posW = ($datavalue -> width * $ratioW);
									$posH = ($datavalue -> height * $ratioH);
									$totalH = $printH - $posY;
									$path_parts = basename($datavalue -> imagePath);
									$designImgSource = Mage::getBaseDir('media')."/designertool/clipart/" . $path_parts;
									list($wid, $hit) = getimagesize($designImgSource);
									$size = array($wid, $hit);
									$pdf = new PDF("P", "pt", $size);
									$pdf -> AddPage();
									$designImgSourceEps = str_replace('.png', '.eps', $designImgSource);
									if(file_exists($designImgSourceEps)){
										$txtColor = $datavalue -> fill;
										$outputfile = $designDirName.'/'.str_replace('.png', '.eps', $path_parts);
										if ($datavalue -> colorrize)
											$pdf -> RotatedEpsColorable($designImgSourceEps, 0, 0, $wid, $hit, 0, $txtColor);
										else
											$pdf -> RotatedEps($designImgSourceEps, 0, 0, $wid, $hit, 0);
										copy($designImgSourceEps, $outputfile );
									} 
									else{
										$outputfile = $designDirName.'/'.$path_parts;
										$pdf -> RotatedImage($designImgSource, 0, 0, $wid, $hit, 0);
										copy($designImgSource, $outputfile );
									}
									$rand = rand();
									$pdfFileName = $orderId . "-" . $productId . "-" . $rand . ".pdf";
									$clipartName = str_replace('.pdf', '.eps', $pdfFileName);
									//$ImageFileName =
									if (is_file($outputfile)) {
									//$zipArr[] = $designDirName . "/" . $pdfFileName;
									//$pdf -> Output($designDirName . "/" . $pdfFileName);
										$Eps_script = $Eps_script . 'var thisPlacedItem;thisPlacedItem = newLayer.placedItems.add();
										thisPlacedItem.file = File("D:/illustrator/NR336_Sign/' .$path_parts. '");';
										$Eps_script = $Eps_script . 'thisPlacedItem.height=' . $posH . ';';
										$Eps_script = $Eps_script . 'thisPlacedItem.width=' . $posW . ';';
										$Eps_script = $Eps_script . 'thisPlacedItem.top=' . $totalH . ';';
										$Eps_script = $Eps_script . 'thisPlacedItem.left=' . $posX . ';';
										$Eps_script = $Eps_script . 'thisPlacedItem.rotate ("' . $rotation . '");';
									}
		
									$zipArr[] = $outputfile;
								}
								if ($datavalue -> name == 'image') {
									$rotation = 0;//(-($datavalue -> rotation));
									$posX = ($datavalue -> x * $ratioW);
									$posY = ($datavalue -> y * $ratioH);
									$posW = ($datavalue -> width * $ratioW);
									$posH = ($datavalue -> height * $ratioH);
									$totalH = $printH - $posY;
									$designImgSource = str_replace('/large/', '/original/', $datavalue -> ImgPath);
									$imageArray = explode("/", $designImgSource);
									$position = count($imageArray) - 1;
									$imageRequied = $imageArray[$position];
									if (!file_exists($dirName . "/" . $imageRequied))
										$zipArr[] = $designImgSource;
									copy($designImgSource, $dirName . "/" . $imageRequied);
		
									$Eps_script = $Eps_script . 'var thisPlacedItem;thisPlacedItem = newLayer.placedItems.add();
									thisPlacedItem.file = File("D:/illustrator/NR336_Sign/' . $orderId . '/' . $imageRequied . '");';
		
									$Eps_script = $Eps_script . 'thisPlacedItem.height=' . $posH . ';';
									$Eps_script = $Eps_script . 'thisPlacedItem.width=' . $posW . ';';
									$Eps_script = $Eps_script . 'thisPlacedItem.top=' . $totalH . ';';
									$Eps_script = $Eps_script . 'thisPlacedItem.left=' . $posX . ';';
									$Eps_script = $Eps_script . 'thisPlacedItem.rotate ("' . $rotation . '");';
	
								}
							}
							//$divName = $dirName .'_'.$line->rawProdId.'_'.$viewTitle.'_'. "mybigcommerce";
							$divName = $dirName . '/' . $orderId . '_' . $productId . '_NR349';
							$myFile = "$divName" . ".jsx";
							$fh = fopen($myFile, 'w') or die("can't open file");
							fwrite($fh, $Eps_script);
							fclose($fh);
							$zipArr[] = $myFile;
							$Eps_script = '';
					//$zipArr[] = $dirName . "/" . $pdfFileName;
					// $pdf->Output($dirName . "/" . $pdfFileName);
				  	}
				}

				$fileName = "pdf/" . $orderId . ".zip";
				$fd = fopen($fileName, "wb");
				$createZip = new ZipFile($fd);
				foreach ($zipArr as $filzip) {
					$zipfileName = substr($filzip, strrpos($filzip, "/") + 1);
					$createZip -> addFile($filzip, $zipfileName, true);
				}
				$createZip -> close();
				$url = Mage::helper("adminhtml")->getUrl("designpdf/adminhtml_designpdf/deletePDF/", array("orderId" => $orderId, "orderIncId" => $orderIncId));
                $downloadUrl = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB) . 'download.php?fileName=' . $orderId . '.zip';
                echo '<a style="display: block;" title="Download Pdf" href="' . $downloadUrl . '">Download PDF</a></br>';
                echo '<a href="javascript:void(0);" onclick="generate_pdf(\'' . $url . '\',' . $orderId . ');"> Delete PDF </a>';
			} else {
				echo "Sorry there is no order!!";
			}
		} else {
			echo "PDF already generated!!";
		}
		
	}

	function setTextQuery($value, $imageDestName) { 
		if ($value -> fill == '#000000')
			$txtColor = '#000002';
		elseif ($value -> fill == '#FFFFFF' || $value -> fill == '#ffffff')
			$txtColor = '#FDFFFF';
		else
			$txtColor =  $value -> fill;
		$garvity = $value -> align;
		$fontId = $value -> fontID;
		$myfont = Mage::getModel('font/font') -> load($fontId);
		
		$fontFileName = $value->TTFName;//Mage::getBaseDir('media')."/designertool/font/" . $fontTTF;

		$lines = preg_split("/\r\n|[\r\n]/", $value -> text_val);
		$countLine = count($lines);
		$text = '';
		for ($i = 0; $i < $countLine; $i++) {
			$text = $text . $lines[$i];
			if ($i != $countLine - 1) {
				$text = $text . " \n ";
			}
		}
		$text = " " . $text . " ";

		$File = "TextFile.txt";
		$Handle = fopen($File, 'w');
		fwrite($Handle, $text);
		fclose($Handle);

		$filpStr = '';
		$arc = '';
		$rotate = 0;
		$end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';

		/*if ($value -> arc > 0) {
			$step = 360 / 100;
			$rotate = 0;
			$end = '';
			$arc = $value -> arc * $step;
			$end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';
		} else if ($value -> arc < 0) {

			$step = 360 / 100;
			$rotate = 180;
			$end = '';
			$arc = $value -> arc * (-$step);
			$end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';
		}
		if ($value -> reversecut == -1) {
			$filpStr = ' -flop';
			//echo   $query = '  -gravity center -background none -fill "' . $txtColor . '" -font "' . $fontFileName . '"  "' . $filpStr . '" -size 2000x2000 -dither None +antialias label:@"' . $File . '"   '.$end.'  -trim png:' . $imageDestName;exit;
		}*/

		$query = '  -gravity center -background none -fill "' . $txtColor . '" -font "' . $fontFileName . '"  ' . $filpStr . ' -size 2000x2000 -dither None +antialias label:@"' . $File . '"   ' . $end . '  -trim png:' . $imageDestName;

		return $query;
		
	}

	function setTextNormalQuery($value, $imageDestName) {
		if ($value -> shadowColor1 == '000000')
			$txtColor = '#000002';
		elseif ($value -> shadowColor1 == 'FFFFFF' || $value -> shadowColor1 == 'ffffff')
			$txtColor = '#FDFFFF';
		else
			$txtColor = '#' . $value -> shadowColor1;
		$garvity = $value -> align;
		$fontId = $value -> fontId;
		$myfont = Mage::getModel('font/font') -> load($fontId);

		$fontTTF = $myfont -> getFileTtfName();
		$fontFileName = "media/designer_tool_fonts/font_ttf/" . $fontTTF;

		$lines = preg_split("/\r\n|[\r\n]/", $value -> text);
		$countLine = count($lines);
		$text = '';
		for ($i = 0; $i < $countLine; $i++) {
			$text = $text . $lines[$i];
			if ($i != $countLine - 1) {
				$text = $text . " \n ";
			}
		}
		$text = " " . $text . " ";

		$File = "TextFile.txt";
		$Handle = fopen($File, 'w');
		fwrite($Handle, $text);
		fclose($Handle);

		$filpStr = '';
		$arc = '';
		$rotate = 0;
		$end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';

		if ($value -> arc > 0) {
			$step = 360 / 100;
			$rotate = 0;
			$end = '';
			$arc = $value -> arc * $step;
			$end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';
		} else if ($value -> arc < 0) {

			$step = 360 / 100;
			$rotate = 180;
			$end = '';
			$arc = $value -> arc * (-$step);
			$end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';
		}
		if ($value -> reversecut == -1) {
			$filpStr = ' -flop';
			//echo $query = '  -gravity center -background none -fill "#020202" -font "' . $fontFileName . '" "' . $filpStr . '" -size 2000x2000 -dither None +antialias label:@"' . $File . '"   '.$end.' -trim png:' . $imageDestName;exit;
		}
		$query = '  -gravity center -background none -fill "' . $txtColor . '" -font "' . $fontFileName . '" ' . $filpStr . ' -size 2000x2000 -dither None +antialias label:@"' . $File . '"   ' . $end . ' -trim png:' . $imageDestName;

		return $query;
	}

	function shadowforImage($value, $imageDestName, $normalImage, $imageDestName1) {

		if ($value -> shadowType == 'br') {
			$x = 15;
			$y = 15;
			$shadowPosition = "+" . $x . "+" . $y;

		} else if ($value -> shadowType == 'bl') {
			$x = 15;
			$y = 15;
			$shadowPosition = "-" . $x . "+" . $y;

		} else if ($value -> shadowType == 'tr') {
			$x = 15;
			$y = 15;
			$shadowPosition = "+" . $x . "-" . $y;
		} else if ($value -> shadowType == 'tl') {
			$x = 15;
			$y = 15;
			$shadowPosition = "-" . $x . "-" . $y;
		}
		$query = ' -size 2000x2000 xc:transparent "' . $normalImage . '" -geometry  ' . $shadowPosition . ' -composite  "' . $imageDestName . '" -geometry +0+0  -composite -trim ' . $imageDestName1;
		return $query;
	}
 
}
