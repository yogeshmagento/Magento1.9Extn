<?php

require_once 'pdffiles/zip.class.php';

class Sparx_Designpdf_Adminhtml_DesignpdfController extends Mage_Adminhtml_Controller_action {

   var $imageMagickPath;

   public function imageMagicPath() {
      $this->imageMagickPath = Mage::getStoreConfig('designertool/imagemagick_info/image_magick_path');
      return $this->imageMagickPath;
   }

   function deletePDFAction() {
      $orderId = $this->getRequest()->getParam('orderId');
      @unlink(Mage::getBaseDir() . '/pdf/' . $orderId . ".zip");
      $this->DELETE_RECURSIVE_DIRS(Mage::getBaseDir() . '/pdf/' . $orderId);
      $url = Mage::helper("adminhtml")->getUrl("designpdf/adminhtml_designpdf/generatePDF/", array("orderId" => $orderId));
      echo '<a href="javascript:void(0);" onclick="generate_pdf(\'' . $url . '\',' . $orderId . ');">Generate PDF</a>';
   }

   function DELETE_RECURSIVE_DIRS($dirname) {
      if (is_dir($dirname)) {
         $dir_handle = opendir($dirname);
         while ($file = readdir($dir_handle)) {
            if ($file != "." && $file != "..") {
               if (!is_dir($dirname . "/" . $file)) {
                  unlink($dirname . "/" . $file);
               } else {
                  $this->DELETE_RECURSIVE_DIRS($dirname . "/" . $file);
                  @rmdir($dirname . "/" . $file);
               }
            }
         }
         closedir($dir_handle);
         @rmdir($dirname);
         return true;
      } else
         return false;
   }

   function createDirectory($dirName) {
      if (!is_dir($dirName)) {
         @mkdir($dirName);
         @chmod($dirName, 0777);
      }
   }

   function generatePDFAction() {
     $orderId = $this->getRequest()->getParam('orderId');
     $order = Mage::getModel('sales/order')->load($orderId);
     $items = $order->getAllItems();
     $itemcount = count($items);
     $ordZipFileName = $orderId . ".zip";
     $directoryName = "pdf/" . $ordZipFileName;
     $this->tcpdfDirPath = Mage::getBaseDir();
     $cnt = 0;
     if (!is_file($directoryName)) {
         if ($itemcount > 0) {
            $zipArr = array();
            foreach ($items as $itemId => $item) {
               $productId = $item->getProductId();
               $Product_options = $item->getProductOptions();
               $colections = Mage::getModel('designertool/designertool')->getCollection()
                       ->addFieldToFilter('product_id', $productId)
                       ->addFieldToFilter('tool_output', array('neq' => ''));
               $cnt = count($colections->getData());
               $optionsArr = $item->getProductOptions();
               if (count($optionsArr['options']) > 0) {
                  foreach ($optionsArr['options'] as $option) {
   					    $optionValues = $option['value'];
   					    	$exCode=explode('info#', $optionValues);
           				   $optionValue=trim($exCode[0]);
                  }
               }
               if ($optionValue) {
                  $designQuote = Mage::getModel('designertool/designquote')->getCollection()
                                  ->addFieldToFilter('design_unique_id', $optionValue)->getFirstItem();
                  $designId = $designQuote->getDesignId();
               }
               $dirOrderName = $directoryName . "/" . $orderId;
               $this->createDirectory($dirOrderName);
               $dirName = $dirOrderName . "/" . $productId;
               $this->createDirectory($dirName);

               $pdfFile = Mage::getBaseDir('media') . "/designertool/pdf/" . $orderId;
               $this->createDirectory($pdfFile);

               $pdfFileName = $pdfFile . '/' . rand() . '.pdf';


               $data = Mage::getModel('designertool/designertool')->load($designId);
               $dataArr = json_decode($data->getDataArray(), true);
               $backgroundColor = $data->getBackgroundColor();
               $backgroundColor = $this->hex2rgb($backgroundColor);
               $height = $data->getHeight();
               $width = $data->getWidth();
               
               foreach ($dataArr as $val => $v) {
                  $fname = $v['originalImgPath'];
                  
                  if (isset($fname) && !empty($fname)) {
                     $orgSrc = str_replace(Mage::getBaseUrl('media'), Mage::getBaseDir('media') . '/', $fname);
                     $tempSource = $pdfFile . '/';
                     $path_parts = pathinfo($fname);
                     $finalFile = $tempSource . $path_parts['basename'];
                     copy($orgSrc, $finalFile);
                     $zipArr[] = $finalFile;
                  }
                  $fontpath = $v['fontCategoryDataArray'];
                  if (isset($fontpath) && !empty($fontpath)) {
                     foreach ($fontpath as $key) {
                        $orgSrc = str_replace(Mage::getBaseUrl('media'), Mage::getBaseDir('media') . '/', $key);
                        $tempSource = $pdfFile . '/';
                        $path_parts = pathinfo($key);
                        $finalttf = $tempSource . $path_parts['basename'];
                        copy($orgSrc, $finalttf);
                        $zipArr[] = $finalttf;
                     }
                  }
               }


               //============== for svg generations ==========
               $svgArr = json_decode($data->getSvgArr());
               $option = $Product_options['options'];
               $pdf = new TCPDF_TCPDF(PDF_PAGE_ORIENTATION, 'pt', '', true, 'UTF-8', false);
               
               $pdfheight = $data->getPrintHeight()*72;
        
        		$pdf->SetPrintHeader(false);
               	$pdf->SetPrintFooter(false);
               	$pdf->SetAutoPageBreak(false, 0);
               	$pdf->SetMargins(0, 0, 0, $keepmargins = false);
               	$orientation = ($pdfwidth > $pdfheight) ? 'L' : 'P';
               	$svgtoimagecreate1 = "";
               	$size = array($pdfwidth, $pdfheight);
               	$pdf->AddPage($orientation, $size);
               	$arr = explode(",", $option[0]['value']);
               	
                  $svgtoimagecreate1 = $svgArr;
                  $svgtoimagecreate = $pdfFile . '/' . "temp" . rand() . ".svg";
                  $zipArr[] = $svgtoimagecreate;
                  $file = fopen($svgtoimagecreate, "w");
                  fwrite($file, $svgtoimagecreate1);
                  fclose($file);

                  $res = $this->maintainratio($pdfwidth, $pdfheight, $width, $height);
                  $left = ($pdfwidth - $res[0]) / 2;
                  $top = ($pdfheight - $res[1]) / 2;
                  
                  $pdf->Rect(0, 0, $pdfwidth, $pdfheight, 'F', array(), array($backgroundColor[0], $backgroundColor[1], $backgroundColor[2]));
                 
				 $pdf->ImageSVG($file = $svgtoimagecreate, $x = 0, $y = 0, $w = $pdfwidth, $h = $pdfheight, $link = 'http://www.tcpdf.org', $align = '', $palign = '', $border = 0, $fitonpage = false);
                  
				
               $zipArr[] = $pdfFileName;

               $pdf->Output($pdfFileName, 'F');
            }

            $fileName = $pdfFile . ".zip";
            $fd = fopen($fileName, "wb");
            $createZip = new ZipFile($fd);
            foreach ($zipArr as $filzip) {
               $zipfileName = substr($filzip, strrpos($filzip, "/") + 1);
               $createZip->addFile($filzip, $zipfileName, true);
            }
            $createZip->close();
            $url = Mage::helper("adminhtml")->getUrl("designpdf/adminhtml_designpdf/deletePDF/", array("orderId" => $orderId));
            $downloadUrl = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB) . 'download.php?fileName=' . $orderId . '.zip';
            //echo $downloadUrl;
            echo '<a style="display: block;" title="Download Pdf" href="' . $downloadUrl . '">Download PDF</a></br>';
            echo '<a href="javascript:void(0);" onclick="generate_pdf(\'' . $url . '\',' . $orderId . ');"> Delete PDF </a>';
         } else {
            echo "Sorry there is no order!!";
         }
      } else {
         echo "PDF already generated!!";
      }
   }

   function setTextQuery($value, $imageDestName) {
      if ($value->fill == '#000000')
         $txtColor = '#000002';
      elseif ($value->fill == '#FFFFFF' || $value->fill == '#ffffff')
         $txtColor = '#FDFFFF';
      else
         $txtColor = $value->fill;
      $garvity = $value->align;
      $fontId = $value->fontID;
      $myfont = Mage::getModel('font/font')->load($fontId);

      $fontFileName = $value->TTFName; 
      //Mage::getBaseDir('media')."/designertool/font/" . $fontTTF;

      $lines = preg_split("/\r\n|[\r\n]/", $value->text_val);
      $countLine = count($lines);
      $text = '';
      for ($i = 0; $i < $countLine; $i++) {
         $text = $text . $lines[$i];
         if ($i != $countLine - 1) {
            $text = $text . " \n ";
         }
      }
      $text = " " . $text . " ";

      $File = "TextFile.txt";
      $Handle = fopen($File, 'w');
      fwrite($Handle, $text);
      fclose($Handle);

      $filpStr = '';
      $arc = '';
      $rotate = 0;
      $end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';

      $query = '  -gravity center -background none -fill "' . $txtColor . '" -font "' . $fontFileName . '"  ' . $filpStr . ' -size 2000x2000 -dither None +antialias label:@"' . $File . '"   ' . $end . '  -trim png:' . $imageDestName;

      return $query;
   }

   function setTextNormalQuery($value, $imageDestName) {
      if ($value->shadowColor1 == '000000')
         $txtColor = '#000002';
      elseif ($value->shadowColor1 == 'FFFFFF' || $value->shadowColor1 == 'ffffff')
         $txtColor = '#FDFFFF';
      else
         $txtColor = '#' . $value->shadowColor1;
      $garvity = $value->align;
      $fontId = $value->fontId;
      $myfont = Mage::getModel('font/font')->load($fontId);

      $fontTTF = $myfont->getFileTtfName();
      $fontFileName = "media/designer_tool_fonts/font_ttf/" . $fontTTF;

      $lines = preg_split("/\r\n|[\r\n]/", $value->text);
      $countLine = count($lines);
      $text = '';
      for ($i = 0; $i < $countLine; $i++) {
         $text = $text . $lines[$i];
         if ($i != $countLine - 1) {
            $text = $text . " \n ";
         }
      }
      $text = " " . $text . " ";

      $File = "TextFile.txt";
      $Handle = fopen($File, 'w');
      fwrite($Handle, $text);
      fclose($Handle);

      $filpStr = '';
      $arc = '';
      $rotate = 0;
      $end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';

      if ($value->arc > 0) {
         $step = 360 / 100;
         $rotate = 0;
         $end = '';
         $arc = $value->arc * $step;
         $end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';
      } else if ($value->arc < 0) {

         $step = 360 / 100;
         $rotate = 180;
         $end = '';
         $arc = $value->arc * (-$step);
         $end .= ' -rotate ' . $rotate . ' -distort Arc "' . $arc . ' ' . $rotate . '"';
      }
      if ($value->reversecut == -1) {
         $filpStr = ' -flop';
         //echo $query = '  -gravity center -background none -fill "#020202" -font "' . $fontFileName . '" "' . $filpStr . '" -size 2000x2000 -dither None +antialias label:@"' . $File . '"   '.$end.' -trim png:' . $imageDestName;exit;
      }
      $query = '  -gravity center -background none -fill "' . $txtColor . '" -font "' . $fontFileName . '" ' . $filpStr . ' -size 2000x2000 -dither None +antialias label:@"' . $File . '"   ' . $end . ' -trim png:' . $imageDestName;

      return $query;
   }

   function shadowforImage($value, $imageDestName, $normalImage, $imageDestName1) {

      if ($value->shadowType == 'br') {
         $x = 15;
         $y = 15;
         $shadowPosition = "+" . $x . "+" . $y;
      } else if ($value->shadowType == 'bl') {
         $x = 15;
         $y = 15;
         $shadowPosition = "-" . $x . "+" . $y;
      } else if ($value->shadowType == 'tr') {
         $x = 15;
         $y = 15;
         $shadowPosition = "+" . $x . "-" . $y;
      } else if ($value->shadowType == 'tl') {
         $x = 15;
         $y = 15;
         $shadowPosition = "-" . $x . "-" . $y;
      }
      $query = ' -size 2000x2000 xc:transparent "' . $normalImage . '" -geometry  ' . $shadowPosition . ' -composite  "' . $imageDestName . '" -geometry +0+0  -composite -trim ' . $imageDestName1;
      return $query;
   }

   public function maintainratio($pdfwidth, $pdfheight, $canvasWidth, $canvasHeight) {

      $result = array();
      $svgratio = $canvasWidth / $canvasHeight;
      $pdfratio = $pdfwidth / $pdfheight;
      if ($pdfwidth >= $pdfheight) {

         $usedwidth = $pdfwidth;
         $usedheight = $pdfwidth / $svgratio;

         if ($usedheight <= $pdfheight) {
            $result[] = $usedwidth;
            $result[] = $usedheight;
         } else {
            $usedheight = $pdfheight;
            $usedwidth = $svgratio * $usedheight;
            $result[] = $usedwidth;
            $result[] = $usedheight;
         }
      } else {
         $usedheight = $pdfheight;
         $usedwidth = $svgratio * $usedheight;
         if ($usedwidth <= $pdfwidth) {

            $result[] = $usedwidth;
            $result[] = $usedheight;
         } else {

            $usedwidth = $pdfwidth;
            $usedheight = $pdfwidth / $svgratio;
            $result[] = $usedwidth;
            $result[] = $usedheight;
         }
      }

      return $result;
   }

   function hex2rgb($color) {
      //echo $color[0].$color[1]
      list($r, $g, $b) = array($color[1] . $color[2],
          $color[3] . $color[4],
          $color[5] . $color[6]);
      $r = hexdec($r);
      $g = hexdec($g);
      $b = hexdec($b);
      return array($r, $g, $b);
   }

}
