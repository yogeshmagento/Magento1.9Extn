<?php

class Sparx_Designpdf_Adminhtml_MaketextController extends Mage_Adminhtml_Controller_action {
	var $string, $counts, $flopVal, $flipVal, $text, $File, $Handle, $m, $designdr, $designDirName, $flipFlopVal, $designDirName1, $fontFileName, $txtColor, $mRatio, $width, $height, $effectName, $isShadow, $strokWid, $stroke, $strokeColor, $query, $magick, $kerning, $resulImg, $imgUrl, $shadowColor, $gravity, $shadowCode, $shadowCode2, $objId,$imageMagickPath;

	public function init($post, $orderId, $widthVal, $heightVal) {
		//echo 'fdgf';
        $this->imageMagickPath = Mage::getStoreConfig('designertool/imagemagick_info/image_magick_path');
        $string = $post;//$_POST['data'];
		$this -> text = trim($string -> data);
		$this -> File = "TextFile.txt";
		$Handle = fopen($this -> File, 'w');
		fwrite($Handle, $this -> text);
		fclose($Handle);
		$this -> counts = count(explode("\n", $this -> text));
		$this -> m = rand();
		$this -> designdr = 'designimage';
		$this -> designDirName = Mage::getBaseDir('media').'/designertool/pdf/'. $orderId ;

		$this -> fontFileName = $string -> Font_name;
		$this -> txtColor = $string -> txtcolor;
		$this -> mRatio = $string -> mRatio;
		$this -> width = $widthVal; //$string -> width;
		$this -> height = $heightVal; //$string -> height;
		$this -> effectName = $string -> effectName;
		$this -> kerning = $string -> characterSpace;
		$this -> gravity = $string -> textAlign;
		$this -> flipVal = $string -> flipVal;
		$this -> flopVal = $string -> flopVal;
		$this -> this -> strokeWidth = 0;
		$this -> isShadow = 0;
		$this -> strokWid = 0;
		$this -> stroke = $string -> strokewidth;
		$this -> strokeColor = 0;
		$this -> query = '';
		$this -> textShadow = $string -> textShadow;
		$this -> textColor = $string -> textColor;
		$this -> borderColor = $string -> borderColor;
		$this -> shadowColor = $string -> shadowColor;
		$this -> objId = $string -> objId;
		// $this -> shadowColor = $string['textShadow'];
		$this -> magick = $this->imageMagickPath;
		$this -> resulImg = $this -> designDirName . "/textLabel" . $this -> objId . ".png";
		$this -> imgUrl = $this -> designDirName . "/textLabel" . $this -> objId . ".png";
		$this -> effectImageURL = $this -> designDirName . "/textLabel" . $this -> objId . ".png";
		//echo $this -> effectImageURL;
		if ($this -> txtColor == '')
			$this -> txtColor = '#000000';
		else
			$this -> txtColor;

		if ($this -> effectName == "Normal") {
			$this -> query = $this -> normal();
			if ($this -> mRatio == 'true') {
				exec($this -> magick . ' ' . $this -> query);
			} else {
				exec($this -> magick . ' ' . $this -> query);
			}
			list($this -> width, $this -> height) = getimagesize($this -> resulImg);
			
			//exec("convert -resize 1000% ".$this -> resulImg."   ".$this -> designDirName ."/label_A_black.png");
			
			

			$obj['imageUrl'] = $this -> imgUrl;
			$obj['imageWidth'] = $this -> width;
			$obj['imageHeight'] = $this -> height;
			//echo stripslashes(json_encode($obj));
		}

		if ($this -> effectName == 'Arch Up') {

			$this -> archUp();
		}

		if ($this -> effectName == 'Arch Down') {
			$this -> archDown();
		}

		if ($this -> effectName == 'Can Up') {
			$this -> canUp();
		}

		if ($this -> effectName == 'Can Down') {
			$this -> canDown();
		}
		if ($this -> effectName == 'Inflate Top') {
			$this -> InflateTop();
		}

		if ($this -> effectName == 'Inflate Bottom') {
			$this -> InflateBottom();
		}

		if ($this -> effectName == 'Cascade Up') {
			$this -> CascadeUp();
		}

		if ($this -> effectName == 'Cascade Down') {
			$this -> CascadeDown();
		}

		if ($this -> effectName == 'Chevron Up') {
			$this -> squeeze();
		}

		if ($this -> effectName == 'Deflate Top') {
			$this -> DeflateTop();
		}
		if ($this -> effectName == 'Deflate Bottom') {
			$this -> DeflateBottom();
		}

		if ($this -> effectName == 'Wave #1') {
			$this -> WaveOneTop();
		}

		if ($this -> effectName == 'Wave #2') {
			$this -> WaveOneBottom();
		}

		if ($this -> effectName == 'Double Wave #1') {
			$this -> DoubleWaveTop();
		}

		if ($this -> effectName == 'Double Wave #2') {
			$this -> DoubleWaveBottom();
		}

		if ($this -> effectName == 'Fade Up') {
			$this -> FadeUp();
		}

		if ($this -> effectName == 'Fade Down') {
			$this -> FadeDown();
		}

		if ($this -> effectName == 'Fade Left') {
			$this -> FadeLeft();
		}

		if ($this -> effectName == 'Fade Right') {
			$this -> FadeRight();
		}

		if ($this -> effectName == 'Stop Sign') {
			$this -> StopSign();
		}

		if ($this -> effectName == 'Triangle Up') {
			$this -> TriangleUp();
		}

		if ($this -> effectName == 'Triangle Down') {
			$this -> TriangleDown();
		}

		if ($this -> effectName == 'Curve Down') {
			$this -> CurveDown();
		}

		if ($this -> effectName == 'Curve Up') {
			$this -> CurveUp();
		}

	}

	public function shadowManage() {

		if ($this -> textShadow == 'None') {
			$this -> shadowCode = ' \( +clone -background "' . $this -> shadowColor . '" -shadow 0 \) -background none -compose DstOver -flatten';

		} else if ($this -> textShadow == 'Top Left') {
			$this -> shadowCode = ' \( +clone -background "' . $this -> shadowColor . '" -shadow 100x2-20-20 \) -background none -compose DstOver -flatten';

		} else if ($this -> textShadow == 'Top Right') {
			$this -> shadowCode = ' \( +clone -background "' . $this -> shadowColor . '" -shadow 100x2+20-20 \) -background none -compose DstOver -flatten';

		} else if ($this -> textShadow == 'Bottom Left') {
			$this -> shadowCode = ' \( +clone -background "' . $this -> shadowColor . '" -shadow 100x2-20+20 \) -background none -compose DstOver -flatten';

		} else if ($this -> textShadow == 'Bottem Right') {
			$this -> shadowCode = ' \( +clone -background "' . $this -> shadowColor . '" -shadow 100x2+20+20 \) -background none -compose DstOver -flatten';

		} else if ($this -> textShadow == 'Slant Left') {
			$this -> shadowCode2 = " -flip +distort SRT '0,0 1,-1 0' \( +clone -background '" . $this -> shadowColor . "' -shadow 100x1+0+0 -virtual-pixel Transparent +distort Affine '0,0 0,0  100,0 100,0  0,100 100,70' \) +swap -background transparent -layers merge -fuzz 2% -trim +repage";

		} else if ($this -> textShadow == 'Slant Right') {
			$this -> shadowCode2 = " -flip +distort SRT '0,0 1,-1 0' \( +clone -background '" . $this -> shadowColor . "' -shadow 100x1+0+0 -virtual-pixel Transparent +distort Affine '0,0 0,0  100,0 100,0  200,100 100,70' \) +swap -background transparent -layers merge -fuzz 2% -trim +repage";

		}

		if ($this -> kerning == 'Smallest') {
			$this -> kerning = -60;
		} else if ($this -> kerning == 'Smaller') {
			$this -> kerning = -40;
		} else if ($this -> kerning == 'Small') {
			$this -> kerning = -20;
		} else if ($this -> kerning == 'Medium') {
			$this -> kerning = 0;
		} else if ($this -> kerning == 'Large') {
			$this -> kerning = 20;
		} else if ($this -> kerning == 'Larger') {
			$this -> kerning = 40;
		} else if ($this -> kerning == 'Largest') {
			$this -> kerning = 60;
		}

	}

	public function flipFlop() {
		if ($this -> flipVal === 'true' && $this -> flopVal === 'true') {
			$this -> flipFlopVal = '-flip -flop';
		} else if ($this -> flipVal === 'true' && $this -> flopVal === 'false') {
			$this -> flipFlopVal = '-flip';
		} else if ($this -> flipVal === 'false' && $this -> flopVal === 'true') {
			$this -> flipFlopVal = '-flop';
		} else if ($this -> flipVal === 'false' && $this -> flopVal === 'false') {
			$this -> flipFlopVal = '';
		}

	}

	public function normal() {
		//echo 'hdfgdfgit'; exit;
		$start = ' -background transparent -depth 8';
		
		$this -> shadowManage();
		$this -> flipFlop();

		if ($this -> mRatio == 'true') {
			if ($this -> stroke != 0) {
				$normalText = ' -density 200x200 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100 -kerning ' . $this -> kerning . ' -strokewidth ' . $this -> stroke . '  -stroke "' . $this -> borderColor . '" -dither None label:@"' . $this -> File . '"' . $this -> shadowCode;
			} else {
				$normalText = ' -density 200x200 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100  -kerning ' . $this -> kerning . ' -dither None label:@"' . $this -> File . '" ' . $this -> shadowCode;
			}

			$this -> query = $start . ' -matte -channel RGBA -virtual-pixel transparent -font "' . $this -> fontFileName . '" ' . '-gravity "' . $this -> gravity . '" ' . $normalText . '    ' . $this -> shadowCode2 . ' -resize "' . $this -> width . '"x"' . $this -> height . '"  +antialias ' . $this -> flipFlopVal . ' -dither None +antialias -trim png: "' . $this -> resulImg . '"';
			//$this -> query = $start . ' -matte -channel RGBA -virtual-pixel transparent -font "' . $this -> fontFileName . '" ' . '-gravity "' . $this -> gravity . '" ' . $normalText . '    ' . $this -> shadowCode2 . ' -resize "' . $this -> width . '"x"' . $this -> height . '"  +antialias ' . $this -> flipFlopVal . ' +antialias  png: "' . $this -> resulImg . '"';
		} else {
			if ($this -> stroke != 0) {
				$normalText = ' -density 200x200 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100 -kerning ' . $this -> kerning . ' -strokewidth ' . $this -> stroke . '  -stroke "' . $this -> borderColor . '" -dither None label:@"' . $this -> File . '"' . $this -> shadowCode;
			} else {
				$normalText = ' -density 200x200 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100  -kerning ' . $this -> kerning . ' -dither None label:@"' . $this -> File . '" ' . $this -> shadowCode;
			}
			//echo 'second';

			$this -> query = $start . ' -matte -channel RGBA -virtual-pixel transparent -font "' . $this -> fontFileName . '" ' . '-gravity "' . $this -> gravity . '" ' . $normalText . '    ' . $this -> shadowCode2 . ' -resize "' . $this -> width . '"x"' . $this -> height . '"\! +antialias ' . $this -> flipFlopVal . ' -dither None +antialias -trim png: "' . $this -> resulImg . '"';
			//$this -> query = $start . ' -matte -channel RGBA -virtual-pixel transparent -font "' . $this -> fontFileName . '" ' . '-gravity "' . $this -> gravity . '" ' . $normalText . '    ' . $this -> shadowCode2 . ' -resize "' . $this -> width . '"x"' . $this -> height . '"\! +antialias ' . $this -> flipFlopVal . ' +antialias  png: "' . $this -> resulImg . '"';
		}

		return $this -> query;
	}

	public function archUp() {

		$start = ' -background transparent -depth 8';

		$this -> shadowManage();
		$this -> flipFlop();

		$distortText = ' -virtual-pixel Transparent -background transparent -distort Arc 120';

		if ($this -> mRatio == 'true') {
			if ($this -> stroke != 0) {
				$normalText = ' -density 300 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100 -kerning ' . $this -> kerning . ' -strokewidth ' . $this -> stroke . '  -stroke "' . $this -> borderColor . '" -dither None label:@"' . $this -> File . '"' . $this -> shadowCode;
			} else {
				$normalText = ' -density 300 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100  -kerning ' . $this -> kerning . ' -dither None label:@"' . $this -> File . '" ' . $this -> shadowCode;
			}

			$this -> query = $start . ' -matte -channel RGBA -virtual-pixel transparent -font "' . $this -> fontFileName . '" ' . '-gravity "' . $this -> gravity . '" ' . $normalText . ' ' . $this -> flipFlopVal . '   ' . $this -> shadowCode2 . ' ' . $distortText . ' -resize "' . $this -> width . '"x"' . $this -> height . '"  -dither None +antialias  -trim png: "' . $this -> effectImageURL . '"';
		} else {
			if ($this -> stroke != 0) {
				$normalText = ' -density 300 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100 -kerning ' . $this -> kerning . ' -strokewidth ' . $this -> stroke . '  -stroke "' . $this -> borderColor . '" -dither None label:@"' . $this -> File . '"' . $this -> shadowCode;
			} else {
				$normalText = ' -density 300 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100  -kerning ' . $this -> kerning . ' -dither None label:@"' . $this -> File . '" ' . $this -> shadowCode;
			}

			$this -> query = $start . ' -matte -channel RGBA -virtual-pixel transparent -font "' . $this -> fontFileName . '" ' . '-gravity "' . $this -> gravity . '" ' . $normalText . '  ' . $this -> flipFlopVal . '  ' . $this -> shadowCode2 . ' ' . $distortText . ' -resize "' . $this -> width . '"x"' . $this -> height . '"\! -dither None +antialias   -trim png: "' . $this -> effectImageURL . '"';
		}

		exec($this -> magick . '  ' . $this -> query);

		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function archDown() {

		$start = ' -background transparent -depth 8';

		$this -> shadowManage();
		$this -> flipFlop();

		$step = 360 / 7;
		$rotate = 180;

		$arc = $distortValue * $step;
		$distortText = " -virtual-pixel Transparent -rotate 170 -distort Arc '180 180' ";
		$this -> query = $this -> resulImg . ' -virtual-pixel Transparent ' . $distortText . ' ' . $this -> effectImageURL;

		if ($this -> mRatio == 'true') {
			if ($this -> stroke != 0) {
				$normalText = ' -density 300 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100 -kerning ' . $this -> kerning . ' -strokewidth ' . $this -> stroke . '  -stroke "' . $this -> borderColor . '" -dither None label:@"' . $this -> File . '"' . $this -> shadowCode;
			} else {
				$normalText = ' -density 300 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100  -kerning ' . $this -> kerning . ' -dither None label:@"' . $this -> File . '" ' . $this -> shadowCode;
			}

			$this -> query = $start . '  -matte -channel RGBA -virtual-pixel transparent -font "' . $this -> fontFileName . '" ' . '-gravity "' . $this -> gravity . '" ' . $normalText . ' ' . $this -> flipFlopVal . '  ' . $this -> shadowCode2 . ' ' . $distortText . ' -resize "' . $this -> width . '"x"' . $this -> height . '"  -dither None +antialias  -trim png: "' . $this -> effectImageURL . '"';
		} else {
			if ($this -> stroke != 0) {
				$normalText = ' -density 300 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100 -kerning ' . $this -> kerning . ' -strokewidth ' . $this -> stroke . '  -stroke "' . $this -> borderColor . '" -dither None label:@"' . $this -> File . '"' . $this -> shadowCode;
			} else {
				$normalText = ' -density 300 -depth 8 -quality 100 -fill "' . $this -> textColor . '"  -pointsize 100  -kerning ' . $this -> kerning . ' -dither None label:@"' . $this -> File . '" ' . $this -> shadowCode;
			}

			$this -> query = $start . '  -matte -channel RGBA -virtual-pixel transparent  -font "' . $this -> fontFileName . '" ' . '-gravity "' . $this -> gravity . '" ' . $normalText . '  ' . $this -> flipFlopVal . '   ' . $this -> shadowCode2 . ' ' . $distortText . ' -resize "' . $this -> width . '"x"' . $this -> height . '"\! -dither None +antialias   -trim png: "' . $this -> effectImageURL . '"';
		}

		exec($this -> magick . '  ' . $this -> query);

		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function canUp() {

		$this -> query = $this -> normal();

		exec($this -> magick . '' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$query = '';
		$distort = -8 * 7;
		$wavelength = $w * 2;
		$this -> query = $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -background none -wave ' . $distort . 'x' . $wavelength . ' -gravity South -dither None +antialias -trim ' . $this -> effectImageURL;

		exec($this -> magick . '  ' . $this -> query);

		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function canDown() {

		$this -> query = $this -> normal();

		exec($this -> magick . '' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$query = '';
		$distort = 8 * 7;
		$wavelength = $w * 2;
		$this -> query = $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -background none -wave ' . $distort . 'x' . $wavelength . ' -gravity South -dither None +antialias -trim ' . $this -> effectImageURL;

		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function InflateTop() {

		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$distortValue = 5;
		$distort = .3 / 7;
		$distort = $distort * $distortValue;

		$tmp0 = $this -> resulImg;
		exec("identify -ping -format %w " . $tmp0 . "", $wd);
		exec("identify -ping -format %h " . $tmp0 . "", $ht);
		$dim = $wd[0] . 'x' . $ht[0];
		exec('convert xc: -format "%[fx:' . $w . '/2]" info:', $halfw);
		exec('convert xc: -format "%[fx:' . $h . '*1.5]" info:', $newhh);
		exec('convert xc: -format "%[fx:1+' . $distort . '+.7]" info:', $a);
		exec('convert xc: -format "%[fx:-' . $distort . ']" info:', $b);

		$this -> query = '' . $this -> resulImg . '  -matte -channel RGBA -virtual-pixel transparent  -background none  -gravity south -extent ' . $w . 'x' . $newhh[0] . ' -distort barrelinverse "0 0 0 1   0 0 ' . $b[0] . ' ' . $a[0] . '  ' . $halfw[0] . ' ' . $newhh[0] . '" -dither None +antialias -trim  ' . $this -> effectImageURL;

		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));

	}

	public function InflateBottom() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$distortValue = 5;
		$distort = .3 / 7;
		$distort = $distort * $distortValue;

		$tmp0 = $this -> resulImg;
		exec("identify -ping -format %w " . $tmp0 . "", $wd);
		exec("identify -ping -format %h " . $tmp0 . "", $ht);
		$dim = $wd[0] . 'x' . $ht[0];
		exec('convert xc: -format "%[fx:' . $w . '/2]" info:', $halfw);
		exec('convert xc: -format "%[fx:' . $h . '*1.5]" info:', $newhh);
		exec('convert xc: -format "%[fx:1+' . $distort . '+.7]" info:', $a);
		exec('convert xc: -format "%[fx:-' . $distort . ']" info:', $b);

		$this -> query = '' . $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -background none  -gravity north -extent ' . $w . 'x' . $newhh[0] . ' -distort barrelinverse "0 0 0 1   0 0 ' . $b[0] . ' ' . $a[0] . '   ' . $halfw[0] . ' 0 " -dither None +antialias -trim   ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function CascadeUp() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$dMax = $h / 3;
		$dPer = $dMax / 8;
		$d = $dPer * 5;

		$x11 = 0;
		$x12 = 0;
		$y11 = 0;
		$y12 = 0;

		$x21 = 0;
		$x22 = $h;
		$y21 = 0;
		$y22 = $h;

		$x31 = $w;
		$x32 = $h;
		$y31 = $w;
		$y32 = $h - $d;

		$x41 = $w;
		$x42 = $d;
		$y41 = $w;
		$y42 = $d;

		$this -> query = $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -interpolate Spline -distort Bilinear "' . $x11 . ',' . $x12 . ',' . $y11 . ',' . $y12 . '  ' . $x21 . ',' . $x22 . ',' . $y21 . ',' . $y22 . '  ' . $x31 . ',' . $x32 . ',' . $y31 . ',' . $y32 . ' ' . $x41 . ',' . $x42 . ',' . $y41 . ',' . $y42 . '"' . " -dither None +antialias " . $this -> effectImageURL;

		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function CascadeDown() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$dMax = $h / 3;
		$dPer = $dMax / 8;
		$d = $dPer * 5;

		$x11 = 0;
		$y11 = $d;
		$x12 = 0;
		$y12 = $d;

		$x21 = 0;
		$y21 = $h;
		$x22 = 0;
		$y22 = $h - $d;

		$x31 = $w;
		$y31 = $h;
		$x32 = $w;
		$y32 = $h;

		$x41 = $w;
		$y41 = 0;
		$x42 = $w;
		$y42 = 0;

		$this -> query = $this -> resulImg . '  -matte -channel RGBA -virtual-pixel transparent -interpolate Spline -distort Bilinear "' . $x11 . ',' . $y11 . ',' . $x12 . ',' . $y12 . '  ' . $x21 . ',' . $y21 . ',' . $x22 . ',' . $y22 . '  ' . $x31 . ',' . $y31 . ',' . $x32 . ',' . $y32 . ' ' . $x41 . ',' . $y41 . ',' . $x42 . ',' . $y42 . '"' . "  -dither None +antialias " . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function DeflateTop() {
		$this -> query = $this -> normal();
		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$this -> query = ' ' . $this -> temp($w, $h * 3, 'South') . ' ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);
		$distort = 0.8;

		$b = $distort * (pow(2 * min($w, $h) / (1.3 * ($w + $h)), 2));
		$a = (1 - $distort);
		$this -> query = ' -matte -channel RGBA -virtual-pixel transparent -monitor ' . $this -> effectImageURL . ' -distort barrelinverse "0 0 0 1   0 ' . $b . ' 0 ' . $a . '" -dither None +antialias -trim  ' . $this -> resulImg;
		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> resulImg);
		$this -> resulImg = str_replace('../', '', $this -> resulImg);
		$obj['imageUrl'] = $this -> resulImg;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function DeflateBottom() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$this -> query = ' ' . $this -> temp($w, $h * 3, 'North') . ' +antialias ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);

		$distort = 0.8;

		$b = $distort * (pow(2 * min($w, $h) / (1.3 * ($w + $h)), 2));
		$a = (1 - $distort);
		$this -> query = '  -matte -channel RGBA -virtual-pixel transparent  -monitor ' . $this -> effectImageURL . ' -distort barrelinverse "0 0 0 1   0 ' . $b . ' 0 ' . $a . '"  -dither None +antialias -trim  ' . $this -> resulImg;

		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> resulImg);
		$this -> resulImg = str_replace('../', '', $this -> resulImg);
		$obj['imageUrl'] = $this -> resulImg;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));

	}

	public function temp($w, $h, $gravity) {

		// if ($this -> strokeWidth > 0) {
		// $strokWid = $this -> strokWid + 5;
		// $strokeText = ' -strokewidth ' . $strokWid . ' -stroke "#' . $this -> stroke . '"';
		// } else
		// $strokeText = '';
		// $color = ($this -> isShadow != "0") ? $this -> strokeColor : $this -> txtColor;

		$start = ' -background transparent -depth 8';
		// if ($color == '000000')
		// $color = '#000002';
		// elseif ($color == 'FFFFFF' || $color == 'ffffff')
		// $color = '#FFE';
		// else
		// $color = '#' . $color;
		$this -> flipFlop();

		if ($this -> stroke != 0)
			$normalText = ' -fill "' . $this -> textColor . '" ' . '-size "' . $w . '"x"' . $h . '!" -strokewidth ' . $this -> stroke . '  -stroke "' . $this -> borderColor . '" -dither None  label:@"' . $this -> File . '"' . $this -> shadowCode;
		else
			$normalText = ' -fill "' . $this -> textColor . '" ' . '-size "' . $w . '"x"' . $h . '!"  -dither None  label:@"' . $this -> File . '"' . $this -> shadowCode;
		$query = $start . ' -font "' . $this -> fontFileName . '" ' . '-gravity "' . $gravity . '" -kerning ' . $this -> kerning . '' . $normalText . ' ' . $this -> flipFlopVal;
		return $query;
	}

	public function WaveOneTop() {

		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$tmpA0 = $this -> resulImg;

		$distort = 1;
		$gravity = "center";
		$bc = 'color';
		$pad = 1;
		$cycles = 1.0;
		exec($this -> magick . '  xc: -format "%[fx:' . $distort . '*' . $h . ']" info:', $amp0);

		exec($this -> magick . '  xc: -format "%[fx:-' . $amp0[0] . ']" info:', $amp);

		exec($this -> magick . '  xc: -format "%[fx:' . $w . '/' . $cycles . ']" info:', $wav);
		exec($this -> magick . '  ' . $tmpA0 . ' -matte -channel RGBA -virtual-pixel transparent  -background none -wave ' . $amp[0] . 'x' . $wav[0] . ' -background none -trim -bordercolor none -border ' . $pad . ' -dither None +antialias  ' . $this -> effectImageURL . '');

		$size = getimagesize($this -> effectImageURL);
		$w = $size[0];
		$h = $size[1];

		if ($h > 450)
			$h = 450;

		exec($this -> magick . '  ' . $this -> effectImageURL . ' -matte -channel RGBA -virtual-pixel transparent  -background none -resize "' . $this -> width . '"x"' . $h . '"\! -dither None +antialias  -trim png:' . $this -> effectImageURL . '');

		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> resulImg = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> resulImg;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function WaveOneBottom() {

		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$tmpA0 = $this -> resulImg;

		$distort = 1;
		$gravity = "center";
		$bc = 'color';
		$pad = 1;
		$cycles = 1.0;
		exec($this -> magick . '  xc: -format "%[fx:' . $distort . '*' . $h . ']" info:', $amp0);

		exec($this -> magick . '  xc: -format "%[fx:' . $amp0[0] . ']" info:', $amp);

		exec($this -> magick . '  xc: -format "%[fx:' . $w . '/' . $cycles . ']" info:', $wav);
		//print_r($wav); exit;
		exec($this -> magick . '  ' . $tmpA0 . ' -matte -channel RGBA -virtual-pixel transparent  -background none -wave ' . $amp[0] . 'x' . $wav[0] . ' -background none -trim -bordercolor none -border ' . $pad . ' -dither None +antialias  ' . $this -> effectImageURL . '');

		$size = getimagesize($this -> effectImageURL);
		$w = $size[0];
		$h = $size[1];

		if ($h > 450) {
			$h = 450;
			exec($this -> magick . '  ' . $this -> effectImageURL . ' -matte -channel RGBA -virtual-pixel transparent  -background none -resize "' . $this -> width . '"x"' . $h . '"\! -dither None +antialias  -trim png:' . $this -> effectImageURL . '');
		}

		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> resulImg = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> resulImg;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function DoubleWaveTop() {

		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$tmpA0 = $this -> resulImg;

		$distort = 0.5;
		$gravity = "center";
		$bc = 'color';
		$pad = 1;
		$cycles = 2.0;
		exec($this -> magick . '  xc: -format "%[fx:' . $distort . '*' . $h . ']" info:', $amp0);

		exec($this -> magick . '  xc: -format "%[fx:-' . $amp0[0] . ']" info:', $amp);

		exec($this -> magick . '  xc: -format "%[fx:' . $w . '/' . $cycles . ']" info:', $wav);
		exec($this -> magick . '  ' . $tmpA0 . ' -matte -channel RGBA -virtual-pixel transparent -background none -wave ' . $amp[0] . 'x' . $wav[0] . ' -background none -trim -bordercolor none -border ' . $pad . ' -dither None +antialias  ' . $this -> effectImageURL . '');

		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> resulImg = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> resulImg;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function DoubleWaveBottom() {

		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$tmpA0 = $this -> resulImg;

		$distort = 0.5;
		$gravity = "center";
		$bc = 'color';
		$pad = 1;
		$cycles = 2.0;
		exec($this -> magick . '  xc: -format "%[fx:' . $distort . '*' . $h . ']" info:', $amp0);

		exec($this -> magick . '  xc: -format "%[fx:' . $amp0[0] . ']" info:', $amp);

		exec($this -> magick . '  xc: -format "%[fx:' . $w . '/' . $cycles . ']" info:', $wav);
		exec($this -> magick . '  ' . $tmpA0 . ' -matte -channel RGBA -virtual-pixel transparent  -background none -wave ' . $amp[0] . 'x' . $wav[0] . ' -background none -trim -bordercolor none -border ' . $pad . ' -dither None +antialias  ' . $this -> effectImageURL . '');

		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> resulImg = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> resulImg;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function FadeUp() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$distortValue = 11;
		$d = 55;

		$x11 = 0;
		$x12 = 0;
		$y11 = $d;
		$y12 = 0;

		$x21 = 0;
		$x22 = $h;
		$y21 = 0;
		$y22 = $h;

		$x31 = $w;
		$x32 = $h;
		$y31 = $w;
		$y32 = $h;

		$x41 = $w;
		$x42 = 0;
		$y41 = $w - $d;
		$y42 = 0;

		$this -> query = $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -distort Perspective "' . $x11 . ',' . $x12 . ',' . $y11 . ',' . $y12 . '  ' . $x21 . ',' . $x22 . ',' . $y21 . ',' . $y22 . '  ' . $x31 . ',' . $x32 . ',' . $y31 . ',' . $y32 . ' ' . $x41 . ',' . $x42 . ',' . $y41 . ',' . $y42 . '"  -dither None +antialias ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> resulImg = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> resulImg;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function FadeDown() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$distortValue = 11;
		$d = 60;

		$x11 = 0;
		$x12 = 0;
		$y11 = 0;
		$y12 = 0;

		$x21 = 0;
		$x22 = $h;
		$y21 = $d;
		$y22 = $h;

		$x31 = $w;
		$x32 = $h;
		$y31 = $w - $d;
		$y32 = $h;

		$x41 = $w;
		$x42 = 0;
		$y41 = $w;
		$y42 = 0;

		$this -> query = $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -distort Perspective "' . $x11 . ',' . $x12 . ',' . $y11 . ',' . $y12 . '  ' . $x21 . ',' . $x22 . ',' . $y21 . ',' . $y22 . '  ' . $x31 . ',' . $x32 . ',' . $y31 . ',' . $y32 . ' ' . $x41 . ',' . $x42 . ',' . $y41 . ',' . $y42 . '"  -dither None +antialias -trim ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> resulImg = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> resulImg;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function FadeLeft() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$dMax = $h / 3;
		$dPer = $dMax / 8;
		$d = $dPer * 5;

		$x11 = 0;
		$y11 = -50;
		$x12 = 0;
		$y12 = $d;

		$x21 = 0;
		$y21 = $h;
		$x22 = 0;
		$y22 = $h - $d;

		$x31 = $w;
		$y31 = $h;
		$x32 = $w;
		$y32 = $h;

		$x41 = $w;
		$y41 = 0;
		$x42 = $w;
		$y42 = 0;

		$this -> query = $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -interpolate Spline -distort Bilinear "' . $x11 . ',' . $y11 . ',' . $x12 . ',' . $y12 . '  ' . $x21 . ',' . $y21 . ',' . $x22 . ',' . $y22 . '  ' . $x31 . ',' . $y31 . ',' . $x32 . ',' . $y32 . ' ' . $x41 . ',' . $y41 . ',' . $x42 . ',' . $y42 . '"' . " -dither None +antialias -trim  " . $this -> effectImageURL;

		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function FadeRight() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$dMax = $h / 3;
		$dPer = $dMax / 8;
		$d = $dPer * 5;

		$x11 = 0;
		$x12 = 0;
		$y11 = 0;
		$y12 = 0;

		$x21 = 0;
		$x22 = $h;
		$y21 = 0;
		$y22 = $h;

		$x31 = $w;
		$x32 = $h;
		$y31 = $w;
		$y32 = $h - $d;

		$x41 = $w;
		$x42 = -50;
		$y41 = $w;
		$y42 = $d;

		$this -> query = $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -interpolate Spline -distort Bilinear "' . $x11 . ',' . $x12 . ',' . $y11 . ',' . $y12 . '  ' . $x21 . ',' . $x22 . ',' . $y21 . ',' . $y22 . '  ' . $x31 . ',' . $x32 . ',' . $y31 . ',' . $y32 . ' ' . $x41 . ',' . $x42 . ',' . $y41 . ',' . $y42 . '"' . "   -dither None +antialias -trim  " . $this -> effectImageURL;

		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function CurveUp() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$dMax = $h / 3;
		$dPer = $dMax / 8;
		$d = $dPer * 5;

		$x11 = 0;
		$y11 = -50;
		$x12 = 0;
		$y12 = $d;

		$x21 = 0;
		$y21 = $h;
		$x22 = 0;
		$y22 = $h - $d;

		$x31 = $w;
		$y31 = $h;
		$x32 = $w;
		$y32 = $h;

		$x41 = $w;
		$y41 = 0;
		$x42 = $w;
		$y42 = 0;

		$this -> query = $this -> resulImg . '  -matte -channel RGBA -virtual-pixel transparent -interpolate Spline -distort Bilinear "' . $x11 . ',' . $y11 . ',' . $x12 . ',' . $y12 . '  ' . $x21 . ',' . $y21 . ',' . $x22 . ',' . $y22 . '  ' . $x31 . ',' . $y31 . ',' . $x32 . ',' . $y32 . ' ' . $x41 . ',' . $y41 . ',' . $x42 . ',' . $y42 . '"' . " -dither None +antialias  -trim png:  " . $this -> effectImageURL;

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> effectImageURL);
		$w = $size[0];
		$h = $size[1];
		$waveW = 2 * $w;
		$lineLen = $this -> counts * 25;

		$this -> query = $this -> effectImageURL . '  -matte -channel RGBA -virtual-pixel transparent -background none -wave ' . $lineLen . 'x' . $waveW . ' -background none -trim -bordercolor none -border 1 -dither None +antialias  -trim png: ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> effectImageURL);
		$w = $size[0];
		$h = $size[1];

		$fh = ($h * 72) / 100;
		$sh = ($h * 28) / 100;

		$this -> query = $this -> effectImageURL . '  -matte -channel RGBA -virtual-pixel transparent -background none -density 300 -depth 8 -quality 100   -distort Perspective "0,0,0,' . $sh . '  0,' . $h . ',0,' . $fh . '  ' . $w . ',0,' . $w . ',0  ' . $w . ',' . $h . ',' . $w . ',' . $h . '" -dither None +antialias   -trim png: ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);

		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function CurveDown() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$dMax = $h / 3;
		$dPer = $dMax / 8;
		$d = $dPer * 5;

		$x11 = 0;
		$x12 = 0;
		$y11 = 0;
		$y12 = 0;

		$x21 = 0;
		$x22 = $h;
		$y21 = 0;
		$y22 = $h;

		$x31 = $w;
		$x32 = $h;
		$y31 = $w;
		$y32 = $h - $d;

		$x41 = $w;
		$x42 = -50;
		$y41 = $w;
		$y42 = $d;

		$this -> query = $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -interpolate Spline -distort Bilinear "' . $x11 . ',' . $x12 . ',' . $y11 . ',' . $y12 . '  ' . $x21 . ',' . $x22 . ',' . $y21 . ',' . $y22 . '  ' . $x31 . ',' . $x32 . ',' . $y31 . ',' . $y32 . ' ' . $x41 . ',' . $x42 . ',' . $y41 . ',' . $y42 . '"' . "   -dither None +antialias -trim  " . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> effectImageURL);
		$w = $size[0];
		$h = $size[1];
		$waveW = 2 * $w;
		$lineLen = $this -> counts * 20;

		$this -> query = $this -> effectImageURL . ' -matte -channel RGBA -virtual-pixel transparent -background none -wave ' . $lineLen . 'x' . $waveW . ' -background none -trim -bordercolor none -border 1 -dither None +antialias ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> effectImageURL);
		$w = $size[0];
		$h = $size[1];

		$fh = ($h * 28) / 100;
		$sh = ($h * 72) / 100;

		$this -> query = $this -> effectImageURL . ' -matte -channel RGBA -virtual-pixel transparent -background none -distort Perspective "0,0,0,0  0,' . $w . ',0,' . $w . '  ' . $w . ',0,' . $w . ',' . $fh . '  ' . $w . ',' . $h . ',' . $w . ',' . $sh . '"  -dither None +antialias -trim ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function StopSign() {
		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$distortValue = 7;
		$distort = 0.05;

		$k = (pow(2 * min($w, $h) / (1.3 * ($w + $h)), 2));
		$b = -$distort * $k;
		$a = (1 + $distort);

		$this -> query = '-monitor ' . $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -distort Barrel "0.0 0.0 0.0 1   0.0 0.0 0.48 0.48"  -dither None +antialias -trim ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> resulImg = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> resulImg;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

	public function TriangleUp() {

		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$distortValue = 5;
		$distort = .3 / 7;
		$distort = $distort * $distortValue;

		$tmp0 = $this -> resulImg;
		exec("identify -ping -format %w " . $tmp0 . "", $wd);
		exec("identify -ping -format %h " . $tmp0 . "", $ht);
		$dim = $wd[0] . 'x' . $ht[0];
		exec('convert xc: -format "%[fx:' . $w . '/2]" info:', $halfw);
		exec('convert xc: -format "%[fx:' . $h . '*1.5]" info:', $newhh);
		exec('convert xc: -format "%[fx:1+' . $distort . '+.49]" info:', $a);
		exec('convert xc: -format "%[fx:-' . $distort . ']" info:', $b);

		$this -> query = '' . $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent  -background none  -gravity south -extent ' . $w . 'x' . $newhh[0] . ' -distort barrelinverse "0 0 0 1   0 0 ' . $b[0] . ' ' . $a[0] . '  ' . $halfw[0] . ' ' . $newhh[0] . '"  -dither None +antialias -trim  ' . $this -> effectImageURL;

		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));

	}

	public function TriangleDown() {

		$this -> query = $this -> normal();

		exec($this -> magick . '  ' . $this -> query);

		$size = getimagesize($this -> resulImg);
		$w = $size[0];
		$h = $size[1];

		$distortValue = 5;
		$distort = .3 / 7;
		$distort = $distort * $distortValue;

		$tmp0 = $this -> resulImg;
		exec("identify -ping -format %w " . $tmp0 . "", $wd);
		exec("identify -ping -format %h " . $tmp0 . "", $ht);
		$dim = $wd[0] . 'x' . $ht[0];
		exec('convert xc: -format "%[fx:' . $w . '/2]" info:', $halfw);
		exec('convert xc: -format "%[fx:' . $h . '*1.4]" info:', $newhh);
		exec('convert xc: -format "%[fx:1+' . $distort . '+.49]" info:', $a);
		exec('convert xc: -format "%[fx:-' . $distort . ']" info:', $b);

		$this -> query = '' . $this -> resulImg . ' -matte -channel RGBA -virtual-pixel transparent -background none  -gravity north -extent ' . $w . 'x' . $newhh[0] . ' -distort barrelinverse "0 0 0 1   0  0  ' . $b[0] . '   ' . $a[0] . '   ' . $halfw[0] . ' 0 "  -dither None +antialias -trim   ' . $this -> effectImageURL;
		exec($this -> magick . '  ' . $this -> query);
		list($this -> width, $this -> height) = getimagesize($this -> effectImageURL);
		$this -> effectImageURL = str_replace('../', '', $this -> effectImageURL);
		$obj['imageUrl'] = $this -> effectImageURL;
		$obj['imageWidth'] = $this -> width;
		$obj['imageHeight'] = $this -> height;
		//echo stripslashes(json_encode($obj));
	}

}

//$maketext = new MakeText();
?>