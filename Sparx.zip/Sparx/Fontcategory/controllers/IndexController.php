<?php
class Sparx_Fontcategory_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/fontcategory?id=15 
    	 *  or
    	 * http://site.com/fontcategory/id/15 	
    	 */
    	/* 
		$fontcategory_id = $this->getRequest()->getParam('id');

  		if($fontcategory_id != null && $fontcategory_id != '')	{
			$fontcategory = Mage::getModel('fontcategory/fontcategory')->load($fontcategory_id)->getData();
		} else {
			$fontcategory = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($fontcategory == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$fontcategoryTable = $resource->getTableName('fontcategory');
			
			$select = $read->select()
			   ->from($fontcategoryTable,array('fontcategory_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$fontcategory = $read->fetchRow($select);
		}
		Mage::register('fontcategory', $fontcategory);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}