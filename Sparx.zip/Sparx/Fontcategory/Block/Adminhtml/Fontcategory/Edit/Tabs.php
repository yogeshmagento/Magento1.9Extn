<?php

class Sparx_Fontcategory_Block_Adminhtml_Fontcategory_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
      parent::__construct();
      $this->setId('fontcategory_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('fontcategory')->__('Font category Information'));
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('fontcategory')->__('Font category Information'),
          'title'     => Mage::helper('fontcategory')->__('Font category Information'),
          'content'   => $this->getLayout()->createBlock('fontcategory/adminhtml_fontcategory_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}