<?php
class Sparx_Fontcategory_Block_Fontcategory extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getFontcategory()     
     { 
        if (!$this->hasData('fontcategory')) {
            $this->setData('fontcategory', Mage::registry('fontcategory'));
        }
        return $this->getData('fontcategory');
        
    }
}