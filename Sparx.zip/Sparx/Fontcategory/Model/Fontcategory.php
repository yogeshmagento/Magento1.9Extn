<?php

class Sparx_Fontcategory_Model_Fontcategory extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('fontcategory/fontcategory');
    }
    
    public function getfontcategory(){
        $categories = Mage::getModel('fontcategory/fontcategory')->getCollection()->getData();
        $categoryArray = array();
        if(count($categories) > 0 ){
            foreach($categories as $category){
                $categoryArray[$category['fontcategory_id']] = $category['title'];
            }
        }
        return $categoryArray;
    }
}