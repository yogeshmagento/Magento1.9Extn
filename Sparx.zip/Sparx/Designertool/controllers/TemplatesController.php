<?php

class Sparx_Designertool_TemplatesController extends Mage_Core_Controller_Front_Action {
	public function indexAction() {
        $this->loadLayout();
        $this->renderLayout();
    }
}
