<?php

class Sparx_Designertool_SavedesignController extends Mage_Core_Controller_Front_Action {

public function unsDeleteDesignAction(){
		$result=array();
	    $result['status']=0;
		$designId=$this->getRequest()->getParam('designId');
		if($designId>0){
			$cookie = Mage::getSingleton('core/cookie');
			$unsavedDesigns = $this->getUnsavedDesign();
			
			$key = array_search($designId, $unsavedDesigns);
				if (false !== $key) {
					unset($unsavedDesigns[$key]);
					$loadDesign = Mage::getModel('designertool/designertool')->load($designId)->delete();
					$designIds = array_unique($unsavedDesigns);    // design id unique         
					$newDesigns = implode('.', $designIds);      // design id array to string

					$cookie = Mage::getSingleton('core/cookie');
					$cookie->set('designIds', $newDesigns, time() + 86400, '/');    // set cookie for save designs
					$result['status']=$designId;
				}
	}
	return $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
}

public function sDeleteDesignAction(){
		$result=array();
	    $result['status']=0;
		$designId=$this->getRequest()->getParam('designId');
		if($designId>0){
					$loadDesign = Mage::getModel('designertool/designertool')->load($designId)->delete();
					$result['status']=$designId;
		}
	return $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
}


	
	public function getCookieDesigns()     
     { 
        $designIds = Mage::getModel('core/cookie')->get('designIds');
        $designIds= explode('.',$designIds);
         return array_filter($designIds);
        
    }
   
    
    public function getUnsavedDesign(){
        $designs = $this->getCookieDesigns();
        foreach($designs as $id){
            $loadDesign = Mage::getModel('designertool/designertool')->load($id);
            if($loadDesign->getAction() == 'saveDesign'){
                $unsaveDesign[] = $loadDesign->getId();
            }
        }
        return $unsaveDesign;
    }
	
	

    

}
