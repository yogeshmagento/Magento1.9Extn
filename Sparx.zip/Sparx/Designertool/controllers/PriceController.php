<?php

class Sparx_Designertool_PriceController extends Mage_Core_Controller_Front_Action {

    var $materialId;
    var $materialSizeId;
    var $otherOptId;
    var $sideId;
    var $doublesidePrice;

    public function indexAction() {
        $this->loadLayout();
        $this->renderLayout();
    }

    public function updatePriceAction() {
        $data = $this->getRequest()->getPost();
        $outputArray = array();
        $this->materialId = $data['materialId'];
        $this->materialSizeId = $data['materialSizeId'];
        $this->otherOptId = $data['otherOptValue']; // other option price
        $this->sideId = $data['sideValue']; 

        // double side price
        if ($this->sideId == '2') {
            $this->doublesidePrice = Mage::helper('material')->getSideInfo($this->materialId);
        } else {
            $this->doublesidePrice = 0;
        }

        if ($data['materialSizeId']) {
            $outputArray['size'] = Mage::helper('designertool')->templateInfo($data);
        }
        $outputArray['tier'] = Mage::helper('material')->getMaterialSizeTierPrice($this->materialId, $this->materialSizeId, $this->doublesidePrice, $this->otherOptId);
        $totalPrice = Mage::helper('material')->calculateQtyPrice($data);
        $outputArray['unitprice'] = number_format($totalPrice / $data['quantity'], 2);
        $outputArray['totalprice'] = number_format($totalPrice, 2);


        $html .= '<div class="tooltip_templates" style="display:block;">
                                        <div id="tooltip_bulk_qty" class="bulk-discount-not" style="width:250px">
                                        <div class="bulk_qty_table">
                                            <table class="data-table">
                                                <tbody><tr>
                                                        <th class="text-left">Quantity</th>
                                                        <th class="text-left">Price per unit</th>
                                                    </tr>';
                                                    
                                                    $mprice = Mage::getModel('material/material')->load($this->materialId)->getPrice();
                                                    
                                                        $doubleside = Mage::getModel('material/sizetier')->getCollection();
                                                        $doubleside->addFieldToFilter( 'material_id', $data['materialId'] )
                                                                    ->addFieldToFilter( 'material_sizeinfo_id', $data['materialSizeId']); 
                                                            foreach ($doubleside as $dprice) {
                                                                $rangeform = $dprice['range_from'];
                                                                $rangeto = $dprice['range_to'];
                                                                $priceon = $dprice['price'];
                                                                $pricedouble = $dprice['doubleside_price'];
                                                                //echo "<pre>"; print_r($pricedouble); exit;

                                                                $totalprice = $priceon + $mprice;
                                                                
                                                             $html .=   '<tr><td>';
                                                             $html .=    $rangeform.'-'.$rangeto;
                                                                    
                                                              $html .=  '</td><td>$'. number_format($totalprice, 2); 
                                                                    
                                                               $html .= '</td></tr>';
                                                                
                                                             }

                                                         
                                          $html .=         ' <tr><td>Above '.$rangeform.'</td><td>Call us on 516-771-9241</td></tr>
                                                </tbody>
                                            </table>
                                        </div></div>
                                    </div>';

                                $outputArray['pricepopup'] = $html;
        

        $this->getResponse()->setBody(json_encode($outputArray));
    }

    public function qtyPriceAction() {
        $data = $this->getRequest()->getPost();
        $price = Mage::helper('material')->calculateQtyPrice($data);
        $this->getResponse()->setBody($price);
    }

    public function qtyCalculatorPriceAction() {
        $priceArray = array();
        $data = $this->getRequest()->getPost();
        
        $customW=$data['customW'];
        $customH=$data['customH'];
        if((isset($customW) && $customW>0) && (isset($customH) && $customH>0)){
                $customAreaVal= $customW*$customH;
                $data['materialSizeId']=$this->getCustomSizeMaterialId($customAreaVal,$data['materialId']);
        }
        
        $this->sideId = $data['sideValue'];
        if ($this->sideId == '2') { 
        $materialId = $data['materialId'];
        $materialSizeId = $data['materialSizeId']; 
        
        $doubleside = Mage::getModel('material/sizetier')->_tierPrice($materialId, $materialSizeId)
                        ->addFieldToFilter('qty', array("lteq" => $data['quantity']));
        foreach ($doubleside as $dprice) {
            $doublesidePrice = $dprice['doubleside_price'];
        }

        $pricval = Mage::getModel('material/material')->load($materialId)->getPrice();
          
        $totalPrice = $doublesidePrice + $pricval; 
        $priceArray['unitprice'] = $totalPrice;
        $priceArray['totalprice'] = $totalPrice * $data['quantity'];


        $html .= '<div class="tooltip_templates" style="display:block;">
                                            <div id="tooltip_bulk_qty" class="bulk-discount-not" style="width:250px">
                                            <div class="bulk_qty_table">
                                                <table class="data-table">
                                                    <tbody><tr>
                                                            <th class="text-left">Quantity</th>
                                                            <th class="text-left">Price per unit</th>
                                                        </tr>';
                                                    

                                                        $mprice = Mage::getModel('material/material')->load($materialId)->getPrice();
                                                            $doubleside = Mage::getModel('material/sizetier')->getCollection();
                                                            $doubleside->addFieldToFilter( 'material_id', $materialId)
                                                                        ->addFieldToFilter( 'material_sizeinfo_id', $materialSizeId); 
                                                                foreach ($doubleside as $dprice) {
                                                                    $rangeform = $dprice['range_from'];
                                                                    $rangeto = $dprice['range_to'];
                                                                    $priceon = $dprice['price'];
                                                                    $pricedouble = $dprice['doubleside_price'];

                                                                    $totalprice = $mprice + $pricedouble;
                                                                    
                                                                 $html .=   '<tr><td>';
                                                                 $html .=    $rangeform.'-'.$rangeto;
                                                                        
                                                                  $html .=  '</td><td>$'. $totalprice; 
                                                                        
                                                                   $html .= '</td></tr>';
                                                                    
                                                                 }

                                                             
                                              $html .=         ' <tr><td>Above '.$rangeform.'</td><td>Call us on 516-771-9241</td></tr>
                                                    </tbody>
                                                </table>
                                            </div></div>
                                        </div>';

            $priceArray['pricepopup2'] = $html;

        } else {
            $this->doublesidePrice = 0; 
        $totalPrice = Mage::helper('material')->calculateQtyPrice($data);

        $priceArray['unitprice'] = number_format($totalPrice / $data['quantity'], 2);
        $priceArray['totalprice'] = $totalPrice;

        $html .= '<div class="tooltip_templates" style="display:block;">
                                            <div id="tooltip_bulk_qty" class="bulk-discount-not" style="width:250px">
                                            <div class="bulk_qty_table">
                                                <table class="data-table">
                                                    <tbody><tr>
                                                            <th class="text-left">Quantity</th>
                                                            <th class="text-left">Price per unit</th>
                                                        </tr>';
                                                    

                                                        $mprice = Mage::getModel('material/material')->load($data['materialId'])->getPrice();
                                                            $doubleside = Mage::getModel('material/sizetier')->getCollection();
                                                            $doubleside->addFieldToFilter( 'material_id', $data['materialId'])
                                                                        ->addFieldToFilter( 'material_sizeinfo_id', $data['materialSizeId'])
                                                                        ->addFieldToFilter('qty', array("lteq" => $data['quantity'])); 
                                                                foreach ($doubleside as $dprice) {
                                                                    $rangeform = $dprice['range_from'];
                                                                    $rangeto = $dprice['range_to'];
                                                                    $priceon = $dprice['price'];
                                                                    $pricedouble = $dprice['doubleside_price'];

                                                                    $totalprice = $mprice + $priceon;
                                                                    
                                                                 $html .=   '<tr><td>';
                                                                 $html .=    $rangeform.'-'.$rangeto;
                                                                        
                                                                  $html .=  '</td><td>$'. $totalprice; 
                                                                        
                                                                   $html .= '</td></tr>';
                                                                    
                                                                 }

                                                             
                                              $html .=         ' <tr><td>Above '.$rangeform.'</td><td>Call us on 516-771-9241</td></tr>
                                                    </tbody>
                                                </table>
                                            </div></div>
                                        </div>';

            $priceArray['pricepopup2'] = $html;

        }
        
        $this->getResponse()->setBody(json_encode($priceArray));
    }
    
    public function getCustomSizeMaterialId($customAreaVal,$materialId){
			$sizeinfo = Mage::getModel('material/sizeinfo')->getCollection()->addFieldToFilter('material_id', $materialId)->getData();
			if (!empty($sizeinfo)) {
				$sColl=array();
				foreach ($sizeinfo as $value) {
						$sColl[$value['material_sizeinfo_id']]= ($value['width'] * $value['height']);
					}
			  asort($sColl);
			  
			  $inc=0;
			  $count=count($sColl);
			  foreach($sColl as $sId=>$sVal){
					if($customAreaVal<=$sVal){
							$materialSizeId=$sId;
							break;
						}
					$inc++;	
					if($inc==$count){
							$materialSizeId=$sId;
							break;
						}	
				  }
			  
			}
			return $materialSizeId;
		}

}
