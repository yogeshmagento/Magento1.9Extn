<?php

class Sparx_Designertool_IndexController extends Mage_Core_Controller_Front_Action {

    public $returndata = array();

    public function indexAction() {
        $this->singleDomainCheck();
        $this->loadLayout();
        $this->renderLayout();
    }

    /**
     * create domain license
     */
    public function singleDomainCheck() {
        $allowed_hosts = array('10.0.4.4', 'projects.thesparxitsolutions.com', 'dev.demosparx.in', 'easysignstore.com', 'www.easysignstore.com');
        if (!in_array($_SERVER['HTTP_HOST'], $allowed_hosts)) {
            echo 'Single domain licensed';
            header($_SERVER['SERVER_PROTOCOL'] . ' 400 Bad Request');
            exit;
        }
    }

    public function colorsModuleAction() {
        $colors = Mage::getModel('color/color')
                ->getCollection()
                ->addFieldToFilter('status', 1);

        $colorarray = array();
        foreach ($colors as $key => $color) {
            $tempcolor = array();
            if ($key == 1) {
                $tempcolor['isDefault'] = $color['color_id'];
            }

            $tempcolor['id'] = $color['color_id'];
            $tempcolor['title'] = $color['title'];
            $tempcolor['value'] = '#' . $color['colorcode'];

            $colorarray[] = $tempcolor;
            unset($tempcolor);
        }

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($colorarray));
    }

    public function fonts_backupAction() {
        $fonts = Mage::getModel('font/font')
                ->getCollection()
                ->addFieldToFilter('status', 1);
        $fontarray = array();
        foreach ($fonts as $key => $font) {
            $tempfont = array();
            if ($key == 1) {
                $tempfont['isDefault'] = $font['font_id'];
            }

            $tempfont['id'] = $font['font_id'];
            $tempfont['title'] = $font['title'];
            $tempfont['normal'] = 'media/designertool/font/' . $font['filename'];
            $tempfont['ai_name'] = $font['font_AI'];

            $fontarray[] = $tempfont;
            unset($tempcolor);
        }

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($fontarray));
    }

    public function fontcategoryAction(){
        $fontcategories = Mage::getModel('fontcategory/fontcategory')->getCollection()
                ->addFieldToFilter('status', 1);
        $fontArray = array();
        foreach ($fontcategories as $key => $fontcategory) {
            $valueArray = array();
            if ($key == 1)
                $valueArray['isDefault'] = $fontcategory['fontcategory_id'];

            $valueArray['id'] = $fontcategory['fontcategory_id'];
            $valueArray['title'] = $fontcategory['title'];


            $fontDataColl = array();

            $fontModel = Mage::getModel('managefont/managefont')->getCollection()
                ->addFieldToFilter('status', array('eq' => 1))
                ->addFieldToFilter('fontcategory_id', $fontcategory['fontcategory_id'])
                ->setOrder('managefont_id', 'asc');

            //echo "<pre>"; print_r($fontModel->getData());

            if ($fontModel->getSize() > 0) {
            $count = 0;
            foreach ($fontModel->getData() as $fontVal) {
                $fontDataArr = array();
                $fontId = $fontVal['managefont_id'];


                $fontDataArr['id'] = $fontId;
                $fontDataArr['title'] = $fontVal['title'];

                $fontDescModel = Mage::getModel('managefont/managefontdesc')->getCollection()
                        ->addFieldToFilter('managefont_id', $fontId)
                        ->setOrder('fonttype_id', 'asc');
                $fontDescData = $fontDescModel->getData();
                if ($fontDescModel->getSize() > 0) {
                    foreach ($fontDescData as $key => $fontDesc) {
                        if (!empty($fontDesc['font_ttf'])) {
                            $fontDataArr[$fontDesc['fonttype_code'] . 'ttf'] = 'media/designertool/font/ttf/' . $fontDesc['font_ttf'];
                            $fontDataArr[$fontDesc['fonttype_code']] = $fontDesc['font_name'];
                        }
                        if ($key == 0):
                           // $fontDataArr['fontImage'] = 'media/designertool/font/original/' . $fontDesc['fonttype_image'];
                        endif;
                    }
                }
                $fontDataColl[] = $fontDataArr; 
                
                $valueArray['fontFamily'] = $fontDataColl;
                 
                }
            }
            $fontArray[] = $valueArray;
            unset($valueArray);
        }

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($fontArray));
    }  
    /*
    for templates
    */
    public function templatesAction(){
    $templates = Mage::getModel('designertool/designertool')->getCollection()->addFieldToFilter('created_by', 'admin');;          
    $templateArray = array();
    foreach ($templates as $key => $temp) {
        $valArray = array();
            $valArray['id'] = $temp['design_id'];
            $valArray['height'] = $temp['height'];
            $valArray['width'] = $temp['width'];
            $valArray['canvasWidth'] = $temp['canvas_width'];
            $valArray['canvasHeight'] = $temp['canvas_height'];
            $valArray['canvasData'] = $temp['canvas_array'];
            //$valArray['previewData'] =  $temp['data_array'];
            $image = $temp['filename']; 
            $path = Mage::getBaseDir('media').'/designertool/designImage/'. $image;
            $type = pathinfo($path, PATHINFO_EXTENSION);
            $data = file_get_contents($path);
            $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data); 
            $valArray['previewData'] = $base64;

           $templateArray[]= $valArray;
           unset($valArray);
        }
    $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($templateArray));
    }
    /*
    end templates
    */
    public function clipartAction() {
        $clipartcategories = Mage::getModel('clipartcategory/clipartcategory')->getCollection()
                ->addFieldToFilter('status', 1);
        $clipartArray = array();
        foreach ($clipartcategories as $key => $clipartcategory) {
            $valueArray = array();
            if ($key == 1)
                $valueArray['isDefault'] = $clipartcategory['clipartcategory_id'];

            $valueArray['id'] = $clipartcategory['clipartcategory_id'];
            $valueArray['categoryName'] = $clipartcategory['title'];

            $cliparts = Mage::getModel('clipart/clipart')->getCollection()
                                ->addFieldToFilter('clipartcategory_id', $clipartcategory['clipartcategory_id']);

            //echo "<pre>"; print_r($cliparts->getData());
                $data = $this->getRequest()->getParams();

                if ($data['catId']) {
                    $cliparts->addFieldToFilter('clipartcategory_id', $data['catId']);
                }

                $clipartnewArray = array();
                foreach ($cliparts as $key => $clipart) {
                    $valuenewArray = array();
                    $valuenewArray['id'] = $clipart['clipart_id'];
                    $valuenewArray['name'] = $clipart['title'];
                    $valuenewArray['thumb'] = Mage::getBaseUrl('media') . 'designertool/clipart/thumb/' . $clipart['filename'];
                    $valuenewArray['large'] = Mage::getBaseUrl('media') . 'designertool/clipart/large/' . $clipart['filename'];
                    $valuenewArray['original'] = Mage::getBaseUrl('media') . 'designertool/clipart/' . $clipart['filename'];
                    $color = $this->getDefaultcolorAction();
                    $clipartnewArray[] = $valuenewArray;
                    unset($valuenewArray);
                    //echo "<pre>"; print_r($clipartnewArray);
                    
                }
                $valueArray['clipartImages'] = $clipartnewArray;
                $clipartArray[] = $valueArray;
            unset($valueArray);
        }

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($clipartArray));
    }



    public function fontsAction() {
        $fontDataColl = array();

        $fontModel = Mage::getModel('managefont/managefont')->getCollection()
                ->addFieldToFilter('status', array('eq' => 1))
                ->setOrder('managefont_id', 'asc');

        if ($fontModel->getSize() > 0) {
            $count = 0;
            foreach ($fontModel->getData() as $fontVal) {
                $fontDataArr = array();
                $fontId = $fontVal['managefont_id'];


                $fontDataArr['id'] = $fontId;
                $fontDataArr['title'] = $fontVal['title'];

                $fontDescModel = Mage::getModel('managefont/managefontdesc')->getCollection()
                        ->addFieldToFilter('managefont_id', $fontId)
                        ->setOrder('fonttype_id', 'asc');
                $fontDescData = $fontDescModel->getData();
                if ($fontDescModel->getSize() > 0) {
                    foreach ($fontDescData as $key => $fontDesc) {
                        if (!empty($fontDesc['font_ttf'])) {
                            $fontDataArr[$fontDesc['fonttype_code'] . 'ttf'] = 'media/designertool/font/ttf/' . $fontDesc['font_ttf'];
                            $fontDataArr[$fontDesc['fonttype_code']] = $fontDesc['font_name'];
                        }
                        if ($key == 0):
                           // $fontDataArr['fontImage'] = 'media/designertool/font/original/' . $fontDesc['fonttype_image'];
                        endif;
                    }
                }
                $fontDataColl[] = $fontDataArr;
                unset($fontDataArr);
            }
        }
        return $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($fontDataColl));
    }
    
    /**
     * get bg font_size
     */
    public function getFontSizeAction() {
        $attributeInfo = Mage::getResourceModel('eav/entity_attribute_collection')
                ->setCodeFilter('font_size')
                ->getFirstItem();
        //echo '<pre>'; print_r($attributeInfo->getData()); exit;
        $default_value = $attributeInfo->getDefaultValue();
        $attributeOptions = $attributeInfo->getSource()->getAllOptions(false);
        $attributeOptionsArray = Mage::helper('designertool')->sizesortArray($attributeOptions);
        $sizearray = array();
        $i = 0;
        foreach ($attributeOptionsArray as $key => $sizeValue) {
            $tempsize = array();

            if ($i == 0)
                $tempsize['isDefault'] = $default_value;

            $tempsize['id'] = $key; //$size['value'];
            $tempsize['size'] = $sizeValue; //$size['label'];
            $sizearray[] = $tempsize;
            unset($tempsize);
            $i++;
        }
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($sizearray));
    }


     /**
     * get bg finish_options
     */
    public function getFinishAction() {
        $attributeInfo = Mage::getResourceModel('eav/entity_attribute_collection')
                ->setCodeFilter('finish_options')
                ->getFirstItem();
        //echo '<pre>'; print_r($attributeInfo->getData()); exit;
        $default_value = $attributeInfo->getDefaultValue();
        $attributeOptions = $attributeInfo->getSource()->getAllOptions(false);
        $attributeOptionsArray = Mage::helper('designertool')->sizesort1Array($attributeOptions);
        $finisharray = array();
        $i = 0;
        foreach ($attributeOptionsArray as $key => $sizeValue) {
            $tempsize = array();

            if ($i == 0)
                $tempsize['isDefault'] = $default_value;

            $tempsize['id'] = $key; //$size['value'];
            $tempsize['size'] = $sizeValue; //$size['label'];
            $finisharray[] = $tempsize;
            unset($tempsize);
            $i++;
        }
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($finisharray));
    }

     /**
     * get bg Grommets
     */
    public function getGrommetsAction() {
        $attributeInfo = Mage::getResourceModel('eav/entity_attribute_collection')
                ->setCodeFilter('grommets_options')
                ->getFirstItem();
        //echo '<pre>'; print_r($attributeInfo->getData()); exit;
        $default_value = $attributeInfo->getDefaultValue();
        $attributeOptions = $attributeInfo->getSource()->getAllOptions(false);
        $attributeOptionsArray = Mage::helper('designertool')->sizesort1Array($attributeOptions);
        $grommetsarray = array();
        $i = 0;
        foreach ($attributeOptionsArray as $key => $sizeValue) {
            $tempsize = array();

            if ($i == 0)
                $tempsize['isDefault'] = $default_value;

            $tempsize['id'] = $key; //$size['value'];
            $tempsize['size'] = $sizeValue; //$size['label'];
            $grommetsarray[] = $tempsize;
            unset($tempsize);
            $i++;
        }
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($grommetsarray));
    }


     /**
     * get bg categories
     */
    public function getBgCategoriesAction() {
        $categories = Mage::helper('designertool/data')->getDropDownValues('designertool_bg_categories');
        //echo "<pre>"; print_r($categories); exit;
        $catColl = array();
        $count = 0;
        if (count($categories) > 0):
            foreach ($categories as $id => $value) {
                $catArr = array();
                $catArr['id'] = $id;
                $catArr['categoryName'] = $value;
                //if ($count++ == 0):
                    $bgImages = $this->getBgImagesAction($catArr);
                    $catArr['backgroundImages'] = Mage::helper('core')->jsonDecode($bgImages);
                //endif;

                $catColl[] = $catArr;
            }
        endif;
        return $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($catColl));
    }

    /**
     * Customer Login or Register on Tool
     */
    public function loginAndRegisterAction() {
        $post_data = $this->getRequest()->getPost();
        //echo "<pre>"; print_r($post_data);
        if (!empty($post_data)) {
            $data = array();
            $message = "";
            Mage::unregister('controller');
            $customerType = $post_data['type'];
            $websiteId = Mage::app()->getWebsite()->getId();
            Mage::init($websiteId, 'website');
            if ($customerType == 'login') {

                $session = Mage::getSingleton('customer/session');
                $email = $post_data['email'];
                $password = $post_data['password'];
                if (!empty($email) && !empty($password)) {
                    try {
                        $session->login($email, $password);
                        $data['status'] = 1;
                        if (Mage::getSingleton('customer/session')->isLoggedIn()) {
                            $customerData = Mage::getSingleton('customer/session')->getCustomer();
                            $data['userId'] = $customerData->getId();
                        }
                        if ($session->getCustomer()->getIsJustConfirmed()) {
                            //$this->_welcomeCustomer($session->getCustomer(), true);
                        }
                    } catch (Mage_Core_Exception $e) {
                        switch ($e->getCode()) {
                            case Mage_Customer_Model_Customer::EXCEPTION_EMAIL_NOT_CONFIRMED:
                                $value = Mage::helper('customer')->getEmailConfirmationUrl($email);
                                $message = Mage::helper('customer')->__('This account is not confirmed. Click here to resend confirmation email.', $value);
                                break;
                            case Mage_Customer_Model_Customer::EXCEPTION_INVALID_EMAIL_OR_PASSWORD:
                                $message = $e->getMessage();
                                break;
                            default:
                                $message = $e->getMessage();
                        }
                        $session->setUsername($email);
                    } catch (Exception $e) {
                        
                    }
                } else {
                    $message = $this->__('Login and password are required.');
                }
                $data['status'] = $data['status'] ? $data['status'] : 0;
                $data['userId'] = $data['userId'] ? $data['userId'] : 0;
                $data['message'] = $message;
            } elseif ($customerType == 'register') {
                $firstName = $post_data['firstName'];
                $lastName = $post_data['lastName'];
                $email = $post_data['email'];
                $password = $post_data['password'];

                $customer = Mage::getModel('customer/customer');
                $customer->setWebsiteId(Mage::app()->getWebsite()->getId());
                $customer->loadByEmail($email);

                if (!$customer->getId()) {
                    $customer->setEmail($email);
                    $customer->setFirstname($firstName);
                    $customer->setLastname($lastName);
                    $customer->setPasswordHash(md5($password));
                    $customer->save();
                    $customer->setConfirmation(null);
                    $customer->save();
                    $customer->sendNewAccountEmail();
                    $session = Mage::getSingleton('customer/session');
                    $session->login($email, $password);
                    $message = "Account created sucessfully";
                    $status = 1;
                } else {
                    $message = $this->__('There is already an account with this email address.');
                    $status = 0;
                }
                try {
                    if (Mage::getSingleton('customer/session')->isLoggedIn()) {
                        $customerData = Mage::getSingleton('customer/session')->getCustomer();
                        $data['userId'] = $customerData->getId();
                    }
                } catch (Exception $e) {
                    $message = $this->__('Invalid customer data');
                }
                $data['message'] = $message;
                $data['status'] = $status;
            }
        }
        echo json_encode($data);
        exit;
        // return $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($data));
    }

    /**
     * get bg images
     */
    public function getBgImagesAction($post) {
        $bgImagesColl = array();

        if (count($post) > 0):
            $bgCategoryId = $post['id'];
        else:
            $post = $this->getRequest()->getPost();
            $bgCategoryId = $post['id'];
        endif;

        if (isset($bgCategoryId) && $bgCategoryId > 0):
            $bgImages = Mage::getModel('bgimages/bgimages')->getCollection()
                            ->addFieldToFilter('bg_category_id', $bgCategoryId)
                            ->addFieldToFilter('status', array('eq' => 1))->getFirstItem()->getFilename();
            $bgImages = json_decode($bgImages);

            if (count($bgImages) > 0):
                foreach ($bgImages as $key => $filename):
                    $bgImgObj = (object) $bgImgObj;
                    $bgImgObj->id = $key;
                    $bgImgObj->title = '';
                    $bgImgObj->thumb = 'media/files/bgimages/thumb/' . $filename;
                    $bgImgObj->large = 'media/files/bgimages/large/' . $filename;
                    $bgImagesColl[] = $bgImgObj;
                    unset($bgImgObj);
                endforeach;
            endif;
        endif;
        return $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($bgImagesColl));
    }

    public function sizesAction() {
        $attributeInfo = Mage::getResourceModel('eav/entity_attribute_collection')
                ->setCodeFilter('font_size')
                ->getFirstItem();
        //echo '<pre>'; print_r($attributeInfo->getData()); exit;
        $default_value = $attributeInfo->getDefaultValue();
        $attributeOptions = $attributeInfo->getSource()->getAllOptions(false);
        $attributeOptionsArray = Mage::helper('designertool')->sizesortArray($attributeOptions);
        $sizearray = array();
        $i = 0;
        foreach ($attributeOptionsArray as $key => $sizeValue) {
            $tempsize = array();

            if ($i == 0)
                $tempsize['isDefault'] = $default_value;

            $tempsize['id'] = $key; //$size['value'];
            $tempsize['value'] = $sizeValue; //$size['label'];
            $sizearray[] = $tempsize;
            unset($tempsize);
            $i++;
        }
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($sizearray));
    }

    public function colorsAction() {
        $coll = Mage::getModel('color/color')->getCollection()->addFieldToFilter('status', array('eq' => 1));
        //echo '<pre>'; print_r($coll->getData()); exit;
        $colorarray = array();
        foreach ($coll as $key => $color) {
            $tempcolor = array();

            if ($key == 0)
                $tempcolor['isDefault'] = $default_value;

            $tempcolor['id'] = $color['color_id'];
            $tempcolor['title'] = $color['title'];
            $tempcolor['colorCode'] = $color['colorcode'];
            $colorarray[] = $tempcolor;
            unset($tempcolor);
        }

        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($colorarray));
    }

    /**
    Shape
    **/

    public function shapesAction(){
        $shapes = Mage::getModel('shape/shape')->getCollection()
                ->addFieldToFilter('status', 1);

        $shapeArray = array();
            foreach ($shapes as $key => $shapesValue) {
                $newvalueArray = array();
                if ($key == 1)
                    $newvalueArray['isDefault'] = $shapesValue['shape_id'];

                $newvalueArray['id'] = $shapesValue['shape_id'];
                $newvalueArray['previewData'] = 'media/designertool/shape/' . $shapesValue['filename'];

                $shapeArray[] = $newvalueArray;
                unset($newvalueArray);
            }
         $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($shapeArray));
    }

    

    public function imagesAction() {
        $cliparts = Mage::getModel('clipart/clipart')->getCollection();
        $data = $this->getRequest()->getParams();

        if ($data['catId']) {
            $cliparts->addFieldToFilter('clipartcategory_id', $data['catId']);
        }

        if ($data['subcatId']) {
            $cliparts->addFieldToFilter('clipartsubcategory_id', $data['subcatId']);
        }

        $clipartArray = array();
        foreach ($cliparts as $key => $clipart) {
            $valueArray = array();
            $valueArray['id'] = $clipart['clipart_id'];
            $valueArray['title'] = $clipart['title'];
            $valueArray['isColorable'] = $clipart['colorable'];
            $valueArray['thumb'] = Mage::getBaseUrl('media') . 'designertool/clipart/thumb/' . $clipart['filename'];
            $valueArray['large'] = Mage::getBaseUrl('media') . 'designertool/clipart/large/' . $clipart['filename'];
            $valueArray['original'] = Mage::getBaseUrl('media') . 'designertool/clipart/' . $clipart['filename'];
            $color = $this->getDefaultcolorAction();
            $valueArray['color'] = "#000000";
            $valueArray['colorId'] = "7";
            $clipartArray[] = $valueArray;
            unset($valueArray);
        }
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($clipartArray));
    }

    private function getDefaultcolorAction() {
        $attributeInfo = Mage::getResourceModel('eav/entity_attribute_collection')
                ->setCodeFilter('color')
                ->getFirstItem();
        $attributeInfo['source_model'] = 'eav/entity_attribute_source_table';

        $default_value = $attributeInfo->getDefaultValue();
        $attributeOptions = $attributeInfo->getSource()->getAllOptions(false);
        foreach ($attributeOptions as $key => $color) {
            if ($color['value'] = $default_value) {
                return array('id' => $default_value, 'code' => $color['details']);
            }
        }
    }

    // search clipart action
    public function searchClipartAction() {
        $searchname = $this->getRequest()->getParam('name');
        $cliparts = Mage::getModel('clipart/clipart')->getCollection()->addFieldToFilter('title', array('like' => "%" . $searchname . "%"));
        $clipartArray = array();
        foreach ($cliparts as $key => $clipart) {
            $valueArray = array();
            $valueArray['id'] = $clipart['clipart_id'];
            $valueArray['title'] = $clipart['title'];
            $valueArray['isColorable'] = $clipart['colorable'];
            $valueArray['thumb'] = Mage::getBaseUrl('media') . 'designertool/clipart/thumb/' . $clipart['filename'];
            $valueArray['large'] = Mage::getBaseUrl('media') . 'designertool/clipart/large/' . $clipart['filename'];
            $valueArray['original'] = Mage::getBaseUrl('media') . 'designertool/clipart/' . $clipart['filename'];
            $color = $this->getDefaultcolorAction();
            $valueArray['color'] = "#000000";
            $valueArray['colorId'] = "7";
            $clipartArray[] = $valueArray;
            unset($valueArray);
        }
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($clipartArray));
    }

    public function testAction() {
        echo sprintf(Mage::getStoreConfig('designertool/errormessage_info/extension_error_message'), '.eps');
    }

    public function materialsizeAction() {
        $id = $this->getRequest()->getParam('mid');
        $sizeHtml = Mage::getModel('material/material')->_getMaterialSizeHtml($id);
        $this->getResponse()->setBody($sizeHtml);
    }

    public function templateInfoAction() {
        $data = $this->getRequest()->getPost();
        //echo "<pre>"; print_r($data); exit;
        $tempInfo = Mage::helper('designertool')->templateInfo($data);
        $this->getResponse()->setBody(json_encode($tempInfo));
    }

    public function saveAction() {
        $data = $this->getRequest()->getPost();
        //echo "<pre>"; print_r($data); exit;
        $toolModel = Mage::getModel('designertool/designertool');
        $tooldata['canvas_array'] = $data['canvasArr'];
        $tooldata['svg_arr'] = json_encode($data['svgArr']);
        $tooldata['data_array'] = json_encode($data['dataArray']);
        $tooldata['canvas_width'] = $data['canvasWidth'];
        $tooldata['canvas_height'] = $data['canvasHeight'];
        $tooldata['custom_width'] = $data['customWidth'];
        $tooldata['custom_height'] = $data['customHeight'];
        $tooldata['material_size_id'] = $data['materialSizeId'];
        $tooldata['material_id'] = $data['materialId'];
        $tooldata['created_by'] = 'User';
        $tooldata['product_id'] = $data['productId'];
        $tooldata['action'] = $data['action'];
        $tooldata['background_color'] = $data['backgroundColor'];
        $tooldata['background_alpha'] = $data['backgroundAlpha'];
        $tooldata['height'] = $data['height'];
        $tooldata['width'] = $data['width'];
        $tooldata['print_height'] = $data['printHeight'];
        $tooldata['print_width'] = $data['printWidth'];
		$tooldata['finish_options'] = $data['finishOptions'];
		$tooldata['grommets_options'] = $data['grommetsOptions'];

        if ($data['previewImg'])
            $tooldata['filename'] = Mage::helper('designertool')->createDesignimage($data['previewImg']);

        $toolModel->setData($tooldata);

//        if ($data['designId'])
//            $toolModel->setId($data['designId']);

        if ($toolModel->getCreatedTime == NULL || $toolModel->getUpdateTime() == NULL) {
            $toolModel->setCreatedTime(now())
                    ->setUpdateTime(now());
        } else {
            $toolModel->setUpdateTime(now());
        }

        $toolModel->save();

        $this->saveDesignsInCookie($toolModel->getId()); // designs save in browser cookie

        if ($data['action'] == 'saveDesign') {
            $this->returndata['action'] = 'saveDesign';
            $this->returndata['message'] = 'Your design has been saved under <a href="' . Mage::getUrl('designertool/index/savedesigns') . '" style="font-weight:600;">My Signs</a> section';
        }

        if ($data['action'] == 'email') {
            $this->sendDesignToFriend($data['emailData'], $toolModel->getId());
            //echo "<pre>"; print_r($toolModel->getId());
            $this->returndata['message'] = "Your design has been emailed to your friend.";
            $this->returndata['action'] = 'email';
        }

        if ($data['action'] == 'save') {

            $parameter = array(
                'tab' => 3,
                'designId' => $toolModel->getId());
            $this->returndata['url'] = Mage::getUrl('designertool/index/index', $parameter);
            $this->returndata['action'] = 'save';
            $this->returndata['designId'] = $toolModel->getId();
        }

        if ($data['action'] == 'share') {

            $returnHtml = '';
            $returnHtml .= '<table cellspacing="5" cellpadding="0" border="0" width="270" style="border:solid 1px #999999;background-color:#ffffff;">
                        <tbody><tr>
                            <td>
                                <center>
                                    <a target="_blank" href="' . Mage::getUrl('designertool/share', array('id' => $toolModel->getId())) . '">
                                        <img border="0" alt="Check Out This Design At Milkstore.com!" src="' . Mage::getBaseUrl('media') . 'designertool/designImage/' . Mage::getModel('designertool/designertool')->load($toolModel->getId())->getFilename() . '" width="163">
                                    </a>
                                    <br>
                                    <div style="margin-left: 55px;">
                                        <div style="font-size: 14px; height: 27px; line-height: 28px; border-style: solid; border-width: 2px; border-radius: 4px; clear: both; box-shadow: 1px 1px 0.5px rgb(255, 255, 255) inset, -1px -1px 0.5px rgb(255, 255, 255) inset; cursor: pointer; display: block; float: left; font-family: Arial,Helvetica,sans-serif; margin: 10px 10px 10px 0px; outline: medium none; padding: 0px 12px; text-align: center; width: auto; color: rgb(255, 255, 255); background: -moz-linear-gradient(center top , rgb(83, 168, 70), rgb(83, 168, 70)) repeat scroll 0px 0px transparent; border-color: rgb(62, 176, 57);">
                                            <a style="color: #fff; display: block; font-weight: bold; font-size: 14px; text-decoration: none;" border="0" target="_blank" href="' . Mage::getUrl('designertool/share', array('id' => $toolModel->getId())) . '">Design Your Own!</a>
                                        </div>
                                        <div style="clear:both"></div>                        
                                    </div>
                                    <div style="padding-top:5px;">
                                        <a style="font-size: 16px; font-family: Arial; font-weight: bold; color: rgb(62, 176, 57);" href="' . Mage::getBaseUrl() . '">Custom Signs</a>
                                    </div>
                                </center>
                            </td>
                        </tr>
                    </tbody></table>';
            $this->returndata['action'] = 'share';
            $this->returndata['shareurl'] = Mage::getUrl('designertool/share', array('id' => $toolModel->getId()));
            $this->returndata['htmlcontent'] = $returnHtml;
            //$this->getResponse()->setBody(json_encode($this->returndata));
        }

        $this->getResponse()->setBody(json_encode($this->returndata));
    }

    public function editAction() {
        $designId = $this->getRequest()->getPost('designId');
        $designdata = Mage::helper('designertool')->retriveDesigndata($designId);
        $this->getResponse()->setBody(json_encode($designdata));
    }

    public function materialOptionsAction() {
        $data = $this->getRequest()->getPost();
        $materialId = $data['materialId'];
        if (!isset($materialId) || $materialId==0) {
            $materialId = Mage::getModel('material/material')->getDefaultMaterialId($materialId);
        }

        $materialSizeId = $data['materialSizeId'];
        if (!isset($materialSizeId)) {
            $materialSizeId = Mage::getModel('material/sizeinfo')->getDefaultSizeId($materialId);
        }

        $materialSizeInfo = Mage::getModel('material/sizeinfo')->load($materialSizeId);
        $outputArray = array();
        $outputArray['material'] = Mage::helper('material')->getEquivalentMaterial($materialId, $materialSizeInfo->getSizeRatio());
        $outputArray['material_size'] = Mage::helper('material')->getEquivalentSize($materialId, $materialSizeId, $materialSizeInfo->getSizeRatio());
        $outputArray['material_otherinfo'] = Mage::helper('material')->getOtherinfoData($materialId);

        $side = Mage::getModel('material/sizeinfo')->_IsDoubleSide($materialId);
        $outputArray['sides'] = $side;

        $doubleside = Mage::getModel('material/sizetier')->_tierPrice($materialId, $materialSizeId)
                        ->addFieldToFilter('qty', array("lteq" => $data['quantity']));
        foreach ($doubleside as $dprice) {
            $doublesidePrice = $dprice['doubleside_price'];
        }

        $outputArray['tier'] = Mage::helper('material')->getMaterialSizeTierPrice($materialId, $materialSizeId, $doublesidePrice=0); //first time double price is not selected on calculator. so double price should be zero.

        $category = new Mage_Catalog_Model_Category();
                $category->load($id);
                $collection = $category->getProductCollection();
                $collection->addAttributeToSelect('*');
                $collection->addAttributeToFilter('status', 1);
                $collection->addFieldToFilter(array(array('attribute'=>'visibility', 'neq'=>"1" )));
                $collection->getSelect()->limit(100);
                $urlcheck = array();
                foreach ($collection as $key=>$shopProduct) {
                    $productId = $shopProduct['entity_id'];
                    $product = Mage::getModel('catalog/product')->load($shopProduct['entity_id']);

                    $productUrl = $shopProduct->getProductUrl();
                    $urlcheck[$key]['product_id'] = $productId;
                    $urlcheck[$key]['product_url'] = $productUrl;
                    $urlcheck[$key]['material_data'] = $product->getMaterialData();

                }

                $producturl1 = array();
                    foreach($urlcheck as $u){
                        $designs = Mage::getModel('material/material')->getCollection()->addFieldToFilter('title', $u['material_data'])->getData();

                    $design = Mage::getModel('designertool/designertool')->getCollection()->addFieldToFilter('created_by', 'admin')
                    ->addFieldToFilter('product_id', $u['product_id'])
                    ->addFieldToFilter('material_id', $materialId);
                        if(!empty($design->getData())){
                            $producturl1 = $u['product_url']; 

                    }
                }
                
                $htmlu .= '<input type="hidden" name="ihaveartwork" id = "ihaveartwok" value="'.$producturl1. '">';
                $outputArray['producturl']= $htmlu;


            $html .= '<div class="tooltip_templates" style="display:block;">
                                            <div id="tooltip_bulk_qty" class="bulk-discount-not" style="width:250px">
                                            <div class="bulk_qty_table">
                                                <table class="data-table">
                                                    <tbody><tr>
                                                            <th class="text-left">Quantity</th>
                                                            <th class="text-left">Price per unit</th>
                                                        </tr>';
                                                        
                                                        $mprice = Mage::getModel('material/material')->load($materialId)->getPrice();
                                                         $doubleside = Mage::getModel('material/sizetier')->getCollection();
                                                            $doubleside->addFieldToFilter( 'material_id', $materialId)
                                                                        ->addFieldToFilter( 'material_sizeinfo_id', $materialSizeId); 
                                                                foreach ($doubleside as $dprice) {
                                                                    $rangeform = $dprice['range_from'];
                                                                    $rangeto = $dprice['range_to'];
                                                                    $priceon = $dprice['price'];
                                                                    $pricedouble = $dprice['doubleside_price'];

                                                                    $totalprice = $priceon + $mprice;
                                                                    
                                                                 $html .=   '<tr><td>';
                                                                 $html .=    $rangeform.'-'.$rangeto;
                                                                        
                                                                  $html .=  '</td><td>$'. $totalprice; 
                                                                        
                                                                   $html .= '</td></tr>';
                                                                    
                                                                 }

                                                             
                                              $html .=         ' <tr><td>Above '.$rangeform.'</td><td>Call us on 516-771-9241</td></tr>
                                                    </tbody>
                                                </table>
                                            </div></div>
                                        </div>';

            $outputArray['pricepopup2'] = $html;

        $this->getResponse()->setBody(json_encode($outputArray));
    }
    

    // add to cart
    public function addAction() {
        $data = $this->getRequest()->getPost();
        //echo "<pre>"; print_r($data); exit;
        $materialIdinfo = $data['materialId'];
            $materilId = Mage::getModel('material/material')->load($materialIdinfo);
            $materialName =  $materilId->getTitle();

        if((isset($data['customWidth']) && $data['customWidth']>0) && (isset($data['customHeight']) && $data['customHeight']>0)){
            $materialsizeName = 0;
        }else{
            $materilSizename = $data['materialSizeId'];
            $materialSizeInfo = Mage::getModel('material/sizeinfo')->load($materilSizename);
            $materialsizeName =  $materialSizeInfo->getTitle();
        }  

        $productId=  isset($data['productId'])?$data['productId']:0;
        Mage::helper('designertool/products_customoption')->setDesignCodeCustomOption($productId);
        $optionArray = Mage::helper('designertool/products_customoption')->sendCustomOptionArray($productId);
        // set unique design Id
        $data['uid'] = $optionArray['designCodeValue'];
        $designQuote = Mage::getModel('designertool/designquote')->saveCustomData($data);
        $_product = Mage::getModel('catalog/product')->load($productId);
        $finishName = $data['finishOptions'];
        $grommetsName = $data['grommetsOptions'];


        $name='finish_options';
            $attributeInfo = Mage::getResourceModel('eav/entity_attribute_collection')->setCodeFilter($name)->getFirstItem();
            $attributeId = $attributeInfo->getAttributeId();
            $attribute = Mage::getModel('catalog/resource_eav_attribute')->load($attributeId);
            $attributeOptions = $attribute ->getSource()->getAllOptions(false); 

            foreach($attributeOptions as $catVal){ 
                $catValue = $catVal['value'];
                $catlabel = $catVal['label'];
                if($finishName == $catValue){
                  $finishNames = $catlabel;
                }
            }

        $name='grommets_options';
            $attributeInfo = Mage::getResourceModel('eav/entity_attribute_collection')->setCodeFilter($name)->getFirstItem();
            $attributeId = $attributeInfo->getAttributeId();
            $attribute = Mage::getModel('catalog/resource_eav_attribute')->load($attributeId);
            $attributeOptions = $attribute ->getSource()->getAllOptions(false); 

            foreach($attributeOptions as $catVal){ 
                $catValue = $catVal['value'];
                $catlabel = $catVal['label'];
                if($grommetsName == $catValue){
                  $grommetsNames = $catlabel;
                }
            }


        $queryStr='';
        $queryStr.= ' ('.'Material Name = '.$materialName.'), 
        (Size Info = '.$materialsizeName.'),
        (Double Side = '.$data['sideValue'].'),
        (Finishing Info = '.$finishNames.'),
        (Grommets Info = '.$grommetsNames.')';
        if((isset($data['customWidth']) && $data['customWidth']>0) && (isset($data['customHeight']) && $data['customHeight']>0)){
             $queryStr.=',(Custom Size = '.$data['customWidth'].'*'.$data['customHeight'].')';
         }

        $params = array(
            'product' => $productId,
            'materialId' => $materialName,
            'sizeInfo' => $materialsizeName,
            'doubleSide' => $data['sideValue'],
            'customWidth' => $data['customWidth'],
            'customHeight' => $data['customHeight'],
            'qty' => $data['quantity'],
            'options' => array(
                $optionArray['customOptions']['id'] => $optionArray['customOptions']['value'].' info# '.$queryStr
            )
        );

        //echo "<pre>"; print_r($params); exit;

        try {
            // Load the cart, add the product, and save!  You can also update the cart to say it was updated, but that is not required
            $cart = Mage::getModel('checkout/cart');
            $cart->init();
            $cart->addProduct($_product, $params);
            $cart->save();
            Mage::getSingleton('checkout/session')->setCartWasUpdated(true);
        } catch (Exception $e) {
            $error = $e;
        }
        $this->getResponse()->setBody(Mage::getUrl('checkout/cart'));
    }

    // get all save designs
    public function savedesignsAction() {

        $this->loadLayout();
        $this->renderLayout();
    }

   private function sendDesignToFriend($data, $designId) {
        $postArr=array();
        //echo "<pre>"; print_r($data);
        // Set sender information
        $postArr['sender_email']=$senderEmail = $data[0]['email_id_from'];
        
        // Set recepient information
        $postArr['recepient_email_id']= $data[0]['email_id_to'];
        $postArr['recepient_name'] = $data[0]['email_id_to'];
        
        // Set variables that can be used in email template. To get this variable write like {{var customerEmail}} in transactional Email.
        $postArr['custom_vals']= array(
            'email_from' => $senderEmail,
            'optional_message' => $data[0]['email_message'],
            'design_url' => Mage::getUrl('designertool', array('tab' => 2, 'designId' => $designId))
        );
        
        // send email
        $emailResult = $this->sendCustomTransactionalEmail($postArr);
        
        if ($data[0]['checkbx'] == 'true')
            Mage::getModel('newsletter/subscriber')->subscribe($senderEmail); /* To Subscribe */
        else
            Mage::getModel('newsletter/subscriber')->loadByEmail($senderEmail)->unsubscribe(); /* To Unsubscribe */
    }
    
     /**
     * send custom mail
     * @param type $post
     * 
     */
    private function sendCustomTransactionalEmail($post) {
        $receiveEmail = $post['recepient_email_id'];
        $receiveName = strstr($post['recepient_email_id'], '@', true);
        $vars = $post['custom_vals']; 
        
        $senderName = strstr($post['sender_email'], '@', true);

        $templateId = 1;
        $emailTemplate = Mage::getModel('core/email_template')->load($templateId);
        $emailTemplate->setSenderEmail($post['sender_email']);
        $emailTemplate->setSenderName($senderName);
        $emailTemplate->send($receiveEmail, $receiveName, $vars);
    }

    private function saveDesignsInCookie($designId) {
        $designIds = Mage::getModel('core/cookie')->get('designIds'); // get exists cookie

        if (!empty($designIds))     // explode into a array
            $designIds = explode('.', $designIds);
        else
            $designIds = array();


        if ($designId) // add new design id to cookie
            $designIds[] = $designId;

        $designIds = array_unique($designIds);    // design id unique         
        $newDesigns = implode('.', $designIds);      // design id array to string

        $cookie = Mage::getSingleton('core/cookie');
        $cookie->set('designIds', $newDesigns, time() + 86400, '/');    // set cookie for save designs
    }

    public function savesignAction() {
        $designId = $this->getRequest()->getParam('id');
        $model = Mage::getModel('designertool/designertool')->load($designId);
        $model->setAction('saveDesign');
        $model->save();

        $this->getResponse()->setBody(TRUE);
    }

    public function deletesignAction() {
        
    }
    
    public function amazonReviewAction(){
        echo '<iframe src="http://flycart9.mybigcommerce.com/blog/" height="500" width="400"></iframe>';
        exit;
    }

}
