<?php
class Sparx_Designertool_ShareController extends Mage_Core_Controller_Front_Action {

    public function indexAction() { 
        $this->loadLayout();
        $this->getLayout()->getBlock('head')->setTitle($this->__('Sign Designer - Check Out This Design At Signdesigner.com  '));
        $this->renderLayout();
    }    

}
