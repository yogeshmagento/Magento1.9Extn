<?php

$installer = $this;

$installer->startSetup();

$installer->run("

ALTER TABLE {$this->getTable('designertool/designertool')}
ADD COLUMN `svg_arr` longtext NOT NULL DEFAULT '' after `canvas_array`
    ");

$installer->endSetup();
