<?php

$installer = $this;

$installer->startSetup();

$installer->run("

ALTER TABLE {$this->getTable('designertool/designertool')}
ADD COLUMN `user_id` int(11) unsigned NOT NULL after canvas_array,
ADD COLUMN `is_user_save` int(11) unsigned NOT NULL after canvas_array,
ADD COLUMN `is_deleted` smallint(3) unsigned NOT NULL after canvas_array;
    ");

$installer->endSetup();
