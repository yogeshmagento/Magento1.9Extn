<?php

$installer = new Mage_Catalog_Model_Resource_Setup('module_setup');
$installer->startSetup();
$installer->updateAttribute('catalog_product', 'material', array('attribute_code' => 'material_data'));
$installer->endSetup();
