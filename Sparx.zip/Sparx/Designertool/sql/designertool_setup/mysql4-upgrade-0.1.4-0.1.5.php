<?php

$installer = $this;

$installer->startSetup();

$installer->run("

ALTER TABLE {$this->getTable('designertool/designertool')}
ADD COLUMN `canvas_width` varchar(50) NOT NULL DEFAULT '' after `action`,
ADD COLUMN `canvas_height` varchar(50) NOT NULL DEFAULT '' after `action`
    ");

$installer->endSetup();
