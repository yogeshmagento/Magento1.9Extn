<?php

$installer = $this;

$installer->startSetup();

$installer->run("

ALTER TABLE {$this->getTable('designertool/designertool')}
ADD COLUMN `finish_options` varchar(50) NOT NULL DEFAULT '' after `action`,
ADD COLUMN `grommets_options` varchar(50) NOT NULL DEFAULT '' after `action`
    ");

$installer->endSetup();
