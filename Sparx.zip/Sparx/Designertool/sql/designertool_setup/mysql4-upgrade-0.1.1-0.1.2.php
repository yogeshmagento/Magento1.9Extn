<?php

$installer = $this;

$installer->startSetup();

$installer->run("

ALTER TABLE {$this->getTable('designertool/designertool')}
ADD COLUMN `tool_output` text NOT NULL DEFAULT '' after `action`
    ");

$installer->endSetup();
