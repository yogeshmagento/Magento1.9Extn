<?php

$installer = $this;

$installer->startSetup();

$installer->run("

ALTER TABLE {$this->getTable('designertool/designertool')}
ADD COLUMN `custom_width` varchar(50) NOT NULL DEFAULT '' after `action`,
ADD COLUMN `custom_height` varchar(50) NOT NULL DEFAULT '' after `action`
    ");

$installer->endSetup();
