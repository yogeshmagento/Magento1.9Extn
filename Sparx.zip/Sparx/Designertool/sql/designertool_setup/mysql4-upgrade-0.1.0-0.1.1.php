<?php

$installer = $this;

$installer->startSetup();

$installer->run("

-- DROP TABLE IF EXISTS {$this->getTable('designertool/designquote')};
CREATE TABLE {$this->getTable('designertool/designquote')} (
  `custom_quote_id` int(11) unsigned NOT NULL auto_increment,
  `item_id` int(11),
  `design_id` int(11),
  `product_id` int(11),
  `material_id` int(11),
  `material_size_id` int(11),
  `material_option_id` int(11),
  `price` varchar(255) NOT NULL default '',
  `qty` int(11),
  `name` varchar(255) NOT NULL default '',
  `side_id` int(11),
  `design_unique_id` varchar(255) NOT NULL default '',
  PRIMARY KEY (`custom_quote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    ");

$installer->endSetup(); 