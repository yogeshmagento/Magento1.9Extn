<?php

$installer = $this;

$installer->startSetup();

$installer->run("

-- DROP TABLE IF EXISTS {$this->getTable('designertool')};
CREATE TABLE {$this->getTable('designertool')} (
  `design_id` int(11) unsigned NOT NULL auto_increment,
  `product_id` int(11),
  `data_array` longtext NOT NULL default '',
  `canvas_array` longtext NOT NULL default '',
  `created_by` varchar(255) NOT NULL default '',
  `material_id` int(11),
  `material_size_id` int(11),
  `filename` varchar(255) NOT NULL default '',
  `background_color` varchar(255) NOT NULL default '',
  `background_alpha` varchar(255) NOT NULL default '',
  `height` int(11),
  `width` int(11),
  `print_height` int(11),
  `print_width` int(11),
  `action` varchar(255) NOT NULL default '',
  `status` smallint(6) NOT NULL default '0',
  `created_time` datetime NULL,
  `update_time` datetime NULL,
  PRIMARY KEY (`design_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
    ");

$installer->endSetup(); 