<?php

class Sparx_Designertool_Model_System_Config_Source_Dropdown_Values {

    public function toOptionArray() {
        $values = array();
        $collection = Mage::getModel('catalog/product')
                ->getCollection()
                ->addAttributeToSelect('*');
            //    ->addAttributeToFilter('start_from_scratch', 1);

        foreach ($collection as $_product) { 
            $newArray = array();
            $newArray['value'] = $_product->getId();
            $newArray['label'] = $_product->getName();
            $values[] = $newArray;
            unset($newArray);
        }
        
        return $values;
    }

}
