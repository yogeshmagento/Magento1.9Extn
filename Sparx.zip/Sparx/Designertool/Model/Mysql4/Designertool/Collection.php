<?php

class Sparx_Designertool_Model_Mysql4_Designertool_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('designertool/designertool');
    }
}