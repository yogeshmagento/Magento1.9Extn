<?php

class Sparx_Designertool_Model_Mysql4_Designertool extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the designertool_id refers to the key field in your database table.
        $this->_init('designertool/designertool', 'design_id');
    }
}