<?php

class Sparx_Designertool_Model_Mysql4_Designquote extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the designertool_id refers to the key field in your database table.
        $this->_init('designertool/designquote', 'custom_quote_id');
    }
}