<?php

class Sparx_Designertool_Model_Observer {

    /**
     * Flag to stop observer executing more than once
     *
     * @var static bool
     */
    static protected $_singletonFlag = false;

    /**
     * This method will run when the product is saved from the Magento Admin
     * Use this function to update the product model, process the
     * data or anything you like
     *
     * @param Varien_Event_Observer $observer
     */
    public function saveProductTabData(Varien_Event_Observer $observer) {
        if (!self::$_singletonFlag) {
            self::$_singletonFlag = true;

            $product = $observer->getEvent()->getProduct();

            try {
                /**
                 * Perform any actions you want here
                 *
                 */
                $customFieldValue = $this->_getRequest()->getPost('custom_field');

                /**
                 * Uncomment the line below to save the product
                 *
                 */
                //$product->save();
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
        }
    }

    /**
     * Retrieve the product model
     *
     * @return Mage_Catalog_Model_Product $product
     */
    public function getProduct() {
        return Mage::registry('product');
    }

    /**
     * Shortcut to getRequest
     *
     */
    protected function _getRequest() {
        return Mage::app()->getRequest();
    }

    /*
     *  Change override checkout cart item name
     */

    public function changeQuote(Varient_Event_Observer $observer) {
        $item = $observer->getQuoteItem();

        $designValue = $this->getDesignCode($item);
        $changeValues = $this->updateCustomDesignQuote($item, $designValue, 'setProduct');

        if ($item->getParentItem()) {
            $item = $item->getParentItem();
        }
        Mage::log('changeQuote', null, 'mylog.log');
        $item->setName($changeValues['name']);

        $item->setPrice($changeValues['price']);
        $item->setCustomPrice($changeValues['price']);
        $item->getProduct()->setIsSuperMode(true);
        $item->save();
    }

    public function getDesignCode($item) {
        $_customOptions = $item->getProduct()
                ->getTypeInstance(true)
                ->getOrderOptions($item->getProduct());

        return $_customOptions['options'][0]['value'];
    }

    private function updateCustomDesignQuote($item, $designValue, $action = '') {
        $customDesignQuoteId = $this->loadModel()
                        ->getCollection()
                        ->addFieldToFilter('design_unique_id', $designValue)
                        ->getFirstItem()->getId();

        //update quote id in custom design quote table
        $customQuoteModel = $this->loadModel($customDesignQuoteId);
        $customQuoteModel->setItemId($item->getId());
        $customQuoteModel->save();

        $returndata['name'] = $customQuoteModel->getName();
        $returndata['id'] = $customQuoteModel->getId();
        $returndata['price'] = $customQuoteModel->getPrice();
        if ($action == 'setProduct')
            return $returndata;
    }

    /*
     *  load design quote model
     */

    private function loadModel($id = 0) {
        if ($id > 0)
            return Mage::getModel('designertool/designquote')->load($id);

        return Mage::getModel('designertool/designquote');
    }

    /*
     *  Change override checkout cart item price
     */

    public function updatePriceQuote($observer) {
        /**
         * Price calculation as per qty
         */
        foreach ($observer->getCart()->getQuote()->getAllVisibleItems() as $item) {
            $qty = $item->getQty();
            $UnitPrice = $remQty = $price = $qty_set = 0;
        $options = Mage::helper('catalog/product_configuration')->getCustomOptions($item);
         if(isset($options[0]['value'])){
            $arr =  explode(",",$options[0]['value']);
            if(isset($arr[0]) && substr($arr[0],0, 10) == 'predesign#'){
                    $imgid = substr($arr[0],10);
                    $resource = Mage::getSingleton('core/resource');    
                    /**
                    * Retrieve the write connection
                    */
                    $writeConnection = $resource->getConnection('core_write');
                    $query = "SELECT * FROM printpage where id=".$imgid;
                    $d = $writeConnection->fetchAll($query);
                    $materialLabel = $d[0]['material_id'];
                    if(isset($materialLabel)){
                       $mModel= Mage::getModel('material/material')->getCollection()->addFieldToFilter('title',$materialLabel)->getFirstItem();
                       $materialId = $mModel->getId();
                    }
                    $materislSizeId= $d[0]['materialId_size'];
                    $side = $d[0]['doubleside'];
                    //echo "<pre>"; print_r($side);
                    $otherOptionId = '';
                    $customWidth=$d[0]['custom_height'];
                    $customHeight=$d[0]['custom_width'];
                }else{
                     $designQuote = Mage::getModel('designertool/designquote')->getCollection()->addFieldToFilter('item_id', $item->getItemId())->getLastItem();

                    $designId = $designQuote->getDesignId();

                    $designModel = Mage::getModel('designertool/designertool')->load($designId);
                    $customWidth=$designModel->getCustomWidth();
                    $customHeight=$designModel->getCustomHeight();

                    $side = $designQuote->getSideId();
                    $otherOptionId = $designQuote->getMaterialOptionId();
                    $materialId = $designModel->getMaterialId();
                    //echo "<pre>"; print_r($materialId); exit;

                    if ($materialId == 0) {
                        continue;
                    }
                    $materislSizeId = $designQuote->getMaterialSizeId();

                }

            if ($qty >= 1) {
                if((isset($customWidth) && $customWidth>0) && (isset($customHeight) && $customHeight>0)){
                    $customAreaVal=$customWidth*$customHeight;
                    $materislSizeId = $this->getCustomSizeMaterialId($customAreaVal,$materialId);

                }
                    $materialPrice = Mage::getModel('material/material')->load($materialId)->getPrice();
                    $sizetierPriceArr = Mage::getModel('material/sizetier')->getCollection()
                                ->addFieldToFilter('material_id', $materialId)
                                ->addFieldToFilter('material_sizeinfo_id', $materislSizeId)->addFieldToFilter('qty', array(
                                    array('lteq' => $qty)))
                                ->setOrder('qty', 'DESC')
                                ->getFirstItem();
                        $sizetierPrice = $sizetierPriceArr->getPrice();
                        if ($side == 2) {
                             $doublePrice = $sizetierPriceArr->getDoublesidePrice();
                        } else {
                            $doublePrice = $sizetierPriceArr->getPrice();
                        }
                        if (isset($otherOptionId) && ($otherOptionId != '')) {
                            $otherOptionPrice = Mage::getModel('material/otherinfo')->load($otherOptionId)->getPrice();
                        }else{
                            $otherOptionPrice=0.00;
                        }
                        $finalPrice = $materialPrice + $doublePrice + $otherOptionPrice;

                
            } else {
                $finalPrice = 0.00;
            }
            $designValue = $this->getDesignCode($item);
            $this->updateCustomDesignQuote($item, $designValue, 'setProduct');
            } 
            if(isset($finalPrice)){           
            $item->setCustomPrice($finalPrice);
            $item->setOriginalCustomPrice($finalPrice);
            $item->getProduct()->setIsSuperMode(true);
            $item->save();
          }
        }
    }


    public function getCustomSizeMaterialId($customAreaVal,$materialId){
            $sizeinfo = Mage::getModel('material/sizeinfo')->getCollection()->addFieldToFilter('material_id', $materialId)->getData();
            //echo "<pre>"; print_r($sizeinfo);

            if (!empty($sizeinfo)) {
                $sColl=array();
                foreach ($sizeinfo as $value) {
                        $sColl[$value['material_sizeinfo_id']]= ($value['width'] * $value['height']);
                    }
              asort($sColl);
              
              $inc=0;
              $count=count($sColl);
              foreach($sColl as $sId=>$sVal){
                    if($customAreaVal<=$sVal){
                            $materialSizeId=$sId;
                            break;
                        }
                    $inc++; 
                    if($inc==$count){
                            $materialSizeId=$sId;
                            break;
                        }   
                  }
              
            }
            return $materialSizeId;
        }

}