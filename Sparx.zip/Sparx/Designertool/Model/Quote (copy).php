<?php

class Sparx_Designertool_Model_Quote {
    /*
     *  Change override checkout cart item name
     */

    public function changeQuote(Varient_Event_Observer $observer) {
        $item = $observer->getQuoteItem();

        $designValue = $this->getDesignCode($item);
        $changeValues = $this->updateCustomDesignQuote($item, $designValue, 'setProduct');

        if ($item->getParentItem()) {
            $item = $item->getParentItem();
        }
        

        $item->setName($changeValues['name']);
        return $this;
    }

    public function getDesignCode($item) {
        $_customOptions = $item->getProduct()
                ->getTypeInstance(true)
                ->getOrderOptions($item->getProduct());

        return $_customOptions['options'][0]['value'];
    }

    private function updateCustomDesignQuote($item, $designValue, $action = '') {

        $customDesignQuoteId = $this->loadModel()
                        ->getCollection()
                        ->addFieldToFilter('design_unique_id', $designValue)
                        ->getFirstItem()->getId();

        //update quote id in custom design quote table
        $customQuoteModel = $this->loadModel($customDesignQuoteId);
        $customQuoteModel->setItemId($item->getId());
        $customQuoteModel->save();

        $returndata['name'] = $customQuoteModel->getName();
        $returndata['id'] = $customQuoteModel->getId();
        $returndata['price'] = ltrim($customQuoteModel->getprice(),'$');
        
        if ($action == 'setProduct'){
            return $returndata;
        }
    }

    /*
     *  load design quote model
     */

    private function loadModel($id = 0) {
        if ($id > 0)
            return Mage::getModel('designertool/designquote')->load($id);

        return Mage::getModel('designertool/designquote');
    }

    /*
     *  Change override checkout cart item price
     */

    public function updatePriceQuote(Varient_Event_Observer $observer) {
        $item = $observer->getQuoteItem();

        if ($item->getParentItem()) {
            $item = $item->getParentItem();
        }

        $designValue = $this->getDesignCode($item);
        $this->updateCustomDesignQuote($item, $designValue, 'setItem');

        //Mage::log('updatePriceQuote', null, 'mylog.log');
        $price = $this->loadModel()->getcollection()->addFieldToFilter('item_id', $item->getId())->getFirstItem()->getPrice();
         //Mage::log($price, null, 'mylog.log');
        $item->setCustomPrice($price);
        $item->setOriginalCustomPrice($price);
        $item->getProduct()->setIsSuperMode(true);
        $item->save();
    }

}
