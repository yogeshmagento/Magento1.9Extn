<?php

class Sparx_Designertool_Model_Designquote extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('designertool/designquote');
    }
    
    public function _loadmodel($id=0){
        if($id > 0 )
            return Mage::getModel ('designertool/designquote')->load($id);
        
        return Mage::getModel ('designertool/designquote');
    }
    
    public function saveCustomData($data){
        $model = $this->_loadmodel();
        $model->setDesignId($data['designId']);
        $model->setMaterialId($data['materialId']);
        $model->setMaterialSizeId($data['materialSizeId']);
        $model->setMaterialOptionId($data['otherOptValue']);
        $model->setPrice($data['price']);
        $model->setProductId($data['productId']);
        $model->setQty($data['quantity']);
        $model->setSideId($data['sideValue']);
        $model->setName($this->getItemCustomName($data['materialId'],$data['materialSizeId']));
        $model->setDesignUniqueId($data['uid']);
        $model->save();
        
        return $model->getId();
    }
    
    public function getItemCustomName($materialId,$materialSizeId){        
        $materialName = Mage::getModel('material/material')->load($materialId)->getTitle();
        $materialSizeName = Mage::getModel('material/sizeinfo')->load($materialSizeId)->getTitle();
        return $materialSizeName."&nbsp;".$materialName;
    }
     
        
}
