<?php

class Sparx_Designertool_Block_Designertool extends Mage_Core_Block_Template {

    public function _prepareLayout() {
        return parent::_prepareLayout();
    }

    public function getDesignertool() {
        if (!$this->hasData('designertool')) {
            $this->setData('designertool', Mage::registry('designertool'));
        }
        return $this->getData('designertool');
    }

    public function getProductIdByDesignId($designid) {
        $designInfo = Mage::getModel('designertool/designertool')->load($designid);
        return $designInfo->getProductId();
    }
    
    public function getMaterialId(){
       $designid = $this->getRequest()->getParam('designId');
        if($designid)
            return $materialSizeId =  Mage::getModel('designertool/designertool')->load($designid)->getMaterialId();
        else
            return $materialSizeId = $this->getRequest()->getParam('mid');
            
    }
    
    public function getMaterialSizeId(){
        
        $designid = $this->getRequest()->getParam('designId');
        if($designid)
            return $materialSizeId =  Mage::getModel('designertool/designertool')->load($designid)->getMaterialSizeId();
        else
            return $materialSizeId = $this->getRequest()->getParam('sid');
        
    }

}
