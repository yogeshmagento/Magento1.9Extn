<?php
class Sparx_Designertool_Block_Savedesigns extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     private function getCookieDesigns()     
     { 
        $designIds = Mage::getModel('core/cookie')->get('designIds');
        $designIds= explode('.',$designIds);
       // echo "<pre>"; print_r($designIds); exit;
         return array_filter($designIds);
        
    }
    
     public function getSaveDesigns()     
     { 
        $designs = $this->getCookieDesigns();
        foreach($designs as $id){
            $loadDesign = Mage::getModel('designertool/designertool')->load($id);
            if(count($loadDesign->getData())>0 && ($loadDesign->getAction() != 'saveDesign')){
                $saveDesign[] = $loadDesign->getId();
            }
        }
        
        return $saveDesign;
        
    }
    
    public function getAllDesigns(){
        return $this->getCookieDesigns();
    }
    
    public function getUnsavedDesign(){
        $designs = $this->getCookieDesigns();
        foreach($designs as $id){
            $loadDesign = Mage::getModel('designertool/designertool')->load($id);
            if(count($loadDesign->getData())>0 && ($loadDesign->getAction() == 'saveDesign')){
                $unsaveDesign[] = $loadDesign->getId();
            }
        }
        
        return $unsaveDesign;
    }
}
