<?php

class Sparx_Designertool_Block_Adminhtml_Designertool_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
      parent::__construct();
      $this->setId('designertool_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('designertool')->__('Item Information'));
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('designertool')->__('Item Information'),
          'title'     => Mage::helper('designertool')->__('Item Information'),
          'content'   => $this->getLayout()->createBlock('designertool/adminhtml_designertool_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}