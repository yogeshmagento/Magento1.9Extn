<?php

class Sparx_Designertool_Block_Adminhtml_Designertool_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('designertool_form', array('legend'=>Mage::helper('designertool')->__('Item information')));
     
      $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('designertool')->__('Title'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'title',
      ));

      $fieldset->addField('filename', 'file', array(
          'label'     => Mage::helper('designertool')->__('File'),
          'required'  => false,
          'name'      => 'filename',
	  ));
		
      $fieldset->addField('status', 'select', array(
          'label'     => Mage::helper('designertool')->__('Status'),
          'name'      => 'status',
          'values'    => array(
              array(
                  'value'     => 1,
                  'label'     => Mage::helper('designertool')->__('Enabled'),
              ),

              array(
                  'value'     => 2,
                  'label'     => Mage::helper('designertool')->__('Disabled'),
              ),
          ),
      ));
     
      $fieldset->addField('content', 'editor', array(
          'name'      => 'content',
          'label'     => Mage::helper('designertool')->__('Content'),
          'title'     => Mage::helper('designertool')->__('Content'),
          'style'     => 'width:700px; height:500px;',
          'wysiwyg'   => false,
          'required'  => true,
      ));
     
      if ( Mage::getSingleton('adminhtml/session')->getDesignertoolData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getDesignertoolData());
          Mage::getSingleton('adminhtml/session')->setDesignertoolData(null);
      } elseif ( Mage::registry('designertool_data') ) {
          $form->setValues(Mage::registry('designertool_data')->getData());
      }
      return parent::_prepareForm();
  }
}