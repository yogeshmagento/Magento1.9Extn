<?php
class Sparx_Designertool_Block_Adminhtml_Designertool extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {    
    $this->_controller = 'adminhtml_designertool';
    $this->_blockGroup = 'designertool';
    $this->_headerText = Mage::helper('designertool')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('designertool')->__('Add Item');
    parent::__construct();
//    $this->setData('area','frontend');
//    $this->setTemplate('designertool/designertool.phtml');
  }
}