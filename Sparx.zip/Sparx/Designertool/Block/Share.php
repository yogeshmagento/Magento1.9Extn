<?php
class Sparx_Designertool_Block_Share extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getShare()     
     { 
        if (!$this->hasData('share')) {
            $this->setData('share', Mage::registry('share'));
        }
        return $this->getData('share');
        
    }
}
