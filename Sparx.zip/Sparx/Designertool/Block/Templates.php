<?php
class Sparx_Designertool_Block_Templates extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
}
