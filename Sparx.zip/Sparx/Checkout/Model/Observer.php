<?php

class Sparx_Checkout_Model_Observer {

    public function changeQuote(Varient_Event_Observer $observer) {
        $item = $observer->getQuoteItem();
		
		$designValue =  $this->getDesignCode($item);
		$changeValues = $this->updateCustomDesignQuote($item,$designValue, 'setProduct');
		
        if ($item->getParentItem()) {
            $item = $item->getParentItem();
        }
       Mage::log('changeQuote',null, 'mylog.log');
        $item->setName($changeValues['name']);
        
        $item->setPrice($changeValues['price']);
		$item->setCustomPrice($changeValues['price']);
        $item->getProduct()->setIsSuperMode(true);      
        $item->save();
    }
    
    public function getDesignCode($item){
        $_customOptions = $item->getProduct()
						->getTypeInstance(true)
						->getOrderOptions($item->getProduct());
						
        return $_customOptions['options'][0]['value'];        
            
    }
    
    private function updateCustomDesignQuote($item,$designValue, $action=''){
		
		$customDesignQuoteId = $this->loadModel()
								->getCollection()
								->addFieldToFilter('design_unique_id',$designValue)
								->getFirstItem()->getId();
								
		//update quote id in custom design quote table
		$customQuoteModel = $this->loadModel($customDesignQuoteId);
		$customQuoteModel->setItemId($item->getId());	
		$customQuoteModel->save();
		
		$returndata['name'] = $customQuoteModel->getName();
		$returndata['id'] = $customQuoteModel->getId();
		$returndata['price'] = $customQuoteModel->getprice();
		if($action == 'setProduct')
			return $returndata; 
	}
	
	private function loadModel($id=0){
		if($id > 0)
			return Mage::getModel('designertool/designquote')->load($id);
		
		return Mage::getModel('designertool/designquote');	
	}
	
	public function updatePriceQuote(Varient_Event_Observer $observer){  
		 $item = $observer->getQuoteItem();
		 
			 if ($item->getParentItem()) {
				$item = $item->getParentItem();
			}
			
			$designValue =  $this->getDesignCode($item);
			$this->updateCustomDesignQuote($item,$designValue, 'setItem');
		Mage::log('updatePriceQuote',null, 'mylog.log');
		  $price = $this->loadModel()->getcollection()->addFieldToFilter('item_id',$item->getId())->getFirstItem()->getPrice();
		  $item->setCustomPrice($price);
          $item->setOriginalCustomPrice($price);
		  $item->getProduct()->setIsSuperMode(true);  
		  $item->save(); 
	}
		

}
