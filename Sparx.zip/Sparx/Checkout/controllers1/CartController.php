<?php

require_once Mage::getModuleDir('controllers', 'Mage_Checkout').DS.'CartController.php';
class Sparx_Checkout_CartController extends Mage_Checkout_CartController
{
	
}
