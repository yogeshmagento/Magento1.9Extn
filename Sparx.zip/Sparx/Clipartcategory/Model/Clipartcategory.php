<?php

class Sparx_Clipartcategory_Model_Clipartcategory extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('clipartcategory/clipartcategory');
    }
    
    public function getClipartCategory(){
        $categories = Mage::getModel('clipartcategory/clipartcategory')->getCollection()->getData();
        $categoryArray = array();
        if(count($categories) > 0 ){
            foreach($categories as $category){
                $categoryArray[$category['clipartcategory_id']] = $category['title'];
            }
        }
        return $categoryArray;
    }
}