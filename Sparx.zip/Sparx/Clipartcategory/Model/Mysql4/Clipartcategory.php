<?php

class Sparx_Clipartcategory_Model_Mysql4_Clipartcategory extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        // Note that the clipartcategory_id refers to the key field in your database table.
        $this->_init('clipartcategory/clipartcategory', 'clipartcategory_id');
    }
}