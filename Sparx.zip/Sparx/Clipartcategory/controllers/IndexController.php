<?php
class Sparx_Clipartcategory_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/clipartcategory?id=15 
    	 *  or
    	 * http://site.com/clipartcategory/id/15 	
    	 */
    	/* 
		$clipartcategory_id = $this->getRequest()->getParam('id');

  		if($clipartcategory_id != null && $clipartcategory_id != '')	{
			$clipartcategory = Mage::getModel('clipartcategory/clipartcategory')->load($clipartcategory_id)->getData();
		} else {
			$clipartcategory = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($clipartcategory == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$clipartcategoryTable = $resource->getTableName('clipartcategory');
			
			$select = $read->select()
			   ->from($clipartcategoryTable,array('clipartcategory_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$clipartcategory = $read->fetchRow($select);
		}
		Mage::register('clipartcategory', $clipartcategory);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}