<?php
class Sparx_Clipartcategory_Block_Clipartcategory extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getClipartcategory()     
     { 
        if (!$this->hasData('clipartcategory')) {
            $this->setData('clipartcategory', Mage::registry('clipartcategory'));
        }
        return $this->getData('clipartcategory');
        
    }
}