<?php

class Sparx_Clipartcategory_Block_Adminhtml_Clipartcategory_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'clipartcategory';
        $this->_controller = 'adminhtml_clipartcategory';
        
        $this->_updateButton('save', 'label', Mage::helper('clipartcategory')->__('Save Category'));
        $this->_updateButton('delete', 'label', Mage::helper('clipartcategory')->__('Delete Category'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('clipartcategory_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'clipartcategory_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'clipartcategory_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('clipartcategory_data') && Mage::registry('clipartcategory_data')->getId() ) {
            return Mage::helper('clipartcategory')->__("Edit Category '%s'", $this->htmlEscape(Mage::registry('clipartcategory_data')->getTitle()));
        } else {
            return Mage::helper('clipartcategory')->__('Add Category');
        }
    }
}