<?php

class Sparx_Clipartcategory_Block_Adminhtml_Clipartcategory_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
      parent::__construct();
      $this->setId('clipartcategory_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('clipartcategory')->__('Clipart category Information'));
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('clipartcategory')->__('Clipart category Information'),
          'title'     => Mage::helper('clipartcategory')->__('Clipart category Information'),
          'content'   => $this->getLayout()->createBlock('clipartcategory/adminhtml_clipartcategory_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}