<?php
class Sparx_Clipartcategory_Block_Adminhtml_Clipartcategory extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_clipartcategory';
    $this->_blockGroup = 'clipartcategory';
    $this->_headerText = Mage::helper('clipartcategory')->__('Clipart Category Manager');
    $this->_addButtonLabel = Mage::helper('clipartcategory')->__('Add Category');
    parent::__construct();
  }
}