<?php

class Sparx_Clipart_Model_Clipart extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('clipart/clipart');
    }
    
    public function getCategory(){
         $categories = Mage::getModel('clipartcategory/clipartcategory')->getCollection()->getData();
            $categoryArray = array(''=>'Select category');
            if(count($categories) > 0 ){
                foreach($categories as $category){
                    $categoryArray[$category['clipartcategory_id']] = $category['title'];
                }
            }
            return $categoryArray;        
    }
    
    public function getFileExt($fileName) {
        $fileArr = explode('.', $fileName);
        if (count($fileArr) == 2) {
            $fileExt = '.' . $fileArr[1];
            return $fileExt;
        } else {
            die('Invalid Image Name');
            exit;
        }
    }
    
    public function uploadImgInPng($filename="", $path=""){
         $imageMagickPath=Mage::getStoreConfig('designertool/imagemagick_info/image_magick_path');
         $largepath =  $path.DS.'large'.DS.$filename;
         $thumbpath =  $path.DS.'thumb'.DS.$filename;
         $orgPath=$path.DS.$filename;   
        
        //============= check image is eps or not===========================
        if(strpos($filename,'.eps')){
            $epsPath=$path.DS.$filename;               
            $filename=str_replace('.eps','.png',$filename);
            $orgPath= $path.DS.$filename;
            $largepath =  $path.DS.'large'.DS.$filename;
            $thumbpath =  $path.DS.'thumb'.DS.$filename;
            
            exec("$imageMagickPath -density 72 -channel RGBA -colorspace RGB -background none -fill none -dither None $epsPath -trim $orgPath");
            } 
            
         //........... trim original image .............. 
         exec($imageMagickPath . " $orgPath -trim $orgPath");
            
     
        // ..........large image...................
        $lsp=$this->getImageRatio(400,400,$orgPath);
        exec($imageMagickPath . " $orgPath -resize $lsp $largepath");
        // ..........thumb image...................
        $lsp=$this->getImageRatio(74,74,$orgPath);
        exec($imageMagickPath . " $orgPath -resize $lsp $thumbpath");   
        
        return $filename;
    }
    
    public function getImageRatio($widthR='', $heightR='',$image) {
        
        $imageRatio = '';
        list($width, $height) = getimagesize($image);
        $ratio = $width / $height;
        if ($width > $widthR && $height > $heightR) {
            $imageRatio = $widthR . 'x' . $heightR;
            ;
        } elseif ($width < $widthR && $height > $heightR) {
            $imageRatio = 'x' . $heightR;
        } elseif ($width > $widthR && $height < $heightR) {
            $imageRatio = $widthR . 'x';
        } else {
            $imageRatio = $width . 'x' . $height;
        }
        return $imageRatio;
    }
}