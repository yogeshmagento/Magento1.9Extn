<?php
class Sparx_Clipart_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/clipart?id=15 
    	 *  or
    	 * http://site.com/clipart/id/15 	
    	 */
    	/* 
		$clipart_id = $this->getRequest()->getParam('id');

  		if($clipart_id != null && $clipart_id != '')	{
			$clipart = Mage::getModel('clipart/clipart')->load($clipart_id)->getData();
		} else {
			$clipart = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($clipart == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$clipartTable = $resource->getTableName('clipart');
			
			$select = $read->select()
			   ->from($clipartTable,array('clipart_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$clipart = $read->fetchRow($select);
		}
		Mage::register('clipart', $clipart);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}