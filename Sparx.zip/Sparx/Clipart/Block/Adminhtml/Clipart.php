<?php
class Sparx_Clipart_Block_Adminhtml_Clipart extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_clipart';
    $this->_blockGroup = 'clipart';
    $this->_headerText = Mage::helper('clipart')->__('Clipart Manager');
    $this->_addButtonLabel = Mage::helper('clipart')->__('Add Clipart');
    parent::__construct();
  }
}