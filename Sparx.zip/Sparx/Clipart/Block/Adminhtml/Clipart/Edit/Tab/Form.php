<?php

class Sparx_Clipart_Block_Adminhtml_Clipart_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('clipart_form', array('legend'=>Mage::helper('clipart')->__('Clipart information')));
     
      $category = $fieldset->addField('clipartcategory_id', 'select', array(
          'label'     => Mage::helper('clipart')->__('Category'),
          'name'      => 'clipartcategory_id',
          'values'    => Mage::getModel('clipart/clipart')->getCategory(),
          'onchange'  =>'getSubcategories(this)',
      ));
       
     // $category->setAfterElementHtml("<script type=\"text/javascript\">
     //                function getSubcategories(selectElement){
     //                    var reloadurl = '". $this
     //                     ->getUrl('clipart/adminhtml_clipart/getSubcategories') . "category_id/' + selectElement.value;
     //                    new Ajax.Request(reloadurl, {
     //                        method: 'get',
     //                        onLoading: function (subcategoryform) {
     //                            $('clipartsubcategory_id').update('Searching...');
     //                        },
     //                        onComplete: function(subcategoryform) { 
     //                            $('clipartsubcategory_id').update(subcategoryform.responseText);
     //                        }
     //                    });
     //                }
     //            </script>");
       
     // $fieldset->addField('clipartsubcategory_id', 'select', array(
     //      'label'     => Mage::helper('clipart')->__('Sub-Category'),
     //      'name'      => 'clipartsubcategory_id',
     //      'values'    => Mage::getModel('clipartsubcategory/clipartsubcategory')->getDefaultSubcategory($this->getRequest()->getParam('id')),
     //  ));
       
     $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('clipart')->__('Clipart Title'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'title',
     ));

     if($this->getRequest()->getParam('id')){
        $id = $this->getRequest()->getParam('id');;
         $imageurl = Mage::getModel('clipart/clipart')->load($id)->getFilename();
         if($id){ 
           $imageHtml = '<br/><img src="'. Mage::getBaseUrl('media').'designertool/clipart/'.$imageurl.'" />'; 
         }else{
             $imageHtml= '';
         }
     }
     
     $clipart = $fieldset->addField('filename', 'file', array(
          'label'     => Mage::helper('clipart')->__('Clipart file'),
          'required'  => false,
          'name'      => 'filename',
          'note'      => 'Clipart file should be in JPG, JPEG, PNG or svg format.</br> Example : upload_clipart.png',
	));
     
     $clipart->setAfterElementHtml($imageHtml.'<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>'
             . '<script type="text/javascript">'
             . '$myObj = jQuery.noConflict();'
             . '$myObj("input[type=file]").bind(\'change\',function(){
                var currentId = $myObj(this).attr(\'id\');
                var val = $myObj(this).val();
                if(currentId ==\'filename\'){
                    switch(val.substring(val.lastIndexOf(\'.\')+1).toLowerCase()){
                        case "png":
                        case "jpg":
                        case "jpeg":
                        case "svg":
                            return true;
                            break;
                        default:
                            $myObj(this).val(\'\');
                            alert("Only jpg, jpeg, png and svg images is allowed!!!");
                            return false;
                            break;
                    }
                }
                })'
             . '</script>');
     
     /*$fieldset->addField('colorable', 'select', array(
          'label'     => Mage::helper('clipart')->__('Colorable'),
          'name'      => 'colorable',
          'values'    => array(
              array(
                  'value'     => 'false',
                  'label'     => Mage::helper('clipart')->__('No'),
              ),

              array(
                  'value'     => 'true',
                  'label'     => Mage::helper('clipart')->__('Yes'),
              ),
          ),
      ));*/
		
      $fieldset->addField('status', 'select', array(
          'label'     => Mage::helper('clipart')->__('Status'),
          'name'      => 'status',
          'values'    => array(
              array(
                  'value'     => 1,
                  'label'     => Mage::helper('clipart')->__('Enabled'),
              ),

              array(
                  'value'     => 2,
                  'label'     => Mage::helper('clipart')->__('Disabled'),
              ),
          ),
      ));
     
      if ( Mage::getSingleton('adminhtml/session')->getClipartData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getClipartData());
          Mage::getSingleton('adminhtml/session')->setClipartData(null);
      } elseif ( Mage::registry('clipart_data') ) {
          $form->setValues(Mage::registry('clipart_data')->getData());
      }
      return parent::_prepareForm();
  }
}
