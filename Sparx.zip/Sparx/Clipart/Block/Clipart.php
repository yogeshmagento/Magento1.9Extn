<?php
class Sparx_Clipart_Block_Clipart extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getClipart()     
     { 
        if (!$this->hasData('clipart')) {
            $this->setData('clipart', Mage::registry('clipart'));
        }
        return $this->getData('clipart');
        
    }
}