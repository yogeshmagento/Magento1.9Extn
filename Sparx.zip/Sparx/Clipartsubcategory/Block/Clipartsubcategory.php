<?php
class Sparx_Clipartsubcategory_Block_Clipartsubcategory extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getClipartsubcategory()     
     { 
        if (!$this->hasData('clipartsubcategory')) {
            $this->setData('clipartsubcategory', Mage::registry('clipartsubcategory'));
        }
        return $this->getData('clipartsubcategory');
        
    }
}