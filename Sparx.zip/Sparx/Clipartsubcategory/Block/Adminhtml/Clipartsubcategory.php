<?php
class Sparx_Clipartsubcategory_Block_Adminhtml_Clipartsubcategory extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_clipartsubcategory';
    $this->_blockGroup = 'clipartsubcategory';
    $this->_headerText = Mage::helper('clipartsubcategory')->__('Clipart Sub-category Manager');
    $this->_addButtonLabel = Mage::helper('clipartsubcategory')->__('Add Subcategory');
    parent::__construct();
  }
}