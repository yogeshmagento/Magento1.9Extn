<?php

class Sparx_Clipartsubcategory_Block_Adminhtml_Clipartsubcategory_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('clipartsubcategory_form', array('legend'=>Mage::helper('clipartsubcategory')->__('Clipart sub-category information')));
     
      $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('clipartsubcategory')->__('Subcategory Title'),
          'class'     => 'required-entry',
          'required'  => true,
          'name'      => 'title',
      ));
      
      $fieldset->addField('clipartcategory_id', 'select', array(
          'label'     => Mage::helper('clipartsubcategory')->__('Clipart Category'),
          'name'      => 'clipartcategory_id',
          'values'    => Mage::getModel('clipartcategory/clipartcategory')->getClipartCategory(),
        )); 	
      
      $fieldset->addField('status', 'select', array(
          'label'     => Mage::helper('clipartsubcategory')->__('Status'),
          'name'      => 'status',
          'values'    => array(
              array(
                  'value'     => 1,
                  'label'     => Mage::helper('clipartsubcategory')->__('Enabled'),
              ),

              array(
                  'value'     => 2,
                  'label'     => Mage::helper('clipartsubcategory')->__('Disabled'),
              ),
          ),
      ));    
     
     
      if ( Mage::getSingleton('adminhtml/session')->getClipartsubcategoryData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getClipartsubcategoryData());
          Mage::getSingleton('adminhtml/session')->setClipartsubcategoryData(null);
      } elseif ( Mage::registry('clipartsubcategory_data') ) {
          $form->setValues(Mage::registry('clipartsubcategory_data')->getData());
      }
      return parent::_prepareForm();
  }
}