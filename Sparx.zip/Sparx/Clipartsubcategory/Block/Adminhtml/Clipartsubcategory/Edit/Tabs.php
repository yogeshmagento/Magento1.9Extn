<?php

class Sparx_Clipartsubcategory_Block_Adminhtml_Clipartsubcategory_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
      parent::__construct();
      $this->setId('clipartsubcategory_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('clipartsubcategory')->__('Clipart Sub-category Information'));
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('clipartsubcategory')->__('Clipart Sub-category Information'),
          'title'     => Mage::helper('clipartsubcategory')->__('Clipart Sub-category Information'),
          'content'   => $this->getLayout()->createBlock('clipartsubcategory/adminhtml_clipartsubcategory_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}