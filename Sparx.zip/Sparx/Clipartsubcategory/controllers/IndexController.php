<?php
class Sparx_Clipartsubcategory_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/clipartsubcategory?id=15 
    	 *  or
    	 * http://site.com/clipartsubcategory/id/15 	
    	 */
    	/* 
		$clipartsubcategory_id = $this->getRequest()->getParam('id');

  		if($clipartsubcategory_id != null && $clipartsubcategory_id != '')	{
			$clipartsubcategory = Mage::getModel('clipartsubcategory/clipartsubcategory')->load($clipartsubcategory_id)->getData();
		} else {
			$clipartsubcategory = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($clipartsubcategory == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$clipartsubcategoryTable = $resource->getTableName('clipartsubcategory');
			
			$select = $read->select()
			   ->from($clipartsubcategoryTable,array('clipartsubcategory_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$clipartsubcategory = $read->fetchRow($select);
		}
		Mage::register('clipartsubcategory', $clipartsubcategory);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}