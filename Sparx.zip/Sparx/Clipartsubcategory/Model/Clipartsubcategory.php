<?php

class Sparx_Clipartsubcategory_Model_Clipartsubcategory extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('clipartsubcategory/clipartsubcategory');
    }
    
    public function getDefaultSubcategory($clipart_id) {
        $category = Mage::getModel('clipartcategory/clipartcategory')->getCollection()
                ->setPageSize(1)
                ->setOrder('clipartcategory_id', 'ASC')
                ->getData();

        $clipartDefaultCategoryId = $category[0]['clipartcategory_id'];
        
        if($clipart_id):
            $clipart = Mage::getModel('clipart/clipart')->load($clipart_id)->getData();
            $clipartDefaultCategoryId = $clipart['clipartcategory_id'];             
        endif;

        $subcategories = Mage::getModel('clipartsubcategory/clipartsubcategory')
                ->getCollection()
                ->addFieldToFilter('clipartcategory_id', array('eq' => $clipartDefaultCategoryId))
                ->getData();

        $subcatArray = array();
        foreach ($subcategories as $subcategory) {
            $listArray['label'] = $subcategory['title'];
            $listArray['value'] = $subcategory['clipartsubcategory_id'];
            $subcatArray[] = $listArray;
        }
        return $subcatArray;
    }
    
    public function getClipartSubcategory($clipartcategory_id){
        return Mage::getModel('clipartsubcategory/clipartsubcategory')
                    ->getCollection()
                    ->addFieldToFilter('clipartcategory_id', array('eq' => $clipartcategory_id))
                    ->addFieldToFilter('status',1);
    }
}