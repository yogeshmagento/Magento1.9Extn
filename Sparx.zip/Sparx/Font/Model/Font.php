<?php

class Sparx_Font_Model_Font extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('font/font');
    }
    
     public function getFileExt($fileName) {
        $fileArr = explode('.', $fileName);
        if (count($fileArr) == 2) {
            $fileExt = '.' . $fileArr[1];
            return $fileExt;
        } else {
            die('Invalid file Name');
            exit;
        }
    }
}