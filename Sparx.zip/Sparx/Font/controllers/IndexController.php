<?php
class Sparx_Font_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/font?id=15 
    	 *  or
    	 * http://site.com/font/id/15 	
    	 */
    	/* 
		$font_id = $this->getRequest()->getParam('id');

  		if($font_id != null && $font_id != '')	{
			$font = Mage::getModel('font/font')->load($font_id)->getData();
		} else {
			$font = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($font == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$fontTable = $resource->getTableName('font');
			
			$select = $read->select()
			   ->from($fontTable,array('font_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$font = $read->fetchRow($select);
		}
		Mage::register('font', $font);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}