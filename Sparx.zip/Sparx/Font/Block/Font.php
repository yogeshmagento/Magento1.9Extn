<?php
class Sparx_Font_Block_Font extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getFont()     
     { 
        if (!$this->hasData('font')) {
            $this->setData('font', Mage::registry('font'));
        }
        return $this->getData('font');
        
    }
}