<?php

class Sparx_Font_Block_Adminhtml_Font_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
      $form = new Varien_Data_Form();
      $this->setForm($form);
      $fieldset = $form->addFieldset('font_form', array('legend'=>Mage::helper('font')->__('Font information')));
     
     /* $category = $fieldset->addField('title', 'text', array(
          'label'     => Mage::helper('font')->__('Font Title'),
          'name'      => 'title',
      ));*/
      
      $font = $fieldset->addField('filename', 'file', array(
          'label'     => Mage::helper('font')->__('Font File'),
          'note'      => 'It should be in ttf format<br/> Example : arial.ttf',
          'required'  => false,
          'name'      => 'filename',
	  ));
      
      if($this->getRequest()->getParam('id')){
          $id = $this->getRequest()->getParam('id');
          $html = '<img src = "'.Mage::getBaseUrl('media').'designertool/font/thumb/'.Mage::getModel('font/font')->load($id)->getFontImage().'" />';
      } else {
          $html = '';
      }
      
      $font->setAfterElementHtml($html.'<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>'
              . '<script type="text/javascript">'
              . '$myObj = jQuery.noConflict();'
              . '$myObj("input[type=file]").bind(\'change\',function(){'
              . 'var currentId = $myObj(this).attr(\'id\');'
              . 'var val = $myObj(this).val();'
              . 'if(currentId ==\'filename\'){
                  switch(val.substring(val.lastIndexOf(\'.\')+1).toLowerCase()){
                  case "ttf":
                        return true;
                        break;
                  default :
                        $myObj(this).val(\'\');
                         alert("Only ttf file allowed!!!");
                         return false;
                         break;
                      }
                    }
                  })'
              . '</script>');
		
      $fieldset->addField('status', 'select', array(
          'label'     => Mage::helper('font')->__('Status'),
          'name'      => 'status',
          'values'    => array(
              array(
                  'value'     => 1,
                  'label'     => Mage::helper('font')->__('Enabled'),
              ),

              array(
                  'value'     => 2,
                  'label'     => Mage::helper('font')->__('Disabled'),
              ),
          ),
      ));
     
     
      if ( Mage::getSingleton('adminhtml/session')->getFontData() )
      {
          $form->setValues(Mage::getSingleton('adminhtml/session')->getFontData());
          Mage::getSingleton('adminhtml/session')->setFontData(null);
      } elseif ( Mage::registry('font_data') ) {
          $form->setValues(Mage::registry('font_data')->getData());
      }
      return parent::_prepareForm();
  }
}
