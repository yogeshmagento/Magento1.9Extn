<?php

class Sparx_Font_Block_Adminhtml_Font_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'font';
        $this->_controller = 'adminhtml_font';
        
        $this->_updateButton('save', 'label', Mage::helper('font')->__('Save Font'));
        $this->_updateButton('delete', 'label', Mage::helper('font')->__('Delete Font'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('font_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'font_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'font_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('font_data') && Mage::registry('font_data')->getId() ) {
            return Mage::helper('font')->__("Edit Font '%s'", $this->htmlEscape(Mage::registry('font_data')->getTitle()));
        } else {
            return Mage::helper('font')->__('Add Font');
        }
    }
}