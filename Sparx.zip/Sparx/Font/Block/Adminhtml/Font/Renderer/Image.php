<?php

class Sparx_Font_Block_Adminhtml_Font_Renderer_Image extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract {

    public function render(Varien_Object $row) {        
        $imageUrl = '<img src="' . Mage::getBaseUrl('media') . 'designertool/font/thumb/' . $row->getFontImage() . '" title="' . $row->getTitle() . '" alt="' . $row->getTitle() . '"  />';
        return $imageUrl;
    }

}

?>
