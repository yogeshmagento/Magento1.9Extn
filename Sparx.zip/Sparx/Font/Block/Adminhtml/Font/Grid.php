<?php

class Sparx_Font_Block_Adminhtml_Font_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
      parent::__construct();
      $this->setId('fontGrid');
      $this->setDefaultSort('font_id');
      $this->setDefaultDir('ASC');
      $this->setSaveParametersInSession(true);
  }

  protected function _prepareCollection()
  {
      $collection = Mage::getModel('font/font')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
  }

  protected function _prepareColumns()
  {
      $this->addColumn('font_id', array(
          'header'    => Mage::helper('font')->__('ID'),
          'align'     =>'right',
          'width'     => '50px',
          'index'     => 'font_id',
      ));

      $this->addColumn('title', array(
          'header'    => Mage::helper('font')->__('Font Title'),
          'align'     =>'left',
          'index'     => 'title',
      ));

        $this->addColumn('font_image', array(
            'header' => Mage::helper('font')->__('Font Image'),
            'align' => 'left',
            'index' => 'font_image',
            'width' => '350px',
            'filter' => false,
            'renderer' => 'Sparx_Font_Block_Adminhtml_Font_Renderer_Image',
        ));

      $this->addColumn('status', array(
          'header'    => Mage::helper('font')->__('Status'),
          'align'     => 'left',
          'width'     => '80px',
          'index'     => 'status',
          'type'      => 'options',
          'options'   => array(
              1 => 'Enabled',
              2 => 'Disabled',
          ),
      ));
	  
        $this->addColumn('action',
            array(
                'header'    =>  Mage::helper('font')->__('Action'),
                'width'     => '100',
                'type'      => 'action',
                'getter'    => 'getId',
                'actions'   => array(
                    array(
                        'caption'   => Mage::helper('font')->__('Edit'),
                        'url'       => array('base'=> '*/*/edit'),
                        'field'     => 'id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
                'is_system' => true,
        ));
		
		$this->addExportType('*/*/exportCsv', Mage::helper('font')->__('CSV'));
		$this->addExportType('*/*/exportXml', Mage::helper('font')->__('XML'));
	  
      return parent::_prepareColumns();
  }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('font_id');
        $this->getMassactionBlock()->setFormFieldName('font');

        $this->getMassactionBlock()->addItem('delete', array(
             'label'    => Mage::helper('font')->__('Delete'),
             'url'      => $this->getUrl('*/*/massDelete'),
             'confirm'  => Mage::helper('font')->__('Are you sure?')
        ));

        $statuses = Mage::getSingleton('font/status')->getOptionArray();

        array_unshift($statuses, array('label'=>'', 'value'=>''));
        $this->getMassactionBlock()->addItem('status', array(
             'label'=> Mage::helper('font')->__('Change status'),
             'url'  => $this->getUrl('*/*/massStatus', array('_current'=>true)),
             'additional' => array(
                    'visibility' => array(
                         'name' => 'status',
                         'type' => 'select',
                         'class' => 'required-entry',
                         'label' => Mage::helper('font')->__('Status'),
                         'values' => $statuses
                     )
             )
        ));
        return $this;
    }

  public function getRowUrl($row)
  {
      return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }

}