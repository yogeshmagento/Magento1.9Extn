<?php
class Sparx_Font_Block_Adminhtml_Font extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_font';
    $this->_blockGroup = 'font';
    $this->_headerText = Mage::helper('font')->__('Font Manager');
    $this->_addButtonLabel = Mage::helper('font')->__('Add Font');
    parent::__construct();
  }
}