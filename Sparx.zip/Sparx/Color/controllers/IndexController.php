<?php
class Sparx_Color_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/color?id=15 
    	 *  or
    	 * http://site.com/color/id/15 	
    	 */
    	/* 
		$color_id = $this->getRequest()->getParam('id');

  		if($color_id != null && $color_id != '')	{
			$color = Mage::getModel('color/color')->load($color_id)->getData();
		} else {
			$color = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($color == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$colorTable = $resource->getTableName('color');
			
			$select = $read->select()
			   ->from($colorTable,array('color_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$color = $read->fetchRow($select);
		}
		Mage::register('color', $color);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}