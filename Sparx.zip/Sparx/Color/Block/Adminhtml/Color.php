<?php
class Sparx_Color_Block_Adminhtml_Color extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_color';
    $this->_blockGroup = 'color';
    $this->_headerText = Mage::helper('color')->__('Color Manager');
    $this->_addButtonLabel = Mage::helper('color')->__('Add Color');
    parent::__construct();
  }
}