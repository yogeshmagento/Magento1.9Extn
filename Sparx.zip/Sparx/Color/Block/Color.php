<?php
class Sparx_Color_Block_Color extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getColor()     
     { 
        if (!$this->hasData('color')) {
            $this->setData('color', Mage::registry('color'));
        }
        return $this->getData('color');
        
    }
}