<?php

class Sparx_Color_Model_Color extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('color/color');
    }
}