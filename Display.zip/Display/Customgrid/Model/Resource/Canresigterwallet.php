<?php

class Display_Customgrid_Model_Resource_Canresigterwallet extends Mage_Core_Model_Resource_Db_Abstract
{
	protected function _construct()
	{
		$this->_init('customgrid/canresigterwallet','id');
	}
}


