<?php
class Display_Customgrid_Model_Resource_Canresigterwallet_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract {

	protected function _construct()
    {
            $this->_init('customgrid/canresigterwallet');
    }

	}
?>


