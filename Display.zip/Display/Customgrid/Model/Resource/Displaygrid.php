<?php
/**
 * Created by yogesh.
 * User: sevenstar
 * inial resource model
 * Time: 10:36
 */
class Display_Customgrid_Model_Resource_Displaygrid extends Mage_Core_Model_Resource_Db_Abstract
{
    /***
     * Initialize resource model
     */
    public function _construct()
    {
        $this->_init('customgrid/displaygrid','contact_id');
    }

}

