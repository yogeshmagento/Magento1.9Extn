<?php
/**
 * created by yogesh
 * Date: 22/11/2018
 * Time: 10:35:02
 * initial model 
 */

class Display_Customgrid_Model_Registerwallet extends Mage_Core_Model_Abstract {

    public function __construct()
    {
        parent::__construct();
        $this->_init('customgrid/registerwallet');
    }

}