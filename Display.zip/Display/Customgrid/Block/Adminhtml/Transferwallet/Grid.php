<?php
class Display_Customgrid_Block_Adminhtml_Transferwallet_Grid extends Mage_Adminhtml_Block_Widget_Grid {

    /**
     * Display_Customgrid_Block_Adminhtml_Customgrid_Grid constructor.
     */

    public function __construct()
    {
        parent::__construct();
        $this->setId('transferwalletGrid'); // set’s the ID of our grid
        $this->setDefaultSort('id'); // sorting column to use in our grid
        $this->setDefaultDir('ASC'); // sorting order
        $this->setSaveParametersInSession(true); // sets your grid operations in session
    }

    protected function _prepareCollection()
    {
        $collection = Mage::getModel('customgrid/registerwallet')->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn('id', array(
            'header'    => Mage::helper('customgrid')->__('Id'),
            'align'     =>'left',
            'index'     => 'id',
        ));

         $this->addColumn('customer_id', array(
            'header'    => Mage::helper('customgrid')->__('Customer Id'),
            'width'     => '150px',
            'index'     => 'customer_id',
        ));

         $this->addColumn('customer_name', array(
            'header'    => Mage::helper('customgrid')->__('Name'),
            'align'     =>'left',
            'index'     => 'customer_name',
        ));

         $this->addColumn('transfer_name', array(
            'header'    => Mage::helper('customgrid')->__('Transfer Name'),
            'align'     =>'left',
            'index'     => 'transfer_name',
        ));

         $this->addColumn('amount_transfer', array(
            'header'    => Mage::helper('customgrid')->__('Transfer Amount'),
            'align'     =>'left',
            'index'     => 'amount_transfer',
        ));

        $this->addColumn('transfer_id', array(
            'header'    => Mage::helper('customgrid')->__('Transfer Id'),
            'align'     =>'left',
            'index'     => 'transfer_id',
        ));

         $this->addColumn('admin_get_percentage', array(
            'header'    => Mage::helper('customgrid')->__('Admin Get Percentage'),
            'align'     =>'left',
            'index'     => 'admin_get_percentage',
        ));

        $this->addColumn('date_added', array(
            'header'    => Mage::helper('customgrid')->__('Date Added'),
            'align'     =>'left',
            'index'     => 'date_added',
            'type'      => 'datetime',
        ));
         $this->addColumn('status', array(
            'header'    => Mage::helper('customgrid')->__('Status'),
            'align'     =>'left',
            'index'     => 'status',
        ));

        return parent::_prepareColumns();
    }
    
}