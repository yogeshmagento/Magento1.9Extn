<?php

class Display_Customgrid_Block_Adminhtml_Transferwallet extends Mage_Adminhtml_Block_Widget_Grid_Container {

    public function __construct()
    {
    	$this->_blockGroup = 'display_customgrid';
        $this->_controller = 'adminhtml_transferwallet'; //locations of the grid.php
        $this->_headerText = $this->__('Customer Transferwallet Wallet');
        // $this->_headerText = Mage::helper('customgrid')->__('Register Customer Wallet');
        //$this->_addButtonLabel = Mage::helper('customgrid')->__('Add Contact');
        parent::__construct();
    }


}


