<?php
class Display_Customgrid_Block_Adminhtml_Registerwallet_Grid extends Mage_Adminhtml_Block_Widget_Grid {

    /**
     * Display_Customgrid_Block_Adminhtml_Customgrid_Grid constructor.
     */

    public function __construct()
    {

        parent::__construct();
        $this->setId('registerwalletGrid'); // set’s the ID of our grid
        $this->setDefaultSort('id'); // sorting column to use in our grid
        $this->setDefaultDir('ASC'); // sorting order
        $this->setSaveParametersInSession(true); // sets your grid operations in session
    }

    protected function _prepareCollection()
    {
        $collection = Mage::getModel('customgrid/canresigterwallet')->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
         $this->addColumn('customer_id', array(
            'header'    => Mage::helper('customgrid')->__('Customer Id+'),
            'width'     => '150px',
            'index'     => 'customer_id',
        ));

         $this->addColumn('name', array(
            'header'    => Mage::helper('customgrid')->__('Name'),
            'align'     =>'left',
            'index'     => 'name',
        ));

         $this->addColumn('email', array(
            'header'    => Mage::helper('customgrid')->__('Email'),
            'align'     =>'left',
            'index'     => 'email',
        ));

         $this->addColumn('amount', array(
            'header'    => Mage::helper('customgrid')->__('amount'),
            'align'     =>'left',
            'index'     => 'amount',
        ));
         
        $this->addColumn('id', array(
            'header'    => Mage::helper('customgrid')->__('Id'),
            'align'     =>'left',
            'index'     => 'id',
        ));

        $this->addColumn('created_at', array(
            'header'    => Mage::helper('customgrid')->__('Date'),
            'align'     =>'left',
            'index'     => 'created_at',
             'type'      => 'datetime',
        ));

          
        

       

        

       

        return parent::_prepareColumns();
    }
}