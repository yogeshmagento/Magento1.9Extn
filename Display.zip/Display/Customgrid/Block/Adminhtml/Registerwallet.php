<?php

class Display_Customgrid_Block_Adminhtml_Registerwallet extends Mage_Adminhtml_Block_Widget_Grid_Container {

    public function __construct()
    {
    	$this->_blockGroup = 'display_customgrid';
        $this->_controller = 'adminhtml_registerwallet'; //locations of the grid.php
        $this->_headerText = $this->__('Register Customer Wallet');
        // $this->_headerText = Mage::helper('customgrid')->__('Register Customer Wallet');
        //$this->_addButtonLabel = Mage::helper('customgrid')->__('Add Contact');
        parent::__construct();
    }


}


